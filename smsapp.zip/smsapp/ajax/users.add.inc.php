<?php

include_once($_SERVER['DOCUMENT_ROOT']."/core/init.inc.php");
//include_once(DOCUMENT_ROOT."/config/api.inc.php");

if (!empty($_POST)) {

		
		 $fullname = ($_POST['fullname']) ? $_POST['fullname'] : '';
         $fullname = helper::clearText($fullname);
         $fullname = helper::escapeText($fullname);
		 
		 $lastname = ($_POST['lastname']) ? $_POST['lastname'] : '';
         $lastname = helper::clearText($lastname);
         $lastname = helper::escapeText($lastname);
		 
		 $fullname = ($_POST['fullname']) ? $_POST['fullname'] : '';
         $fullname = helper::clearText($fullname);
         $firstname = helper::escapeText($fullname);
		 
		 
		 $email = isset($_POST['email']) ? $_POST['email'] : '';
         $email = helper::clearText($email);
         $email = helper::escapeText($email);
		 
		 $categoryId = isset($_POST['categoryId']) ? $_POST['categoryId'] : '';
         $categoryId = helper::clearText($categoryId);
         $categoryId = helper::escapeText($categoryId);
		 
		 
		 $password = isset($_POST['password']) ? $_POST['password'] : '';
         $password = helper::clearText($password);
         $password = helper::escapeText($password);
         $password = '123456';
		 
		 $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
         $phone = helper::clearText($phone);
         $phone = helper::escapeText($phone);
		 
		 
		 $username = isset($_POST['username']) ? $_POST['username'] : '';
         $username = helper::clearText($username);
         $username = helper::escapeText($username);
		 $rand = rand(0, 999);
         $username = "company".$rand;
		 
		 
		 $lowPhotoUrl = isset($_POST['lowPhotoUrl']) ? $_POST['lowPhotoUrl'] : '';
         $lowPhotoUrl = helper::clearText($lowPhotoUrl);
         $lowPhotoUrl = helper::escapeText($lowPhotoUrl);
		 
		 $type = isset($_POST['type']) ? $_POST['type'] : '';
         $type = helper::clearText($type);
         $type = helper::escapeText($type);
         $type = 'per';
		 
		 
		 $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
         $gender = helper::clearText($gender);
         $sex= helper::escapeText($gender);
		 
		 $country_id = isset($_POST['country_id']) ? $_POST['country_id'] : '';
         $country_id = helper::clearText($country_id);
         $country_id= helper::escapeText($country_id);
		 
		 $lat = isset($_POST['lat']) ? $_POST['lat'] : '';
		 $lng = isset($_POST['lng']) ? $_POST['lng'] : '';
		
		 $account_type = isset($_POST['type']) ? $_POST['type'] : 0;
		 $user_year = isset($_POST['year']) ? $_POST['year'] : 0;
		 $user_month = isset($_POST['month']) ? $_POST['month'] : 0;
		 $user_day = isset($_POST['day']) ? $_POST['day'] : 0;
		
		 $user_year = helper::clearInt($user_year);
		 $user_month = helper::clearInt($user_month);
		 $user_day = helper::clearInt($user_day);
		 $lat = helper::clearText($lat);
		 $lng = helper::clearText($lng);
		
		 
		 $access_data = array();
		 
		 
		 $result = array("error" => true,
		 "error_message" => 'error signup');
		
		
		$account = new account($dbo);
		
		$result = $account->RegisterAccount($username, $fullname,$lastname, $password, $email, $gender, $phone, $type,$country_id,$lowPhotoUrl,$categoryId, 2000, 1, 1, $LANG['lang-code']);
		
		unset($account);
    echo json_encode($result);
    exit;
}

?>