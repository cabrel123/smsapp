<?php

include_once($_SERVER['DOCUMENT_ROOT']."/core/init.inc.php");

?>
<?php  

 if (!empty($_POST)) {
        
		
         $title = isset($_POST['title']) ? $_POST['title'] : '';
         $title = helper::clearText($title);
         $title = helper::escapeText($title);
		 
		 $description = isset($_POST['description']) ? $_POST['description'] : '';
         $description = helper::clearText($description);
         //$description = helper::escapeText($description);
		 
		$categories = new categories($dbo);
		
		$result = $categories->add($title, $description);
		
		unset($categories);
		 
		
		echo json_encode($result);
    exit;
}
?>
