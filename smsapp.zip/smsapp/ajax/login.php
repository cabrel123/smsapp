<?php
/**************************************************************** *
 * SMSAPP engine v1.0        					  				  *
 *                                                                *
 * 						                                          *
 * monkamcabrel11@gmail.com                             		  *
 *                                                                *
 * Copyright 2023 MONKAM CABREL									  *
 ******************************************************************
 */
/**
|----------------------------------------------------------------------------------------------------------------------------
| Iniatiate class by calling init.inc.php
|-----------------------------------------------------------------------------------------------------------------------------
*/
include_once($_SERVER['DOCUMENT_ROOT']."/core/init.inc.php");

/**
|----------------------------------------------------------------------------------------------------------------------------
| check if posted values submited
|-----------------------------------------------------------------------------------------------------------------------------
*/
if (!empty($_POST)) {

/**
|----------------------------------------------------------------------------------------------------------------------------
| get all posted values
|-----------------------------------------------------------------------------------------------------------------------------
*/
    
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

/**
|----------------------------------------------------------------------------------------------------------------------------
| Sanitize all posted values
|-----------------------------------------------------------------------------------------------------------------------------
*/  
    $username = helper::clearText($username);
    $password = helper::clearText($password);

    $username = helper::escapeText($username);
    $password = helper::escapeText($password);

/**
|----------------------------------------------------------------------------------------------------------------------------
| Iniatiate array result
|-----------------------------------------------------------------------------------------------------------------------------
*/	
    $access_data = array();

/**
|----------------------------------------------------------------------------------------------------------------------------
| Call class account to load signin funtion
|-----------------------------------------------------------------------------------------------------------------------------
*/
    $account = new account($dbo);
    $access_data = $account->signin($username, $password);

    unset($account);

/**
|----------------------------------------------------------------------------------------------------------------------------
| Check if signin successfulled
|-----------------------------------------------------------------------------------------------------------------------------
*/
    if ($access_data["error"] === false) {
		
        $account = new account($dbo, $access_data['accountId']);

        switch ($account->getState()) {

            case ACCOUNT_STATE_BLOCKED: {

                break;
            }

            default: {

                $auth = new auth($dbo);
                $access_data = $auth->create($access_data['accountId'], $clientId=0);

                if ($access_data['error'] === false) {
					
					auth::setSession($access_data['accountId'], $username, $account_fullname='', $account_photo_url='', $account_verify='', $account->getAccessLevel($access_data['accountId']), $access_data['accessToken']);
                            auth::updateCookie($username, $access_data['accessToken']);

                            unset($_SESSION['oauth']);
                            unset($_SESSION['oauth_id']);
                            unset($_SESSION['oauth_name']);
                            unset($_SESSION['oauth_email']);
                            unset($_SESSION['oauth_link']);

                    $account = new account($dbo, $access_data['accountId']);
                    $account->setState(ACCOUNT_STATE_ENABLED);
                    $account->setLastActive();
					
					
                    $access_data['account'] = array();

                    array_push($access_data['account'], $account->get());

                }

                break;
            }
        }
    }

    echo json_encode($access_data);
    exit;
}
