/**
* @author  E-LEARNING CNPS
* @since 2020
* @copyright CNPS 2020
*/

/**
*---------------------------------------------------------------------------------------------------------------------------------
* Fonction pour la connexion d'utilisateur
* @param {string} username - Elements posted by the html form  from login.html page
* @param {password} password - Elements posted by the html form  from login.html page
* @return {boolean} Alway returns false.
*----------------------------------------------------------------------------------------------------------------------------------
*/
$("#login-form").submit(function(e) {
    e.preventDefault();
}).validate({ // initialize the plugin
        rules: {
            username: {
                required: true
            },
            password: {
                required: true,
                minlength: 5
            }
        },
		messages:{
					username: {
							required: "Saisissez un nom d'utilisateur"
					},				
					password: {
							required: "Saisissez un mot de passe"
					}			
			},
			
						errorPlacement: function(error, element) {
						   if (element.is(":radio") || element.is(":checkbox")) {
									element.closest('.option-group').after(error);
						   } else {
									error.insertAfter(element.parent());
						   }
						},
        submitHandler: function (form) {
      /* stop form from submitting normally */
 $(".iconlock").hide();    
 $(".spinner").show();    
	  
var username				= $("#username").val();
var password				= $("#password").val();
var successlogin            = "Connexion réussie ! Vous serez redirigé dans un instant...";

	$.ajax({
			url      :"/ajax/login.php",
			method   :'POST',
			data     :{username:username,password:password},
			dataType : 'html',
			success  :function(data)
			{
				if(data){
              alert(data);
			var result 		= $.parseJSON(data);
			var accountId   = result.accountId;
			var error_msg   = result.error;
			var error_desc  = result.error_description;
			
			if(error_msg == true){
				$(".spinner").hide(); 
				 $(".iconlock").show();    
				
			 $('#success').html('<div class="alert alert-danger">'+error_desc+'</div>').fadeIn('slow');          
                $('#success').delay(2500).fadeOut('slow');
			}else{
			  //  $redirectForm_url = "/thankyou.html/$result/fr.html/transaction-réussie"; /* Redirection du navigateur */		
			  $('#success').html('<div class="alert alert-success">'+successlogin+'</div>').fadeIn('slow');          
                $('#success').delay(1500).fadeOut('slow');
				// Store
				localStorage.setItem("userId", accountId);

				localStorage.setItem("accountId", accountId);
				var app_url                 = '/dashboard/'+accountId+'/fr/my-account';
				setTimeout(function () { window.location.replace(app_url) }, 1000);
			  }
            }else{
				$(".spinner").hide(); 
				 $(".iconlock").show(); 
                $('#success').html('<div class="alert alert-danger">Trasaction failed please check your login!</div>').fadeIn('slow');          
                $('#success').delay(1500).fadeOut('slow');
            }
			}
		});
		
		return false;
	}
	 
});

/**
*---------------------------------------------------------------------------------------------------------------------------------
* Fonction pour la visibilité du mot de passe
*----------------------------------------------------------------------------------------------------------------------------------
*/
function show() {
    var p = document.getElementById('password');
    p.setAttribute('type', 'text');
}

function hide() {
    var p = document.getElementById('password');
    p.setAttribute('type', 'password');
}

var pwShown = 0;

document.getElementById("eye").addEventListener("click", function () {
    if (pwShown == 0) {
        pwShown = 1;
        show();
    } else {
        pwShown = 0;
        hide();
    }
}, false);

$('#username').keypress(function( e ) {
    if(e.which === 32) 
        alert("Ce champ ne doit pas avoir d'espace");
});