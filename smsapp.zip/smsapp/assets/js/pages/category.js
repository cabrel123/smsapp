/* Ajouter une catégorie */

$("#addcategory").submit(function(e) {
    e.preventDefault();
}).validate({ // initialize the plugin
			
        rules: {
            title: {
                required: true
            },
			
        },
		
		errorPlacement: function(error, element) {
		   if (element.is(":radio") || element.is(":checkbox")) {
					element.closest('.form-group').after(error);
		   } else {
					error.insertAfter(element.parent());
		   }
		},
        submitHandler: function (form) {

var formData 				= $('#addcategory').serialize();
var form_data 				= new FormData();
//alert(formData);
//alert(form_data);

		$.ajax({
			url:"/ajax/category.add.inc.php",
			method:'POST',
			data:formData,
			dataType: 'html',
			success:function(data)
			{
				if(data){
				
              //alert(data);
			  var result 	= $.parseJSON(data);
				var error   = result.error;
				var error_msg   = result.error_description;
				
				if(error == true){
					$('#success').html('<div class="alert alert-danger">'+error_msg+'</div>').fadeIn('slow');          
					$('#success').delay(1600).fadeOut('slow');
					
				}else{
					$('#success').html('<div class="alert alert-success">Enregistrement réussi !</div>').fadeIn('slow');          
					$('#success').delay(1600).fadeOut('slow');
					location.reload();
				}

            }else{
                $('#success').html('<div class="alert alert-danger">Erreur d\'enregistrement!</div>').fadeIn('slow');          
                $('#success').delay(2500).fadeOut('slow');
            }
			}
		});
               
		return false;
	}
});