<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class models extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM model");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM model");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO model (title, description, imgUrl, createAt, ip_addr, u_agent) value (:title, :description, :imgUrl, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "modelId" => $this->db->lastInsertId(),
                            "model" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }

    public function remove($modelId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $modelInfo = $this->info($modelId);

        if ($modelInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE model SET removeAt = (:removeAt) WHERE id = (:modelId)");
        $stmt->bindParam(":modelId", $modelId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            //remove all models

            $stmt3 = $this->db->prepare("SELECT id FROM cars WHERE category = (:category)");
            $stmt3->bindParam(":category", $modelId, PDO::PARAM_INT);

            if ($stmt3->execute()) {

                while ($row = $stmt->fetch()) {

                    $model = new models($this->db);

                    $model->remove($row['id']);

                    unset($model);
                }
            }

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

            $this->recalculate($modelId);
        }

        return $result;
    }

    public function edit($modelId, $title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }


        $stmt = $this->db->prepare("UPDATE model SET title = (:title), description = (:description), imgUrl = (:imgUrl) WHERE id = (:modelId)");
        $stmt->bindParam(":modelId", $modelId, PDO::PARAM_INT);
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }

    public function recalculate($categoryId) {

        $models_count = 0;

        $models_count = $this->getItemsCount($categoryId);

        $stmt = $this->db->prepare("UPDATE model SET modelsCount = (:modelsCount) WHERE id = (:categoryId)");
        $stmt->bindParam(":modelsCount", $models_count, PDO::PARAM_INT);
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->execute();
    }

    private function getItemsCount($categoryId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE category = (:category) AND removeAt = 0");
        $stmt->bindParam(":category", $categoryId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function info($modelId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM model WHERE id = (:modelId) LIMIT 1");
        $stmt->bindParam(":modelId", $modelId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "modelsCount" => $row['modelsCount'],
                                "model" => htmlspecialchars_decode(stripslashes($row['model'])),
                                "description" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "makeId" => $row['makeId'],
                                "year" => $row['year'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "removeAt" => $row['removeAt']);

            }
        }

        return $result;
    }

    public function get($modelId = 0, $makeId)
    {
        if ($modelId == 0) {

            $modelId = $this->getMaxIdItems();
            $modelId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "modelId" => $modelId,
                        "models" => array());

        $stmt = $this->db->prepare("SELECT id FROM model WHERE removeAt = 0 AND makeId = (:makeId) AND id < (:modelId) ORDER BY id DESC LIMIT 50");
        $stmt->bindParam(':modelId', $modelId, PDO::PARAM_INT);
        $stmt->bindParam(':makeId', $makeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $modelInfo = $this->info($row['id']);

                array_push($result['models'], $modelInfo);

                $result['modelId'] = $modelInfo['id'];

                unset($modelInfo);
            }
        }

        return $result;
    }

    public function getList()
    {
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "models" => array());

        $stmt = $this->db->prepare("SELECT id FROM model WHERE removeAt = 0 ORDER BY id");

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $modelInfo = $this->info($row['id']);

                array_push($result['models'], $modelInfo);

                unset($modelInfo);
            }
        }

        return $result;
    }

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
