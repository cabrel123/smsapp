<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class comments extends db_connect
{

	private $requestFrom = 0;
    private $language = 'en';

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function allCommentsCount()
    {
        $stmt = $this->db->prepare("SELECT max(id) FROM comments");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM comments WHERE removeAt = 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count($itemId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM comments WHERE itemId = (:itemId) AND removeAt = 0 AND status=1");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

 public function CountContentComment($itemId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM comments WHERE itemId = (:itemId) AND removeAt = 0 AND status=1");
		 $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
/***************************** Fonction pour approver un contenu *********************************/	
    public function approve($commentId, $status)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $commentsInfo = $this->info($commentId);

        if ($commentsInfo['error'] === true) {

            return $result;
        }
		
       date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');

        $stmt = $this->db->prepare("UPDATE comments SET status = (:status), createAt = (:publish_date) WHERE id = (:commentId)");
        $stmt->bindParam(":commentId", $commentId, PDO::PARAM_INT);
        $stmt->bindParam(":status", $status, PDO::PARAM_INT);
        $stmt->bindParam(":publish_date", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }
	
	public function addcomment($itemId, $text, $notifyId = 0, $name, $mail, $phone)
    {
        $result = array("error" => true,
                        "itemId" => $itemId,
                        "text" => $text,
                        "notifyId" => $notifyId,
                        "name" => $name,
                        "mail" => $mail,
                        "phone" => $phone,
                        "error_description" => "Une erreur s'est produite",
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($text) == 0) {

            return $result;
        }

date_default_timezone_set("Africa/Douala");
		$dates = date('Y-m-d');
        $currentTime = $dates;
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO comments (name, mail,phone, itemId, comment, createAt, notifyId, ip_addr, u_agent) value (:name, :mail, :phone, :itemId, :comment, :createAt, :notifyId, :ip_addr, :u_agent)");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->bindParam(":phone", $phone, PDO::PARAM_STR);
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->bindParam(":comment", $text, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
        $stmt->bindParam(":notifyId", $notifyId, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

         if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }
	
    private function setNotifyId($commentId, $notifyId)
    {
        $stmt = $this->db->prepare("UPDATE comments SET notifyId = (:notifyId) WHERE id = (:commentId)");
        $stmt->bindParam(":commentId", $commentId, PDO::PARAM_INT);
        $stmt->bindParam(":notifyId", $notifyId, PDO::PARAM_INT);

        $stmt->execute();
    }
	
	
	
	public function reply($accountId,$commentId, $description)
    {
        $result = array("error" => true,
                        "accountId" => $accountId,
                        "commentId" => $commentId,
                        "description" => $description,
                        "error_code" => ERROR_UNKNOWN);

        $commentInfo = $this->info($commentId);

        if ($commentInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE comments SET replyMsg = (:description), replyToUserId = (:accountId)  WHERE id = (:commentId)");
        $stmt->bindParam(":commentId", $commentId, PDO::PARAM_INT);
        $stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);

        if ($stmt->execute()) {

           

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }
	
	
    public function remove($commentId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $commentInfo = $this->info($commentId);

        if ($commentInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE comments SET removeAt = (:removeAt) WHERE id = (:commentId)");
        $stmt->bindParam(":commentId", $commentId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

           

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function removeAll($itemId) {

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE comments SET removeAt = (:removeAt) WHERE itemId = (:itemId)");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
    }

    public function info($commentId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM comments WHERE id = (:commentId) LIMIT 1");
        $stmt->bindParam(":commentId", $commentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $profile = new profile($this->db, $row['fromUserId']);
                $fromUserId = $profile->get();
                unset($profile);

                $replyToUserId = $row['replyToUserId'];
                $replyToUserUsername = "";
                $replyToFullname = "";

                if ($replyToUserId != 0) {

                    $profile = new profile($this->db, $row['replyToUserId']);
                    $replyToUser = $profile->get();
                    unset($profile);

                    $replyToUserUsername = $replyToUser['username'];
                    $replyToFullname = $replyToUser['fullname'];
                }

                $lowPhotoUrl = "";

                if (strlen($fromUserId['lowPhotoUrl']) != 0) {

                    $lowPhotoUrl = $fromUserId['lowPhotoUrl'];
                }
setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
$date = strftime(" %d %h %Y %H:%M",strtotime($row['createAt']));
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "comment" => htmlspecialchars_decode(stripslashes($row['comment'])),
                                "replyMsg" => htmlspecialchars_decode(stripslashes($row['replyMsg'])),
                                "phone" => $row['phone'],
                                "fromUserUsername" => $row['name'],
                                "fromUserEmail" => $row['mail'],
                                "fromUserId" => $row['fromUserId'],
                                "status" => $row['status'],
                                "fromUserState" => $fromUserId['state'],
                                "replyToUserId" => $replyToUserId,
                                "replyToUserUsername" => $replyToUserUsername,
                                "replyToFullname" => $replyToFullname,
                                "date" => $date,
                                "itemId" => $row['itemId'],
                                "createAt" => $row['createAt'],
                                "notifyId" => $row['notifyId'],
                                "timeAgo" => $time->timeAgo($row['createAt']));
            }
        }

        return $result;
    }

    public function get($commentId = 0, $itemId)
    {
        if ($commentId == 0) {

            $commentId = $this->allCommentsCount() + 1;
        }

        $comments = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "commentId" => $commentId,
                          "itemId" => $itemId,
                          "comments" => array());

        $stmt = $this->db->prepare("SELECT id FROM comments WHERE id < (:commentId) AND removeAt = 0 AND status = 1 AND itemId = (:itemId) ORDER BY id DESC LIMIT 70");
        $stmt->bindParam(':commentId', $commentId, PDO::PARAM_INT);
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $commentInfo = $this->info($row['id']);

                array_push($comments['comments'], $commentInfo);

                $comments['commentId'] = $commentInfo['id'];

                unset($commentInfo);
            }
        }

        return $comments;
    }
	
	
    public function getReply($commentId = 0, $itemId)
    {
        if ($commentId == 0) {

            $commentId = $this->allCommentsCount() + 1;
        }

        $comments = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "commentId" => $commentId,
                          "itemId" => $itemId,
                          "comments" => array());

        $stmt = $this->db->prepare("SELECT id FROM comments WHERE id < (:commentId) AND removeAt = 0 AND status = 1 AND itemId = (:itemId) AND replyMsg != '' ORDER BY id DESC LIMIT 3");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);
        $stmt->bindParam(':commentId', $commentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $commentInfo = $this->info($row['id']);

                array_push($comments['comments'], $commentInfo);

                $comments['commentId'] = $commentInfo['id'];

                unset($commentInfo);
            }
        }

        return $comments;
    }
	
	public function getLastComment($commentId = 0, $limit)
    {
        if ($commentId == 0) {

            $commentId = $this->allCommentsCount() + 1;
        }

        $comments = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "commentId" => $commentId,
                          "itemId" => $itemId,
                          "comments" => array());

        $stmt = $this->db->prepare("SELECT id FROM comments WHERE id < (:commentId) AND removeAt = 0 ORDER BY id DESC LIMIT $limit");
        //$stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);
        $stmt->bindParam(':commentId', $commentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $commentInfo = $this->info($row['id']);

                array_push($comments['comments'], $commentInfo);

                $comments['commentId'] = $commentInfo['id'];

                unset($commentInfo);
            }
        }

        return $comments;
    }
	

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }
	 public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }
    public function getRequestFrom()
    {
        return $this->requestFrom;
    }
}
