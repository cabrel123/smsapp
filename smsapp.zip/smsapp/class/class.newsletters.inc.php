<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * inovtech.net                                            *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class newsletters extends db_connect
{

	private $requestFrom = 0;
    private $language = 'en';

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}


    public function pendingUsersCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM mailing_users WHERE   mailing = 1 && suspended=0 && valid_email=1 && active_mailing = 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
    
        public function pendingTestUsersCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM mailing_test_users WHERE   mailing = 1 && suspended=0 && valid_email=1 && active_mailing = 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	public function getIfSubscriberExist($email)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM newsletter WHERE email = (:email)");
		$stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
      public function CheckIfAnyRunningCampaign()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM newsletter_campaign WHERE campaign_status = 1");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	 public function CheckIfAnyRunningCampaign2()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM campaigns WHERE campaign_status = 1");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	public function CountAllNewsletterSubscribers()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM newsletter WHERE deleted = 0 AND flag=0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	/*
|------------------------------------------------------------------------------
| CheckLastCampaign
|------------------------------------------------------------------------------
*/	
	public function CheckLastCampaign($pdf_id)
    {
        $stmt = $this->db->prepare("SELECT id FROM campaigns WHERE campaign_status = 1 AND pdf_id = (:pdf_id)");
       $stmt->bindParam(":pdf_id", $pdf_id, PDO::PARAM_INT);
        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['id'];
        }

        return 0;
    }
	
public function CheckLastCampaign2()
    {
        $stmt = $this->db->prepare("SELECT campaignId FROM newsletter_campaign WHERE campaign_status = 1 ORDER BY id DESC LIMIT 1");
        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['campaignId'];
        }

        return 0;
    }
	
public function getGroupCampaign($campaignId)
    {
        $stmt = $this->db->prepare("SELECT mailing_group FROM mailing WHERE  id = (:campaignId)");
       $stmt->bindParam(":campaignId", $campaignId, PDO::PARAM_INT);
        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['mailing_group'];
        }

        return 0;
    }
	
	public function getMessageCampaign($campaignId)
    {
        $stmt = $this->db->prepare("SELECT subject FROM mailing WHERE  id = (:campaignId)");
       $stmt->bindParam(":campaignId", $campaignId, PDO::PARAM_INT);
        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['subject'];
        }

        return '';
    }
/*
|------------------------------------------------------------------------------
| update 
|------------------------------------------------------------------------------
*/	
public function UpdateSuscriberwhohavenotreceived2($suscriber_id,$msgerror)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur de mise à jour");

        $stmt = $this->db->prepare("UPDATE newsletter SET smtp_message = (:msgerror) WHERE id = (:suscriber_id)");
        $stmt->bindParam(":suscriber_id", $suscriber_id, PDO::PARAM_INT);
        $stmt->bindParam(":msgerror", $msgerror, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
						"profileId" => $suscriber_id);
        }


        return $result;
    }
/*
|------------------------------------------------------------------------------
| update
|------------------------------------------------------------------------------
*/	
public function UpdateSuscriberwhohavereceived2($suscriber_id,$campaign_id)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur de mise à jour");

        $stmt = $this->db->prepare("UPDATE newsletter SET flag = 1, campaign_id = (:campaign_id) WHERE id = (:suscriber_id)");
        $stmt->bindParam(":suscriber_id", $suscriber_id, PDO::PARAM_INT);
        $stmt->bindParam(":campaign_id", $campaign_id, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
						"profileId" => $suscriber_id);
        }


        return $result;
    }
	
/*
|------------------------------------------------------------------------------
| Update cameroon-tribune suscriber when campaign end 
|------------------------------------------------------------------------------
*/	
public function UpdateSuscriberTable2()
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur de mise à jour");

        $stmt = $this->db->prepare("UPDATE newsletter SET campaign_id ='', flag = ''");

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }


        return $result;
    }
	
	
public function CloseCampaign($campaignId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur de mise à jour");

	date_default_timezone_set("Africa/Douala");
$Enddate 							= date("Y-m-d H:i:s");

        $stmt = $this->db->prepare("UPDATE newsletter_campaign SET campaign_status = 0, end_date = (:Enddate) WHERE campaign_status = 1 AND campaignId = (:campaignId)");
        $stmt->bindParam(":Enddate", $Enddate, PDO::PARAM_STR);
        $stmt->bindParam(":campaignId", $campaignId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
						"campaignId" => $campaignId);
        }


        return $result;
    }
	
public function CloseCampaign2($campaignId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur de mise à jour");

	date_default_timezone_set("Africa/Douala");
$Enddate 							= date("Y-m-d H:i:s");

        $stmt = $this->db->prepare("UPDATE campaigns SET campaign_status = 0, end_date = (:Enddate) WHERE campaign_status = 1 AND id = (:campaignId)");
        $stmt->bindParam(":Enddate", $Enddate, PDO::PARAM_STR);
        $stmt->bindParam(":campaignId", $campaignId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
						"campaignId" => $campaignId);
        }


        return $result;
    }	
	
     public function pendingCampaign()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM mailing WHERE   status = 0 && running =0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }


    public function activeChatsCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM chats WHERE removeAt = 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function myActiveChatsCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM chats WHERE (fromUserId = (:userId) OR toUserId = (:userId)) AND removeAt = 0");
        $stmt->bindParam(":userId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function mailingsCountByChat($chatId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM mailings WHERE chatId = (:chatId) AND removeAt = 0");
        $stmt->bindParam(":chatId", $chatId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getMessagesCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM mailings WHERE removeAt = 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getMaxChatId()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM chats");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getMaxMessageId()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM mailings");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function InsertMailingSend($filepdf,$campaign_id,$receiver_email,$id_company,$date,$pdf_id,$suscriber_id) {

	$result = array("error" => true,
                        "filepdf" => $filepdf,
                        "campaign_id" => $campaign_id,
                        "receiver_email" => $receiver_email,
                        "id_company" => $id_company,
                        "date" => $date,
                        "pdf_id" => $pdf_id,
                        "suscriber_id" => $suscriber_id,
                        "error_code" => ERROR_UNKNOWN);
						
        $stmt = $this->db->prepare("INSERT INTO mailing_sent (pdf, campaign_id, email, id_company, date, idpdf, id_abonne) value (:filepdf, :campaign_id, :receiver_email, :id_company, :date, :pdf_id, :suscriber_id)");
        $stmt->bindParam(":filepdf", $filepdf, PDO::PARAM_STR);
        $stmt->bindParam(":campaign_id", $campaign_id, PDO::PARAM_INT);
        $stmt->bindParam(":receiver_email", $receiver_email, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        $stmt->bindParam(":id_company", $id_company, PDO::PARAM_INT);
        $stmt->bindParam(":pdf_id", $pdf_id, PDO::PARAM_INT);
        $stmt->bindParam(":suscriber_id", $suscriber_id, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            'newsletters' => $this->db->lastInsertId(),
                            'suscriber_id'     => $suscriber_id,
                            'error_code'    => ERROR_SUCCESS,
                            'error_description' => 'Subscription Success!');

        }

        return $result;
    }

	 public function InsertMailingSend2($id_company,$suscriber_id) {

	$result = array("error" => true,
                        "id_company" => $id_company,
                        "suscriber_id" => $suscriber_id,
                        "error_code" => ERROR_UNKNOWN);
						
		date_default_timezone_set("Africa/Douala");
		$date 							= date("Y-m-d H:i:s");

        $stmt = $this->db->prepare("INSERT INTO alert_mail_report (subscriberId, id_company, date) value (:suscriber_id, :id_company, :date)");
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        $stmt->bindParam(":id_company", $id_company, PDO::PARAM_INT);
        $stmt->bindParam(":suscriber_id", $suscriber_id, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            'newsletters' => $this->db->lastInsertId(),
                            'suscriber_id'     => $suscriber_id,
                            'error_code'    => ERROR_SUCCESS,
                            'error_description' => 'Subscription Success!');

        }

        return $result;
    }
	
	public function InsertMailingSend3($id_company,$suscriber_id) {

	$result = array("error" => true,
                        "id_company" => $id_company,
                        "suscriber_id" => $suscriber_id,
                        "error_code" => ERROR_UNKNOWN);
						
		date_default_timezone_set("Africa/Douala");
		$date 							= date("Y-m-d H:i:s");

        $stmt = $this->db->prepare("INSERT INTO newsletter_report (subscriberId, id_company, date) value (:suscriber_id, :id_company, :date)");
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        $stmt->bindParam(":id_company", $id_company, PDO::PARAM_INT);
        $stmt->bindParam(":suscriber_id", $suscriber_id, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            'newsletters' => $this->db->lastInsertId(),
                            'suscriber_id'     => $suscriber_id,
                            'error_code'    => ERROR_SUCCESS,
                            'error_description' => 'Subscription Success!');

        }

        return $result;
    }
	
	
	
	
    public function setChatLastView_FromId($chatId) {

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE chats SET fromUserId_lastView = (:fromUserId_lastView) WHERE id = (:chatId)");
        $stmt->bindParam(":chatId", $chatId, PDO::PARAM_INT);
        $stmt->bindParam(":fromUserId_lastView", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function setChatLastView_ToId($chatId) {

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE chats SET toUserId_lastView = (:toUserId_lastView) WHERE id = (:chatId)");
        $stmt->bindParam(":chatId", $chatId, PDO::PARAM_INT);
        $stmt->bindParam(":toUserId_lastView", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function getChatId($fromUserId, $toUserId) {

        $chatId = 0;

        $stmt = $this->db->prepare("SELECT id FROM chats WHERE removeAt = 0 AND ((fromUserId = (:fromUserId) AND toUserId = (:toUserId)) OR (fromUserId = (:toUserId) AND toUserId = (:fromUserId))) LIMIT 1");
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":toUserId", $toUserId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $chatId = $row['id'];
            }
        }

        return $chatId;
    }
	
	public function getCampaignStatus($campaign_id) {

        $campaign_status = 0;

        $stmt = $this->db->prepare("SELECT campaign_status FROM newsletter_campaign WHERE campaignId = (:campaign_id) LIMIT 1");
        $stmt->bindParam(":campaign_id", $campaign_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $campaign_status = $row['campaign_status'];
            }
        }

        return $campaign_status;
    }



    public function removeChat($chatId) {

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE chats SET removeAt = (:removeAt) WHERE id = (:chatId)");
        $stmt->bindParam(":chatId", $chatId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $stmt2 = $this->db->prepare("UPDATE mailings SET removeAt = (:removeAt) WHERE chatId = (:chatId)");
            $stmt2->bindParam(":chatId", $chatId, PDO::PARAM_INT);
            $stmt2->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt2->execute();

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }


    public function remove($itemId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE mailing SET deleted = (:removeAt) WHERE id = (:itemId)");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function getLastMessageInChat($chatId) {

        $stmt = $this->db->prepare("SELECT id FROM mailings WHERE chatId = (:chatId) AND removeAt = 0 ORDER BY id DESC LIMIT 1");
        $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['id'];
        }

        return 0;
    }

    public function getNewMessagesInChat($chatId) {

        $chatInfo = $this->chatInfoShort($chatId);

        $profileId = $chatInfo['fromUserId'];

        if ($profileId == $this->getRequestFrom()) {

            $fromUserId_lastView = $chatInfo['fromUserId_lastView'];

            $stmt = $this->db->prepare("SELECT count(*) FROM mailings WHERE chatId = (:chatId) AND fromUserId <> (:fromUserId) AND createAt > (:fromUserId_lastView) AND removeAt = 0 ORDER BY id DESC LIMIT 1");
            $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);
            $stmt->bindParam(':fromUserId', $this->requestFrom, PDO::PARAM_INT);
            $stmt->bindParam(':fromUserId_lastView', $fromUserId_lastView, PDO::PARAM_INT);

        } else {

            $toUserId_lastView = $chatInfo['toUserId_lastView'];

            $stmt = $this->db->prepare("SELECT count(*) FROM mailings WHERE chatId = (:chatId) AND fromUserId <> (:fromUserId) AND createAt > (:toUserId_lastView) AND removeAt = 0 ORDER BY id DESC LIMIT 1");
            $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);
            $stmt->bindParam(':fromUserId', $this->requestFrom, PDO::PARAM_INT);
            $stmt->bindParam(':toUserId_lastView', $toUserId_lastView, PDO::PARAM_INT);
        }


        if ($stmt->execute()) {

            return $number_of_rows = $stmt->fetchColumn();
        }

        return 0;
    }

    public function chatInfo($chatId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM chats WHERE id = (:chatId) LIMIT 1");
        $stmt->bindParam(":chatId", $chatId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $profileId = $row['fromUserId'];

                if ($profileId == $this->getRequestFrom()) {

                    $profileId = $row['toUserId'];
                }

                $lastMessage = $this->info($this->getLastMessageInChat($chatId));

                if ($lastMessage['error'] === true) {

                    $lastMessage['createAt'] = 0;
                    $lastMessage['message'] = "Unknown";
                }

                $profile = new profile($this->db, $profileId);
                $profileInfo = $profile->get();
                unset($profile);

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "fromUserId" => $row['fromUserId'],
                                "toUserId" => $row['toUserId'],
                                "fromUserId_lastView" => $row['fromUserId_lastView'],
                                "toUserId_lastView" => $row['toUserId_lastView'],
                                "withUserId" => $profileInfo['id'],
                                "withUserVerify" => $profileInfo['verify'],
                                "withUserState" => $profileInfo['state'],
                                "withUserUsername" => $profileInfo['username'],
                                "withUserFullname" => $profileInfo['fullname'],
                                "withUserPhotoUrl" => $profileInfo['lowPhotoUrl'],
                                "lastMessage" => $lastMessage['message'],
                                "lastMessageAgo" => $time->timeAgo($lastMessage['createAt']),
                                "lastMessageCreateAt" => $lastMessage['createAt'],
                                "newMessagesCount" => $this->getNewMessagesInChat($chatId),
                                "createAt" => $row['createAt'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "timeAgo" => $time->timeAgo($row['createAt']),
                                "removeAt" => $row['removeAt']);

                unset($profileInfo);
            }
        }

        return $result;
    }

    public function chatInfoShort($chatId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM chats WHERE id = (:chatId) LIMIT 1");
        $stmt->bindParam(":chatId", $chatId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $result = array("error" => false,
                    "error_code" => ERROR_SUCCESS,
                    "id" => $row['id'],
                    "fromUserId" => $row['fromUserId'],
                    "toUserId" => $row['toUserId'],
                    "fromUserId_lastView" => $row['fromUserId_lastView'],
                    "toUserId_lastView" => $row['toUserId_lastView'],
                    "createAt" => $row['createAt'],
                    "removeAt" => $row['removeAt']);

                unset($profileInfo);
            }
        }

        return $result;
    }

	
	
    public function info($mailingId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM mailing WHERE id = (:mailingId) LIMIT 1");
        $stmt->bindParam(":mailingId", $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

            
    $profile = new profile($this->db, $row['sender']);
                 $profileInfo = $profile->get();
                  unset($profile);
				   setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
 $senddate = strftime(" %d %h %Y",strtotime($row['date']));
                $token = uniqid();
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "subject" => $row['subject'],
                                "message" => htmlspecialchars_decode(stripslashes($row['message'])),
                                "mailing_group" => $row['mailing_group'],
                                "FromUsername" => $profileInfo['fullname'],
                                "status"        => $row['status'],
                                "token"        => $token,
                                "dbUploaded"        => $row['dbUploaded'],
                                "running"        => $row['running'],
                                "senddate"        => $senddate,
                                "pendingUsersCount" => $this->pendingUsersCount(),
                                "pendingCampaignCount" => $this->pendingCampaign(),
                                  
                                
                                "date" => $row['date']
                                );
            }
        }

        return $result;
    }
    
	public function info2($mailingsId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM newsletter WHERE id = (:mailingsId) LIMIT 1");
        $stmt->bindParam(":mailingsId", $mailingsId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
 $senddate = strftime(" %d %h %Y %H:%m",strtotime($row['date']));
               
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "FromUsername" => $row['name'],
                                "email" => $row['email'],
                                "date" => $senddate
                                );
            }
        }

        return $result;
    }
    
        public function mailing_users_info($mailingId)
    {
         $token = uniqid();
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM mailing_users WHERE id = (:mailingId) LIMIT 1");
        $stmt->bindParam(":mailingId", $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

             /**
 *    $profile = new profile($this->db, $row['fromUserId']);
 *                 $profileInfo = $profile->get();
 *                 unset($profile);
 */

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "email" => $row['email'],
                                "name" => $row['name'],
                                "firstname" => $row['firstname'],
                                "username"        => $row['username'],
                      
                                 "token"        => $token,
                                "dbUploaded"        => $row['dbUploaded'],
                                "running"        => $row['running'],
                                "pendingUsersCount" => $this->pendingUsersCount(),
                                "date" => $row['date']
                                );
            }
        }

        return $result;
    }
    
    
 public function mailing_test_users_info($mailingId)
    {
         $token = uniqid();
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM mailing_test_users WHERE id = (:mailingId) LIMIT 1");
        $stmt->bindParam(":mailingId", $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

        /**
 *         $profile = new profile($this->db, $row['fromUserId']);
 *                 $profileInfo = $profile->get();
 *                 unset($profile);
 */
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "email" => $row['email'],
                                "name" => $row['name'],
                                "firstname" => $row['firstname'],
                                "username"        => $row['username'],
                                
                                  "token"        => $token,
                                "dbUploaded"        => $row['dbUploaded'],
                                "running"        => $row['running'],
                                "pendingUsersCount" => $this->pendingTestUsersCount(),
                                "date" => $row['date']
                                );
            }
        }

        return $result;
    }

    public function getChats($itemId = 0)
    {
        if ($itemId == 0) {

            $itemId = $this->getMaxChatId();
            $itemId++;
        }

        $chats = array("error" => false,
                       "error_code" => ERROR_SUCCESS,
                       "itemId" => $itemId,
                       "chats" => array());

        $stmt = $this->db->prepare("SELECT id FROM chats WHERE (fromUserId = (:userId) OR toUserId = (:userId)) AND id < (:itemId) AND removeAt = 0 ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);
        $stmt->bindParam(':userId', $this->requestFrom, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $chatInfo = $this->chatInfo($row['id']);

                array_push($chats['chats'], $chatInfo);

                $chats['itemId'] = $chatInfo['id'];

                unset($chatInfo);
            }
        }

        return $chats;
    }

    public function getNewMessagesCount()
    {
        $count = 0;

        $stmt = $this->db->prepare("SELECT id FROM chats WHERE (fromUserId = (:userId) OR toUserId = (:userId)) AND removeAt = 0 ORDER BY id DESC");
        $stmt->bindParam(':userId', $this->requestFrom, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $chatInfo = $this->chatInfo($row['id']);

                if ($chatInfo['newMessagesCount'] != 0) {

                    $count++;
                }

                unset($chatInfo);
            }
        }

        return $count;
    }

    public function getPreviousMessages($chatId, $mailingId = 0)
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "chatId" => $chatId,
                          "mailingId" => $mailingId,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM mailings WHERE chatId = (:chatId) AND id < (:mailingId) AND removeAt = 0 ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);
        $stmt->bindParam(':mailingId', $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                $mailings['mailingId'] = $mailingInfo['id'];

                unset($mailingInfo);
            }

            $chatInfo = $this->chatInfo($chatId);
        }

        return $mailings;
    }


	public function getNewsletterInfo($mailingId = 0)
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "mailingId" => $mailingId,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM mailing WHERE id = (:mailingId) AND deleted = 0");
        $stmt->bindParam(':mailingId', $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
        }

        return $mailings;
    }
	
    public function getNextMessages($chatId, $mailingId = 0)
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "chatId" => $chatId,
                          "mailingId" => $mailingId,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM mailings WHERE chatId = (:chatId) AND id > (:mailingId) AND removeAt = 0 ORDER BY id ASC");
        $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);
        $stmt->bindParam(':mailingId', $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                $mailings['mailingId'] = $mailingInfo['id'];

                unset($mailingInfo);
            }

            $chatInfo = $this->chatInfo($chatId);

            $profileId = $chatInfo['fromUserId'];

            if ($profileId == $this->getRequestFrom()) {

                $this->setChatLastView_FromId($chatId);

            } else {

                $this->setChatLastView_ToId($chatId);
            }
        }

        return $mailings;
    }


    public function getNewsleterSubscriber()
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM newsletter WHERE deleted = 0 ORDER BY id DESC");
        
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info2($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                $mailings['mailingId'] = $mailingInfo['id'];

                unset($mailingInfo);
            }

        }

        return $mailings;
    }

/**
  * Check if there is any availaible opened newsletter campaign====================================================>
  */ 


    public function get()
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM  mailing WHERE  deleted = 0  ORDER BY id DESC");
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
        }

        return $mailings;
    }
	
/**
  * Check if there is any availaible opened newsletter campaign====================================================>
  */ 


    public function CheckNewsletterSubscribers()
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM  newsletter WHERE  deleted = 0  ORDER BY id DESC LIMIT 30");
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info2($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
        }

        return $mailings;
    }
	
/**
 * start new mailing campaign==========================================================================>
 */
public function StartNewCampaign($pdfId,$FromUserId) {

					$result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
						
		date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
		$campaign_status = 1;
		
        $stmt = $this->db->prepare("INSERT INTO campaigns (campaign_status, campaign_manager, start_date, pdf_id) value (:campaign_status, :campaign_manager, :start_date, :pdf_id)");
        $stmt->bindParam(":campaign_status", $campaign_status, PDO::PARAM_INT);
        $stmt->bindParam(":campaign_manager", $FromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":pdf_id", $pdfId, PDO::PARAM_STR);
        $stmt->bindParam(":start_date", $currentTime, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            'newsletters' => $this->db->lastInsertId(),
                            'suscriber_id'     => $suscriber_id,
                            'error_code'    => ERROR_SUCCESS,
                            'error_description' => 'Subscription Success!');

        }

        return $result;
    }

/**
 * Create new mailing campaign==========================================================================>
 */

    public function create($group='0', $subject="" , $message="")
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($message) == 0 && strlen($message) == 0) {

            return $result;
        }

        
        $currentDate = date("Y-m-d H:i:s");
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO mailing (subject, message, mailing_group, sender, date, ip_addr, u_agent) value (:subject, :message, :mailing_group, :sender, :date, :ip_addr, :u_agent)");
        $stmt->bindParam(":sender", $this->profileId, PDO::PARAM_INT);
        $stmt->bindParam(":subject", $subject, PDO::PARAM_STR);
        $stmt->bindParam(":message", $message, PDO::PARAM_STR);
        $stmt->bindParam(":mailing_group", $group, PDO::PARAM_INT);
        $stmt->bindParam("date", $currentDate, PDO::PARAM_STR);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $mailingId = $this->db->lastInsertId();

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "mailingId" => $mailingId
                            /**
                            * "message" => $this->info($mailingId)
                            */
                            );
        }

        return $result;
    }

	 public function startcampaign($campaignId='0')
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

      
        date_default_timezone_set("Africa/Douala");
        $currentDate = date("Y-m-d H:i:s");
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();
        $campaign_status = 1;

        $stmt = $this->db->prepare("INSERT INTO newsletter_campaign (campaignId, campaign_manager, start_date, 	campaign_status) value (:campaignId, :sender, :date, :campaign_status)");
        $stmt->bindParam(":sender", $this->profileId, PDO::PARAM_INT);
        $stmt->bindParam(":campaignId", $campaignId, PDO::PARAM_INT);
        $stmt->bindParam(":campaign_status", $campaign_status, PDO::PARAM_INT);
        $stmt->bindParam("date", $currentDate, PDO::PARAM_STR);
        

        if ($stmt->execute()) {

            $mailingId = $this->db->lastInsertId();

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "mailingId" => $mailingId
                            /**
                            * "message" => $this->info($mailingId)
                            */
                            );
        }

        return $result;
    }
	
/**
 * ===============Added on march 12/03/2017 ==============================================================================
 */	
	public function SubscribeNewsletter2($email,$name,$group)
    {
		 date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
        $currentTime = $currentTime;
		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
		$table 			= "newsletter";
		
		
        $stmt = $this->db->prepare("INSERT INTO newsletter (email ,name, groups, date) value (:email , :name, :group, :date)");
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":group", $group, PDO::PARAM_STR);
        $stmt->bindParam(":date", $currentTime, PDO::PARAM_STR);
        
        
		$result    = $stmt->execute();
		
        return $result;
    }
	
/**
  * Get mailing template===================================================================================>
  */ 

    public function getmailtemplate()
    {
       
       

        $stmt = $this->db->prepare("SELECT * FROM  mailing_template WHERE  status = 1  ORDER BY id ASC");
        if ($stmt->execute()) {
            
            $row = $stmt->fetch();

             $mailings = array("id" =>$row['id'],
                          "subject" => $row['subject'],
                          "message" => $row['message']
                          );
        }

        return $mailings;
    }

/**
  * Get mailing template===================================================================================>
  */ 

    public function isRunningCampaign()
    {

$mailings = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
        $stmt = $this->db->prepare("SELECT id FROM  mailing WHERE  status = 0 && running =1  ORDER BY id DESC LIMIT 1");
        
         if ($stmt->execute()) {
            
                                $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "runningCampaignCount" => $this->runningCampaign(),
                          "pendingCampaignCount" => $this->pendingCampaign(),
                          "mailings" => array());

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
            


        }

        

        return $mailings;
    }


/**
  * Get mailing template===================================================================================>
  */ 

    public function isPendingCampaign()
    {

$mailings = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
        $stmt = $this->db->prepare("SELECT id FROM  mailing WHERE  status = 0 && running=0  ORDER BY id DESC LIMIT 1");
        
         if ($stmt->execute()) {
            
                $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "runningCampaignCount" => $this->runningCampaign(),
                          "pendingCampaignCount" => $this->pendingCampaign(),
                          "mailings" => array());

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
            
        
        }

        

        return $mailings;
    }
/**
  * Pending Mailing users===================================================================================>
  */ 

    public function isPendingUsers()
    {
        $mailings = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT id FROM  mailing_users WHERE   mailing = 1 && suspended=0 && valid_email=1 && active_mailing = 0 LIMIT 25000");
        
         if ($stmt->execute()) {
            
            $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "pendingUsersCount" => $this->pendingUsersCount(),
                          "mailings" => array());

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->mailing_users_info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
        }

        

        return $mailings;
    }

/**
  * Pending Mailing users===================================================================================>
  */ 

    public function testUsers()
    {
        $mailings = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT id FROM  mailing_test_users  WHERE   mailing = 1 && suspended=0 && valid_email=1 && active_mailing = 0 LIMIT 50");
        
         if ($stmt->execute()) {
            
            $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "pendingUsersCount" => $this->pendingTestUsersCount(),
                          "mailings" => array());

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->mailing_test_users_info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
        }

        

        return $mailings;
    }

/**
  * Newsletter cancellation=========================================================================>
  */ 
    public function unsuscribeToNewsletter($userId=0 , $target='')
    {

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
         if(!empty($target)){
                    $stmt = $this->db->prepare("UPDATE mailing_global_users SET mailing = 0 WHERE id = (:userId)");
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
         }else{
                       $stmt = $this->db->prepare("UPDATE cameroontribune_suscribers SET mailing = 0 WHERE id = (:userId)");
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
         }            

        
       if ($stmt->execute()) {
            
       $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        
        return $result;
    }

/**
  * Table Update=====================================================================================>
  */  
  
  /**
 *  dbUpdate is a fonction for fast pdo DB update
 *  $table = "ah_users";
 * $_POST['password'] = "TITANFACT4";
 * $_POST['id'] = "570";
 * $_POST['currency']="0";
 *  
 * $data  = array(
 *       'password'  => $_POST['password']
 *       
 *       );
 *       
 * $conditions  = array(
 *       'id'  => $_POST['id'],
 *       'currency'  => $_POST['currency']
 *       
 *       );

 * $insert_id = dbUpdate($table , $data , $conditions);
 * echo $insert_id;
 */

public function dbUpdate($table , $data , $conditions){
$fields = "";
$field_conditions = "";
    
     $length = count ($data);
//retrieve data posted
foreach ($data as $field => $value) {
                 $fields   .= $field."=".":".$field. "," ;
}

//retrieve conditions posted
foreach ($conditions as $field_condition => $value_condition) {
                 $field_conditions   .= $field_condition."=".":".$field_condition. " AND " ;
}

//Remove the last coma
                $fields   = rtrim($fields, ",");
                $field_conditions   = rtrim($field_conditions, " AND ");

    
$sth = $this->db->prepare("UPDATE  $table  SET $fields WHERE  $field_conditions");

foreach ($data as $field =>  &$value) {
                
               $sth->bindParam(':'.$field, $value, PDO::PARAM_STR);
}

foreach ($conditions as $field_condition => &$value_condition) {
                
               $sth->bindParam(':'.$field_condition, $value_condition, PDO::PARAM_STR);
}

$sth->execute();

return $sth->execute();
$sth->closeCursor();

}  


/**
 * DB insert allow to insert value into table using PDO connection.
 * For this you need to put all post or value into and array before inserting

 * Sample format:
 * $data  = array(
 *     'username'  => $_POST['username'],
 *     'password'  => $_POST['password'],
 *     'firstname' => $_POST['firstname'],
 *     'lastname' => $_POST['lastname']
 *     
 *     );
 * $table     = "ah_users";
 */


public function dbInsert($table , $data){
    
    $fields ="";
    $field_values="";
    $values="";
     $length = count ($data);
    $fields ="";
    $field_value ="";
    $values ="";
//retrieve data posted
foreach ($data as $field => $value) {
                $fields   .= $field . "," ;
                $field_values   .= ":".$field . "," ;
                $values   .= $value . "," ;
}
//Remove the last coma
                $fields   = rtrim($fields, ",");
                $values = rtrim($values, ",");
                $field_values = rtrim($field_values, ",");

    
$sth = $this->db->prepare("INSERT INTO $table ($fields) VALUES ($field_values)");

foreach ($data as $field =>  &$value) {
                
               $sth->bindParam(':'.$field, $value, PDO::PARAM_STR);
}

$sth->execute();
return $this->db->lastInsertId();
$sth->closeCursor(); 
} 


/**
 * dbFastInsert() is a powerfull and faster option to insert data into a DB using PDO
 * in this case, the only variable to show to function is the TABLE NAME.
 * The fonction use secure prepare to insert your data
 */
public function dbFastInsert($tableName){

//retrieve data posted
      foreach ($_POST as $field => $value) {
                $fields   .= $field . "," ;
    }
//retrieva table colum
$q = $this->db->prepare("DESCRIBE " .  $tableName);
                $q->execute();
                $getFields = $q->fetchAll(PDO::FETCH_COLUMN);
                $dbFieldCount = count( $getFields );
                $tableColums  = implode( ",", $getFields );
           
                //We compare DB colum and Post Field/key            
                $arr1 = explode(",", $tableColums);
                
                $arr2 = explode(",", $fields);
                 
                //We intersec post colum and DB colum
                $array = array_intersect($arr1, $arr2);
                
                //we retrieve post value according to intersec colum and key
                   foreach($array as $k => $v ) {
                     $posted_fields          .= $v.",";
                     $posted_fields_values   .= ":".$v . "," ;
                     $posted[] = $v;
                    }
                    //Remove the last coma
                $posted_fields   = rtrim($posted_fields, ",");
                $posted_fields_values = rtrim($posted_fields_values, ",");
                
                   
                   $sth = $this->db->prepare("INSERT INTO $tableName ($posted_fields) VALUES ($posted_fields_values)");
                 
                 //retrieve intersec post values
                    foreach ($posted as $x =>  &$field) {
                        
                    $value = $_POST[$field];
                    $sth->bindParam(':'.$field, $_POST[$field], PDO::PARAM_STR);
                    
                  }

$sth->execute();
return $this->db->lastInsertId();
$sth->closeCursor();
       }  
    





    public function get2($chatId, $mailingId = 0)
    {
        if ($mailingId == 0) {

            $mailingId = $this->getMaxMessageId();
            $mailingId++;
        }

        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "chatId" => $chatId,
                          "mailingsCount" => $this->mailingsCountByChat($chatId),
                          "mailingId" => $mailingId,
                          "newMessagesCount" => 0,
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM mailings WHERE chatId = (:chatId) AND id < (:mailingId) AND removeAt = 0 ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);
        $stmt->bindParam(':mailingId', $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                $mailings['mailingId'] = $mailingInfo['id'];

                unset($mailingInfo);
            }

            $chatInfo = $this->chatInfo($chatId);

            $profileId = $chatInfo['fromUserId'];

            if ($profileId == $this->getRequestFrom()) {

                $this->setChatLastView_FromId($chatId);

            } else {

                $this->setChatLastView_ToId($chatId);
            }
        }

        $mailings_count = 0;

        $mailing = new mailings($this->db);
        $mailing->setRequestFrom($this->getRequestFrom());

        $mailings_count = $mailing->getNewMessagesCount();

        unset($mailing);


        $mailings['newMessagesCount'] = $mailings_count;

        return $mailings;
    }

    public function getFull($chatId)
    {
        $mailings = array("error" => false,
                          "error_code" => ERROR_SUCCESS,
                          "chatId" => $chatId,
                          "mailingsCount" => $this->mailingsCountByChat($chatId),
                          "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM mailings WHERE chatId = (:chatId) AND removeAt = 0 ORDER BY id ASC");
        $stmt->bindParam(':chatId', $chatId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $mailingInfo = $this->info($row['id']);

                array_push($mailings['mailings'], $mailingInfo);

                unset($mailingInfo);
            }
        }

        return $mailings;
    }

    public function getStream($mailingId = 0, $language = 'en')
    {
        if ($mailingId == 0) {

            $mailingId = $this->getMaxMessageId();
            $mailingId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "mailingId" => $mailingId,
                        "mailings" => array());

        $stmt = $this->db->prepare("SELECT id FROM mailings WHERE id < (:mailingId) AND removeAt = 0 ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':mailingId', $mailingId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $mailingInfo = $this->info($row['id']);

                    array_push($result['mailings'], $mailingInfo);

                    $result['mailingId'] = $row['id'];

                    unset($mailingInfo);
                }
            }
        }

        return $result;
    }

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }
	 public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
