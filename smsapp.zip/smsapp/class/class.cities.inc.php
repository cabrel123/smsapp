<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class cities extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cities");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM cities");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO cities (title, description, imgUrl, createAt, ip_addr, u_agent) value (:title, :description, :imgUrl, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "cityId" => $this->db->lastInsertId(),
                            "city" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }

    public function remove($cityId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $cityInfo = $this->info($cityId);

        if ($cityInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE cities SET removeAt = (:removeAt) WHERE id = (:cityId)");
        $stmt->bindParam(":cityId", $cityId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            //remove all citys

            $stmt3 = $this->db->prepare("SELECT id FROM cars WHERE category = (:category)");
            $stmt3->bindParam(":category", $cityId, PDO::PARAM_INT);

            if ($stmt3->execute()) {

                while ($row = $stmt->fetch()) {

                    $city = new citys($this->db);

                    $city->remove($row['id']);

                    unset($city);
                }
            }

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

            $this->recalculate($cityId);
        }

        return $result;
    }

    public function edit($cityId, $title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }


        $stmt = $this->db->prepare("UPDATE cities SET title = (:title), description = (:description), imgUrl = (:imgUrl) WHERE id = (:cityId)");
        $stmt->bindParam(":cityId", $cityId, PDO::PARAM_INT);
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }

    public function recalculate($categoryId) {

        $citys_count = 0;

        $citys_count = $this->getItemsCount($categoryId);

        $stmt = $this->db->prepare("UPDATE cities SET citysCount = (:citysCount) WHERE id = (:categoryId)");
        $stmt->bindParam(":citysCount", $citys_count, PDO::PARAM_INT);
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->execute();
    }

    private function getItemsCount($categoryId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE category = (:category) AND removeAt = 0");
        $stmt->bindParam(":category", $categoryId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function info($cityId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM cities WHERE id = (:cityId) LIMIT 1");
        $stmt->bindParam(":cityId", $cityId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
                
                $states = new states($this->db);
                $stateInfo = $states->info($row['state_id']);
                unset($states);
                
                $countries = new countries($this->db);
                $countyInfo = $countries->info($stateInfo['country_id']);
                unset($countries);
               
               
                
                $searchName =  $row['name']." , ".$stateInfo['name']." , ".$countyInfo['name'];
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "citysCount" => $row['citysCount'],
                                "name" => htmlspecialchars_decode(stripslashes($row['name'])),
                                "description" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "searchName" => htmlspecialchars_decode(stripslashes($searchName)),
                                "state_id" => $row['state_id'],
                                "createAt" => $row['createAt'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "removeAt" => $row['removeAt'],
                                "stateName" => htmlspecialchars_decode(stripslashes($stateInfo['name'])),
                                "countryId" => $stateInfo['country_id'],
                                "countryName" => htmlspecialchars_decode(stripslashes($countyInfo['name']))
                                );
                                
            }
        }

        return $result;
    }

    public function get($cityId = 0 , $stateId)
    {
        if ($cityId == 0) {

            $cityId = $this->getMaxIdItems();
            $cityId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "cityId" => $cityId,
                        "cities" => array());

        $stmt = $this->db->prepare("SELECT id FROM cities WHERE removeAt = 0 AND state_id = (:state_id) AND id < (:cityId) ORDER BY id DESC LIMIT 40");
        $stmt->bindParam(':cityId', $cityId, PDO::PARAM_INT);
        $stmt->bindParam(':state_id', $stateId, PDO::PARAM_INT);
        

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $cityInfo = $this->info($row['id']);

                array_push($result['cities'], $cityInfo);

                $result['cityId'] = $cityInfo['id'];

                unset($cityInfo);
            }
        }

        return $result;
    }

       public function getCityId($cityName)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "cityName" => $cityName,
                        "cities" => array());

        $stmt = $this->db->prepare("SELECT id FROM cities WHERE  removeAt = 0 AND (LOWER(name) = (:name) OR   name = (:name))");
        $stmt->bindParam(':name', $cityName, PDO::PARAM_INT);
       

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $cityInfo = $this->info($row['id']);

                array_push($result['cities'], $cityInfo);

                $result['cityId'] = $cityInfo['id'];

                unset($cityInfo);
            }
        }

        return $result;
    }

   
    public function getList()
    {
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "citys" => array());

        $stmt = $this->db->prepare("SELECT id FROM cities WHERE removeAt = 0 ORDER BY id");

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $cityInfo = $this->info($row['id']);

                array_push($result['citys'], $cityInfo);

                unset($cityInfo);
            }
        }

        return $result;
    }
    

     public function citiesSearch($queryText = '', $cityId = 0, $limit = 100)
    {
        if ($cityId == 0) {

            $cityId = $this->getMaxIdItems();
            $cityId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "cityId" => $cityId,
                        "cities" => array());
                        
        $queryText = "%".$queryText."%";

        $stmt = $this->db->prepare("SELECT id FROM cities WHERE removeAt = 0 AND (name LIKE (:query) OR state_id LIKE (:query) OR id LIKE (:query))  AND id < (:cityId) ORDER BY id DESC LIMIT :limit");
        $stmt->bindParam(':query',  $queryText, PDO::PARAM_STR);
        $stmt->bindParam(':cityId', $cityId,    PDO::PARAM_INT);
        $stmt->bindParam(':limit',  $limit,     PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $cityInfo = $this->info($row['id']);

                array_push($result['cities'], $cityInfo);

                $result['cityId'] = $cityInfo['id'];

                unset($cityInfo);
            }
        }

        return $result;
    }


     public function citiesSearchWeb($queryText = '', $cityId = 0, $limit = 100)
    {
		  if ($cityId == 0) {

            $cityId = $this->getMaxIdItems();
            $cityId++;
        }
		 $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "cityId" => $cityId,
                        "cities" => array());
		
		$queryTexts = "%".$queryText."%";
		
		$stmt = $this->db->prepare("SELECT id FROM cities WHERE removeAt = 0 AND (name LIKE (:query) OR LOWER(name) LIKE (:query))  AND id < (:cityId) ORDER BY name ASC LIMIT :limit");
        $stmt->bindParam(':query',  $queryTexts, PDO::PARAM_STR);
        $stmt->bindParam(':cityId', $cityId,    PDO::PARAM_INT);
        $stmt->bindParam(':limit',  $limit,     PDO::PARAM_INT);
		    if ($stmt->execute()) {
				$row = $stmt->fetch();
	              
				   while ($row = $stmt->fetch()) {

                $cityInfo = $this->info($row['id']);

                array_push($result['cities'], $cityInfo);

                $result['cityId'] = $cityInfo['id'];
				$result['name']   = $cityInfo['name'];
				$resultname		  = $cityInfo['name'];
				$resultId		  = $cityInfo['id'];
				
				
                unset($cityInfo);
            }
		}
	
		return $result;	
			
    }
    

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
