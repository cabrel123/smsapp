<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class likes extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdLikes()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdlikes()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($countryId= "0" , $stateId= "0" , $cityId= "0" , $makeId= "0" , $modelId= "0", $title, $description, $content, $imgUrl, $previewImgUrl, $allowComments = 1, $price = "0", $incitydailyprice = "0" , $outcitydailyprice = "0" , $incityhourlyprice = "0" , $postArea = "", $postCountry = "", $postCity = "", $postLat = "0.000000", $postLng = "0.000000")
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
                        "error_message" => "erreur",);

        /*if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        if (strlen($content) == 0) {

            return $result;
        }

        if ($category == 0) {

            return $result;
        }

        if ($price == 0) {

            return $result;
        }*/

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO likes (countryId , stateId , cityId , modelId , makeId, allowComments, fromUserId, category,  carDesc, carContent, imgUrl, previewImgUrl, price, incitydailyprice , outcitydailyprice , incityhourlyprice , area, country, city, lat, lng, createAt, ip_addr, u_agent) value (:countryId , :stateId , :cityId , :makeId , :modelId, :allowComments, :fromUserId, :category,  :carDesc, :carContent, :imgUrl, :previewImgUrl, :price, :incitydailyprice , :outcitydailyprice , :incityhourlyprice , :area, :country, :city, :lat, :lng, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":allowComments", $allowComments, PDO::PARAM_INT);
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->bindParam(":category", $makeId, PDO::PARAM_INT);
        $stmt->bindParam(":countryId", $countryId, PDO::PARAM_INT);
        $stmt->bindParam(":stateId", $stateId, PDO::PARAM_INT);
        $stmt->bindParam(":cityId", $cityId, PDO::PARAM_INT);
        $stmt->bindParam(":modelId", $modelId, PDO::PARAM_INT);
        $stmt->bindParam(":makeId", $makeId, PDO::PARAM_INT);
        $stmt->bindParam(":carDesc", $description, PDO::PARAM_STR);
        $stmt->bindParam(":carContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":previewImgUrl", $previewImgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":price", $price, PDO::PARAM_STR);
        $stmt->bindParam(":incitydailyprice", $incitydailyprice, PDO::PARAM_STR);
        $stmt->bindParam(":outcitydailyprice", $outcitydailyprice, PDO::PARAM_STR);
        $stmt->bindParam(":incityhourlyprice", $incityhourlyprice , PDO::PARAM_STR);
        $stmt->bindParam(":area", $postArea, PDO::PARAM_STR);
        $stmt->bindParam(":country", $postCountry, PDO::PARAM_STR);
        $stmt->bindParam(":city", $postCity, PDO::PARAM_STR);
        $stmt->bindParam(":lat", $postLat, PDO::PARAM_STR);
        $stmt->bindParam(":lng", $postLng, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "carId" => $this->db->lastInsertId(),
                            "car" => $this->info($this->db->lastInsertId()));

            if ($this->requestFrom != 0) {

                $account = new account($this->db, $this->requestFrom);
                $account->updateCounters();
                unset($account);
            }

            if ($category != 0) {

                $cat = new categories($this->db);
                $cat->recalculate($category);
                unset($cat);
            }
        }

        return $result;
    }

    public function deleteAllByUserId($userId)
    {
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(':fromUserId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $this->remove($row['id']);
            }
        }
    }

    public function remove($carId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $carInfo = $this->info($carId);

        if ($carInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE id = (:carId)");
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            // remove all notifications by likes and comments

            $stmt2 = $this->db->prepare("DELETE FROM notifications WHERE carId = (:carId)");
            $stmt2->bindParam(":carId", $carId, PDO::PARAM_INT);
            $stmt2->execute();

            //remove all comments to car

            $stmt3 = $this->db->prepare("UPDATE comments SET removeAt = (:removeAt) WHERE carId = (:carId)");
            $stmt3->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt3->bindParam(":carId", $carId, PDO::PARAM_INT);
            $stmt3->execute();

            //remove all likes to car

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE carId = (:carId) AND removeAt = 0");
            $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt->execute();

            $cat = new categories($this->db);
            $cat->recalculate($carInfo['category']);

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        $this->recalculate($carId);

        return $result;
    }

    public function restore($carId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $carInfo = $this->info($carId);

        if ($carInfo['error'] === true) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE likes SET removeAt = 0 WHERE id = (:carId)");
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function edit($carId, $category, $title, $imgUrl, $content, $allowComments, $price)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        if (strlen($content) == 0) {

            return $result;
        }

        if ($category == 0) {

            return $result;
        }

        if ($price == 0) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE likes SET allowComments = (:allowComments), category = (:category), carTitle = (:carTitle), carContent = (:carContent), imgUrl = (:imgUrl), price = (:price), moderatedAt = 0, moderatedId = 0 WHERE id = (:carId)");
        $stmt->bindParam(":allowComments", $allowComments, PDO::PARAM_INT);
        $stmt->bindParam(":category", $category, PDO::PARAM_INT);
        $stmt->bindParam(":carTitle", $title, PDO::PARAM_STR);
        $stmt->bindParam(":carContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
        $stmt->bindParam(":price", $price, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function like($carId, $fromUserId)
    {
        $account = new account($this->db, $fromUserId);
        $account->setLastActive();
        unset($account);

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $carInfo = $this->info($carId);

        if ($carInfo['error'] === true) {

            return $result;
        }

        if ($carInfo['removeAt'] != 0) {

            return $result;
        }

        if ($this->is_like_exists($carId, $fromUserId)) {

            $removeAt = time();

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE carId = (:carId) AND fromUserId = (:fromUserId) AND removeAt = 0");
            $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
            $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $removeAt, PDO::PARAM_INT);
            $stmt->execute();

            $notify = new notify($this->db);
            $notify->removeNotify($carInfo['fromUserId'], $fromUserId, NOTIFY_TYPE_LIKE, $carId);
            unset($notify);

        } else {

            $createAt = time();
            $ip_addr = helper::ip_addr();

            $stmt = $this->db->prepare("INSERT INTO likes (toUserId, fromUserId, carId, createAt, ip_addr) value (:toUserId, :fromUserId, :carId, :createAt, :ip_addr)");
            $stmt->bindParam(":toUserId", $carInfo['fromUserId'], PDO::PARAM_INT);
            $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
            $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
            $stmt->bindParam(":createAt", $createAt, PDO::PARAM_INT);
            $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
            $stmt->execute();
        }


        $this->recalculate($carId);

        $car_info = $this->info($carId);


        if ($car_info['fromUserId'] != $this->requestFrom) {

            $account = new account($this->db, $car_info['fromUserId']);
            $account->updateCounters();
            unset($account);
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likesCount" => $car_info['likesCount'],
                        "myLike" => $car_info['myLike']);

        return $result;
    }

    private function getLikesCount($carId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE carId = (:carId) AND removeAt = 0");
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function is_like_exists($carId, $fromUserId)
    {
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND carId = (:carId) AND removeAt = 0 LIMIT 1");
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            return true;
        }

        return false;
    }

    public function recalculate($carId) {

        $comments_count = 0;
        $likes_count = 0;
        $rating = 0;
        $images_count = 0;

        $modifyAt = time();

        $likes_count = $this->getLikesCount($carId);

        $comments = new comments($this->db);
        $comments_count = $comments->count($carId);
        unset($comments);

        $images = new images($this->db);
        $images_count = $images->count($carId);
        unset($images);

        $rating = $likes_count + $comments_count;

        $stmt = $this->db->prepare("UPDATE likes SET imagesCount = (:imagesCount), likesCount = (:likesCount), commentsCount = (:commentsCount), rating = (:rating), modifyAt = (:modifyAt) WHERE id = (:carId)");
        $stmt->bindParam(":imagesCount", $images_count, PDO::PARAM_INT);
        $stmt->bindParam(":likesCount", $likes_count, PDO::PARAM_INT);
        $stmt->bindParam(":commentsCount", $comments_count, PDO::PARAM_INT);
        $stmt->bindParam(":rating", $rating, PDO::PARAM_INT);
        $stmt->bindParam(":modifyAt", $modifyAt, PDO::PARAM_INT);
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);
        $stmt->execute();

        $account = new account($this->db, $this->requestFrom);
        $account->updateCounters();
        unset($account);
    }

    public function info($carId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM likes WHERE id = (:carId) LIMIT 1");
        $stmt->bindParam(":carId", $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $myLike = false;

                if ($this->requestFrom != 0) {

                    if ($this->is_like_exists($carId, $this->requestFrom)) {

                        $myLike = true;
                    }
                }

                if ($row['fromUserId'] != 0) {

                    $profile = new profile($this->db, $row['fromUserId']);
                    $profileInfo = $profile->get();
                    unset($profile);

                } else {

                    $profileInfo = array("username" => "",
                                         "fullname" => "",
                                         "lowPhotoUrl" => "");
                }

                $category = new categories($this->db);
                $categoryInfo = $category->info($row['category']);
                unset($category);
				
				$cities = new cities($this->db);
                $citiesInfo = $cities->info($row['cityId']);
                unset($cities);
				
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "category" => $row['category'],
                                "price" => $row['price'],
                                "categoryTitle" => $categoryInfo['title'],
                                "cityName" => $citiesInfo['name'],
                                "fromUserId" => $row['fromUserId'],
                                "fromUserUsername" => $profileInfo['username'],
                                "fromUserFullname" => $profileInfo['fullname'],
                                "fromUserPhone" => $profileInfo['phone'],
                                "fromUserPhoto" => $profileInfo['lowPhotoUrl'],
                                "carTitle" => htmlspecialchars_decode(stripslashes($row['carTitle'])),
                                "carDesc" => htmlspecialchars_decode(stripslashes($row['carDesc'])),
                                "carContent" => stripslashes($row['carContent']),
                                "area" => htmlspecialchars_decode(stripslashes($row['area'])),
                                "country" => htmlspecialchars_decode(stripslashes($row['country'])),
                                "city" => htmlspecialchars_decode(stripslashes($row['city'])),
                                "lat" => $row['lat'],
                                "lng" => $row['lng'],
                                 "incitydailyprice" => $row['incitydailyprice'],
                                "outcitydailyprice" => $row['outcitydailyprice'],
                                "incityhourlyprice" => $row['incityhourlyprice'],
                                
                                "previewImgUrl" => $row['previewImgUrl'],
                                "imgUrl" => $row['imgUrl'],
                                "allowComments" => $row['allowComments'],
                                "rating" => $row['rating'],
                                "commentsCount" => $row['commentsCount'],
                                "likesCount" => $row['likesCount'],
                                "myLike" => $myLike,
                                "createAt" => $row['createAt'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "timeAgo" => $time->timeAgo($row['createAt']),
                                "removeAt" => $row['removeAt']);
            }
        }

        return $result;
    }

    public function get($profileId, $carId = 0)
    {
        if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0 AND id < (:carId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
        public function getAlllikes($carId=0 , $cityName=0)
    {
        
         //Retrieve city id ;  getCityId($cityName
         $cities   = new cities($this->db);
         $cityInfo = $cities->getCityId($cityName);
         unset($cities);
         $cityId   = $cityInfo['cityId'];
        
        if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());
        if(!empty($cityId)){
            $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND cityId = (:cityId) AND id < (:carId)  ORDER BY id DESC LIMIT 20");
            $stmt->bindParam(':cityId', $cityId, PDO::PARAM_INT);
            $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);
        }else{
            $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id < (:carId)  ORDER BY id DESC LIMIT 20");
           //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
            $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);
        }
        

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
        public function getAlllikesExist($carId=0, $limit)
    {
        if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id < (:carId)  ORDER BY id DESC LIMIT $limit");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }

        return $result;
    }
	
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
        public function getInfoslikes($carId)
    {
         if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id = (:carId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on 08/05/2017 bt TFM==============================================================================
 */
        public function getUsercar($accountId)
    {
         if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        } 
	//$accountId = 52180;
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND fromUserId = (:accountId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':accountId', $accountId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }

        return $result;
    }	
	
/**
 * ===============Added on 03/05/2017 bt TFM==============================================================================
 */
        public function getAllOrdersAboutUser($user_id)
    {
         
        $stmt = $this->db->prepare("SELECT * FROM orders WHERE  removeAt = 0 AND fromUserId = (:user_id)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        $result = $stmt->execute();

        return $result;
    }
	
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
  public function getLastlikes($carId=0)
    {
         if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id < (:carId) ORDER BY id DESC LIMIT 1");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }

        return $result;
    }


/**
 * ===============Added on april 15/05/2017 bt TFM==============================================================================
 */
        public function getWhishlistUser($accountId)
    {
         
 if ($carId == 0) {

            $carId = $this->getMaxIdlikes();
            $carId++;
        } 
	$accountId = 52225;
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT DISTINCT carId FROM likes WHERE toUserId = (:accountId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':accountId', $accountId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $carInfo = $this->info($row['id']);

                array_push($result['likes'], $carInfo);

                $result['carId'] = $carInfo['id'];

                unset($carInfo);
            }
        }
        return $result;
    }
	
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
