<?php

class logs extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

	
/***************************** Fonction pour avoir l'id le plus grand de la table logs ************************/
    private function getMaxIdlogs()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM logs");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

// count all users	
	public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM logs WHERE removeAt = 0");
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
// count all users	
	public function getCountRecentLogs()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM logs WHERE removeAt = 0 AND type != 2 AND DATE(createAt) = DATE(NOW()) ORDER BY createAt DESC");
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
// count all users	
	public function getCountTransactionFailed($accountId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM logs WHERE removeAt = 0 AND FromUserId = (:accountId) AND type = 1 AND status = 1 ");
		$stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }	
// count all users	
	public function getCountAccountCreateFailed($accountId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM logs WHERE removeAt = 0 AND FromUserId = (:accountId) AND type = 7 AND status = 1 ");
		$stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }	
/***************************** Fonction pour ajouter un nouveau logs *********************************/	
    public function add($FromUserId,$action,$logstype,$statut,$schoolid)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

		
		if (strlen($FromUserId) == 0) {

            return $result;
        }

		date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
       
		
		// appel de la classe helper pour avoir le ip address et le fingerprint de la machine
        $u_agent = helper::u_agent();
        $ip_addr = helper::ip_addr();
		
        $stmt = $this->db->prepare("INSERT INTO logs (FromUserId, action, type,status,schoolid, createAt, u_agent, ip_addr) value (:FromUserId, :action, :type, :statut, :schoolid, :createAt, :u_agent, :ip_addr)");
        $stmt->bindParam(":FromUserId", $FromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":statut", $statut, PDO::PARAM_INT);
        $stmt->bindParam(":type", $logstype, PDO::PARAM_INT);
        $stmt->bindParam(":schoolid", $schoolid, PDO::PARAM_INT);
        $stmt->bindParam(":action", $action, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
		$stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "logId" => $this->db->lastInsertId(),
                            "logs" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }
/***************************** Fonction pour ajouter un nouveau logs *********************************/	
    public function setUserLogs($clientBrowserFingerPrint, $FromUserId,$pageUrl,$timeonpage,$pageType,$pageId)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

		
		if (strlen($clientBrowserFingerPrint) == 0) {

            return $result;
        }

		date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
       
		
		// appel de la classe helper pour avoir le ip address et le fingerprint de la machine
        $u_agent = helper::u_agent();
        $ip_addr = helper::ip_addr();
		
        $stmt = $this->db->prepare("INSERT INTO userlogs (FromUserId, fingerprint,pageUrl,timeonpage,pageType,pageId, createAt, u_agent, ip_addr) value (:FromUserId, :fingerprint, :pageUrl, :timeonpage, :pageType, :pageId, :createAt, :u_agent, :ip_addr)");
        $stmt->bindParam(":FromUserId", $FromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":fingerprint", $clientBrowserFingerPrint, PDO::PARAM_STR);
        $stmt->bindParam(":pageUrl", $pageUrl, PDO::PARAM_STR);
        $stmt->bindParam(":timeonpage", $timeonpage, PDO::PARAM_STR);
        $stmt->bindParam(":pageType", $pageType, PDO::PARAM_STR);
        $stmt->bindParam(":pageId", $pageId, PDO::PARAM_INT);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
		$stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "logId" => $this->db->lastInsertId(),
                            "logs" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }
/***************************** Fonction pour supprimer (désactiver) un logs *********************************/	
    public function remove($logsId)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $itemInfo = $this->info($logsId);

        if ($itemInfo['error'] === true) {

            return $result;
        }
		
        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE logs SET removeAt = (:removeAt) WHERE id = (:logsId)");
        $stmt->bindParam(":logsId", $logsId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }
/*
|------------------------------------------------------------------------------
| cron job of reactivating block accounts
|------------------------------------------------------------------------------
*/	
public function cronjobofreactivatingblockaccounts($accountId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur vérification");

        $stmt = $this->db->prepare("SELECT COUNT(FromUserId) FROM logs WHERE type = 1 AND status = 1 AND FromUserId = (:accountId) AND removeAt = 0");
        $stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
		$stmt->execute();

        $number_of_rows = $stmt->fetchColumn();
		if($number_of_rows == NULL){
			return 0;
		}else{
			return $number_of_rows;
		}
    }
/*
|------------------------------------------------------------------------------
| Reactivate account
|------------------------------------------------------------------------------
*/	
public function updatelog($logId,$accountId,$statut)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
						"error_description" => "Erreur de mise à jour");

		
        $stmt = $this->db->prepare("UPDATE logs SET status = (:statut) WHERE FromUserId = (:accountId) AND id = (:logId) ");
        $stmt->bindParam(":logId", $logId, PDO::PARAM_INT);
        $stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
        $stmt->bindParam(":statut", $statut, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
						"profileId" => $accountId);
        }


        return $result;
    }
/***************************** fonction pour avoir les infos d'un logs *********************************/
    public function info($logsId)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM logs WHERE id = (:logsId) LIMIT 1");
        $stmt->bindParam(":logsId", $logsId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				
				$profile = new profile($this->db, $row['FromUserId']);
                $profileInfo = $profile->get();
                unset($profile);
 setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
$date = strftime(" %d %h %Y %H:%M",strtotime($row['createAt']));
				//on rempli le tableau result
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "status" => $row['status'],
                                "type" => $row['type'],
                                "logsName" => htmlspecialchars_decode(stripslashes($row['action'])),
                                "FromUserFirstName" => $profileInfo['fullname'],
                                "studentLastName" => $profileInfo['lastname'],
                                "createAt" => $row['createAt'],
                                "date" => $date,
                                "removeAt" => $row['removeAt']);
            }
        }

        return $result;
    }

/***************************** fonction pour parcourir la table logs *********************************/
    public function get($logsId = 0, $schoolid)
    {
        if ($logsId == 0) {

            $logsId = $this->getMaxIdlogs();
            $logsId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "logsId" => $logsId,
                        "logs" => array());

        $stmt = $this->db->prepare("SELECT id FROM logs WHERE removeAt = 0 AND id < (:logsId) AND schoolid = (:schoolid) ORDER BY id DESC");
        $stmt->bindParam(':logsId', $logsId, PDO::PARAM_INT);
        $stmt->bindParam(':schoolid', $schoolid, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {
				//appel de la fonction info
                $itemInfo = $this->info($row['id']);
				
                array_push($result['logs'], $itemInfo);

                $result['logsId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
/***************************** fonction pour parcourir la table logs *********************************/
    public function getRecentLogs($logsId = 0, $schoolid)
    {
        if ($logsId == 0) {

            $logsId = $this->getMaxIdlogs();
            $logsId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "logsId" => $logsId,
                        "logs" => array());

        $stmt = $this->db->prepare("SELECT id FROM logs WHERE removeAt = 0 AND id < (:logsId) AND schoolid = (:schoolid) ORDER BY id DESC LIMIT 5");
        $stmt->bindParam(':logsId', $logsId, PDO::PARAM_INT);
        $stmt->bindParam(':schoolid', $schoolid, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {
				//appel de la fonction info
                $itemInfo = $this->info($row['id']);
				
                array_push($result['logs'], $itemInfo);

                $result['logsId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
/***************************** fonction pour sélectionner un logs par id *********************************/	
	 public function getlogsById($logsId = 0)
    {
        if ($logsId == 0) {

            $logsId = $this->getMaxIdlogs();
            $logsId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "logsId" => $logsId,
                        "logs" => array());

        $stmt = $this->db->prepare("SELECT id FROM logs WHERE removeAt = 0 AND id = (:logsId)");
        $stmt->bindParam(':logsId', $logsId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['logs'], $itemInfo);

                $result['logsId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }

	
/***************************** fonctions pour les fichiers de traduction *********************************/
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

/***************************** fonctions pour tracer l'activité d'un utilisateur sur la table logs *********************************/
    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
