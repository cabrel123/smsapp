<?php

/**************************************************************** *
 * arsel.cm engine v1.0                       					  *
 *                                                                *
 * ALLURE                                            	  		  *
 * admin@allure.com                             				  *
 *                                                                *
 * Copyright 2021 BEYALA BEATRICE CEO ALLURE					  *
 ******************************************************************
 */

class contact extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM contact WHERE deleted=''");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM contact");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	 private function getMaxIdItems2()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM petitions");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	public function sendcontactform($name="" , $subject="" , $email="" , $phone="", $message="")
    {
		date_default_timezone_set("Africa/Douala");
$date = date("Y-m-d H:i:s");

		
        $result = array("error" => true,
                        "name" => $name,
                        "subject" => $subject,
                        "email" => $email,
                        "phone" => $phone,
                        "message" => $message,
                        "error_description" => "une erreur s'est produite",
                        "error_code" => ERROR_UNKNOWN);
		
        $stmt = $this->db->prepare("INSERT INTO contact (name , subject, email , phone, message, received_date) value (:name , :subject , :email, :phone , :message , :date)");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":subject", $subject, PDO::PARAM_STR);
        $stmt->bindParam(":phone", $phone, PDO::PARAM_STR);
        $stmt->bindParam(":message", $message, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $msgId = $this->db->lastInsertId();

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "contact" => $this->info($msgId));
        }
		
        return $result;
    }
	
	public function SignPetition($name, $email, $phone, $city, $country)
    {
		date_default_timezone_set("Africa/Douala");
$date = date("Y-m-d H:i:s");

		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
						
		$ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();
		
        $stmt = $this->db->prepare("INSERT INTO petitions (name, email, phone, city, country , received_date, ip_addr, u_agent) value (:name , :email , :phone, :city, :country, :date , :ip_addr , :u_agent)");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":city", $city, PDO::PARAM_STR);
        $stmt->bindParam(":country", $country, PDO::PARAM_STR);
        $stmt->bindParam(":phone", $phone, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }
		
        return $result;
    }
	
	
		
	public function Addmember($name , $address , $email , $phone, $message, $type)
    {
		date_default_timezone_set("Africa/Douala");
$date = date("Y-m-d H:i:s");

		
        $result = array("error" => true,
                        "error_description" => "INSERT INTO members (name , address, email , phone, message, received_date, type) value ('$name' , '$address' , '$email', '$phone' , '$message' , '$date', '$type')",
                        "error_code" => ERROR_UNKNOWN);
		
        $stmt = $this->db->prepare("INSERT INTO members (name , address, email , phone, message, received_date, type) value (:name , :address , :email, :phone , :message , :date, :type)");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":address", $address, PDO::PARAM_STR);
        $stmt->bindParam(":phone", $phone, PDO::PARAM_STR);
        $stmt->bindParam(":message", $message, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        $stmt->bindParam(":type", $type, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $msgId = $this->db->lastInsertId();

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "contact" => $this->info($msgId));
        }
		
        return $result;
    }
	
	
    public function remove($contactId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $itemInfo = $this->info($catId);

        if ($itemInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE contact SET deleted = (:deleted) WHERE id = (:contactId)");
        $stmt->bindParam(":contactId", $contactId, PDO::PARAM_INT);
        $stmt->bindParam(":deleted", $currentTime, PDO::PARAM_INT);

		$stmt->execute();

        return $result;
    }

    public function edit($itemId, $title, $description)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

       

        $stmt = $this->db->prepare("UPDATE contact SET title_contact = (:title), description = (:description) WHERE id = (:itemId)");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }

    public function recalculate($contactId) {

        $items_count = 0;

        $items_count = $this->getItemsCount($contactId);

        $stmt = $this->db->prepare("UPDATE contact SET itemsCount = (:itemsCount) WHERE id = (:contactId)");
        $stmt->bindParam(":itemsCount", $items_count, PDO::PARAM_INT);
        $stmt->bindParam(":contactId", $contactId, PDO::PARAM_INT);
        $stmt->execute();
    }

    private function getItemsCount($contactId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE contact = (:contact) AND deleted = 0");
        $stmt->bindParam(":contact", $contactId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function info($itemId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM contact WHERE id = (:itemId) LIMIT 1");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				$senddate = strftime(" %d %h %Y",strtotime($row['received_date']));

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "status" => $row['status'],
                                "receivedAt" => $senddate,
                                "FromUsername" => htmlspecialchars_decode(stripslashes($row['name'])),
                                "FromUseremail" => htmlspecialchars_decode(stripslashes($row['email'])),
                                "FromUserphone" => htmlspecialchars_decode(stripslashes($row['phone'])),
                                "subject" => htmlspecialchars_decode(stripslashes($row['subject'])),
                                "message" => htmlspecialchars_decode(stripslashes($row['message'])),
                                "deleted" => $row['deleted']);
            }
        }

        return $result;
    }


    public function petitionsInfo($itemId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM petitions WHERE id = (:itemId) LIMIT 1");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				$senddate = strftime(" %d %h %Y",strtotime($row['received_date']));

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "date" => $senddate,
                                "name" => htmlspecialchars_decode(stripslashes($row['name'])),
                                "email" => htmlspecialchars_decode(stripslashes($row['email'])),
                                "phone" => htmlspecialchars_decode(stripslashes($row['phone'])),
                                "city" => htmlspecialchars_decode(stripslashes($row['city'])),
                                "country" => htmlspecialchars_decode(stripslashes($row['country'])),
                                "deleted" => $row['deleted']);
            }
        }

        return $result;
    }
	
    public function get($itemId = 0)
    {
        if ($itemId == 0) {

            $itemId = $this->getMaxIdItems();
            $itemId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "itemId" => $itemId,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM contact WHERE deleted = 0 AND id < (:itemId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['items'], $itemInfo);

                $result['itemId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }

    public function getPetitions($itemId = 0)
    {
        if ($itemId == 0) {

            $itemId = $this->getMaxIdItems2();
            $itemId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "itemId" => $itemId,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM petitions WHERE deleted = 0 AND id < (:itemId) ORDER BY id DESC");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->petitionsInfo($row['id']);

                array_push($result['items'], $itemInfo);

                $result['itemId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
