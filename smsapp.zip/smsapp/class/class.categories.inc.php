<?php
/**************************************************************** *
 * SMSAPP engine v1.0        					  				  *
 *                                                                *
 * 						                                          *
 * monkamcabrel11@gmail.com                             		  *
 *                                                                *
 * Copyright 2023 MONKAM CABREL									  *
 ******************************************************************
 */

class categories extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM categories");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM categories");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

/**
 * ===============Fonction pour Vérifier si une categorie existe==============================================================================
*/
	public function CheckIfcategoriesExist($name)
    {
		//initialisation du tableau result
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM categories WHERE title = (:name) AND deleted = '' ORDER BY id");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
		$stmt->execute();
        return $number_of_rows = $stmt->fetchColumn();
    }
/**
 * ===============Fonction pour ajouter une nouvelle catégorie==============================================================================
*/
    public function add($title,  $description)
    {
        $result = array("error" => true,
                        "title" => $title,
                        "description" => $description,
                        "error_code" => ERROR_UNKNOWN);

       
        date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO categories (title, description, ip_addr, u_agent) value (:title, :description, :ip_addr, :u_agent)");
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
		$stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "itemId" => $this->db->lastInsertId(),
                            "item" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }
/**
 * ===============Fonction pour supprimer une catégorie==============================================================================
*/
    public function remove($catId,$delete_by)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $itemInfo = $this->info($catId);

        if ($itemInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE category SET deleted = (:deleted), delete_by = (:delete_by) WHERE id = (:catId)");
        $stmt->bindParam(":catId", $catId, PDO::PARAM_INT);
        $stmt->bindParam(":delete_by", $delete_by, PDO::PARAM_INT);
        $stmt->bindParam(":deleted", $currentTime, PDO::PARAM_INT);

		$stmt->execute();

        return $result;
    }

/**
 * ===============Fonction pour avoir les infos sur une categorie==============================================================================
*/
    public function info($itemId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM categories WHERE id = (:itemId) LIMIT 1");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "title" => htmlspecialchars_decode(stripslashes($row['title'])),
                                "description" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "removeAt" => $row['removeAt']);
            }
        }

        return $result;
    }

/**
 * ===============Fonction pour récupérer toutes les catégories==============================================================================
 */
    public function get($itemId = 0)
    {
			
        if ($itemId == 0) {

            $itemId = $this->getMaxIdItems();
            $itemId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "itemId" => $itemId,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM categories WHERE removeAt = 0 AND id < (:itemId) ORDER BY id DESC");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['items'], $itemInfo);

                $result['itemId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }

}
