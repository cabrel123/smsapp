<?php

/**************************************************************** *
 * inovtech.net engine v1.0                                       *
 *                                                                *
 * Secure Software Development and Cyber Securoty Provider        *
 * admin@inovtech.net                                             *
 *                                                                *
 * Copyright 2019 Francois Modeste CEO INOVTECH                   *
 ******************************************************************/

class helper extends db_connect
{

    public function __construct($dbo = NULL)
    {
        parent::__construct($dbo);
    }

    static function isValidURL($url) {

        return preg_match('|^(http(s)?://)?[a-z0-9-]+\.(.[a-z0-9-]+)+(:[0-9]+)?(/.*)?$|i', $url);
    }

    static function truncate($str, $len)
    {
        $tail = max(0, $len-10);
        $trunk = substr($str, 0, $tail);
        $trunk .= strrev(preg_replace('~^..+?[\s,:]\b|^...~', '...', strrev(substr($str, $tail, $len-$tail))));

        return $trunk;
    }

    static function createMsgClickableLinks($matches)
    {
        $title = $face = $matches[0];

        $face = helper::truncate($face, 50);

        $matches[0] = str_replace( "www.", "http://www.", $matches[0] );
        $matches[0] = str_replace( "http://http://www.", "http://www.", $matches[0] );
        $matches[0] = str_replace( "https://http://www.", "https://www.", $matches[0] );

        return "<a title=\"$title\" class=\"posted_link\" target=\"_blank\" href=$matches[0]>$face</a>";
    }

    static function processMsgText($text)
    {
        $text = preg_replace_callback('@(?<=^|(?<=[^a-zA-Z0-9-_\.//]))((https?://)?([-\w]+\.[-\w\.]+)+\w(:\d+)?(/([-\w/_\.\,]*(\?\S+)?)?)*)@', "helper::createMsgClickableLinks", $text);

        return $text;
    }

    public function getUserLogin($accountId)
    {
        $stmt = $this->db->prepare("SELECT login FROM users WHERE id = (:id) LIMIT 1");
        $stmt->bindParam(":id", $accountId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch();

            return $row['login'];
        }

        return 0;
    }

    public function getUserPhoto($accountId)
    {
        $stmt = $this->db->prepare("SELECT lowPhotoUrl FROM users WHERE id = (:id) LIMIT 1");
        $stmt->bindParam(":id", $accountId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch();

            if (strlen($row['lowPhotoUrl']) == 0) {

                return "/img/profile_default_photo.png";

            } else {

                return $row['lowPhotoUrl'];
            }
        }

        return "/img/profile_default_photo.png";
    }

    public function getUserId($username)
    {
        $username = helper::clearText($username);
        $username = helper::escapeText($username);

        $stmt = $this->db->prepare("SELECT id FROM users WHERE login = (:username) LIMIT 1");
        $stmt->bindParam(":username", $username, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch();

            return $row['id'];
        }

        return 0;
    }

    public function getUserIdByFacebook($fb_id)
    {
        $fb_id = helper::clearText($fb_id);
        $fb_id = helper::escapeText($fb_id);

        $stmt = $this->db->prepare("SELECT id FROM users WHERE fb_id = (:fb_id) LIMIT 1");
        $stmt->bindParam(":fb_id", $fb_id, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch();

            return $row['id'];
        }

        return 0;
    }

    public function getUserIdByEmail($email)
    {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE email = (:email) LIMIT 1");
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch();

            return $row['id'];
        }

        return 0;
    }

    public function getRestorePoint($hash)
    {
        $hash = helper::clearText($hash);
        $hash = helper::escapeText($hash);

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM restore_data WHERE hash = (:hash) AND removeAt = 0 LIMIT 1");
        $stmt->bindParam(":hash", $hash, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch();

            $result = array('error'=> false,
                            'error_code' => ERROR_SUCCESS,
                            'accountId' => $row['accountId'],
                            'hash' => $row['hash'],
                            'email' => $row['email']);
        }

        return $result;
    }

    public function isEmailExists($user_email)
    {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE email = (:email) LIMIT 1");
        $stmt->bindParam(':email', $user_email, PDO::PARAM_STR);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                return true;
            }
        }

        return false;
    }

    public function isLoginExists($username)
    {
        if (file_exists("../html/page.".$username.".inc.php")) {

            return true;
        }

        $username = helper::clearText($username);
        $username = helper::escapeText($username);

        $stmt = $this->db->prepare("SELECT id FROM users WHERE login = (:username) LIMIT 1");
        $stmt->bindParam(":username", $username, PDO::PARAM_STR);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                return true;
            }
        }

        return false;
    }

    static function getContent($url_address) {

        if (function_exists('curl_init') && function_exists('curl_setopt') && function_exists('curl_exec') && function_exists('curl_exec')) {

            $curl = curl_init($url_address);

            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($curl, CURLOPT_TIMEOUT, 5);

            $result = @curl_exec($curl);

            curl_close($curl);

        } else {

            ini_set('default_socket_timeout', 5);

            $result = @file_get_contents($url_address);
        }

        return $result;
    }

    static function isCorrectFullname($fullname)
    {
        if (strlen($fullname) > 0) {

            return true;
        }

        return false;
    }

    static function isCorrectLogin($username)
    {
        //if (preg_match("/^([a-zA-Z]{4,24})?([a-zA-Z][a-zA-Z0-9_]{4,24})$/i", $username)) {
		if (preg_match('/^[a-zA-Z0-9_]{6,20}$/i', $username)) {
            return true;
        }

        return false;
    }
	
	 static function isCorrectLogin2($username)
    {
        if (preg_match("/^([a-zA-Z]{4,24})?([a-zA-Z][a-zA-Z0-9_]{4,24})$/i", $username)) {
		//if (preg_match('/^[a-zA-Z0-9_]{6,20}$/i', $username)) {
            return true;
        }

        return false;
    }

    static function isCorrectPassword($password)
    {

        if (preg_match('/^[a-z0-9_]{6,20}$/i', $password)) {

            return true;
        }

        return false;
    }

    static function isCorrectEmail($email)
    {
        if (preg_match('/[0-9a-z_-]+@[-0-9a-z_^\.]+\.[a-z]{2,3}/i', $email)) {

            return true;
        }

        return false;
    }
static function replace_accents($string)
{
  return str_replace( array('ÃƒÂ ','ÃƒÂ¡','ÃƒÂ¢','ÃƒÂ£','ÃƒÂ¤', 'ÃƒÂ§', 'ÃƒÂ¨','ÃƒÂ©','ÃƒÂª','ÃƒÂ«', 'ÃƒÂ¬','ÃƒÂ­','ÃƒÂ®','ÃƒÂ¯', 'ÃƒÂ±', 'ÃƒÂ²','ÃƒÂ³','ÃƒÂ´','ÃƒÂµ','ÃƒÂ¶', 'ÃƒÂ¹','ÃƒÂº','ÃƒÂ»','ÃƒÂ¼', 'ÃƒÂ½','ÃƒÂ¿', 'Ãƒâ‚¬','ÃƒÂ','Ãƒâ€š','ÃƒÆ’','Ãƒâ€ž', 'Ãƒâ€¡', 'ÃƒË†','Ãƒâ€°','ÃƒÅ ','Ãƒâ€¹', 'ÃƒÅ’','ÃƒÂ','ÃƒÅ½','ÃƒÂ', 'Ãƒâ€˜', 'Ãƒâ€™','Ãƒâ€œ','Ãƒâ€','Ãƒâ€¢','Ãƒâ€“', 'Ãƒâ„¢','ÃƒÅ¡','Ãƒâ€º','ÃƒÅ“', 'ÃƒÂ'), array('a','a','a','a','a', 'c', 'e','e','e','e', 'i','i','i','i', 'n', 'o','o','o','o','o', 'u','u','u','u', 'y','y', 'A','A','A','A','A', 'C', 'E','E','E','E', 'I','I','I','I', 'N', 'O','O','O','O','O', 'U','U','U','U', 'Y'), $string);
} 
static function suppr_accents($str, $encoding='utf-8')
{
    // transformer les caractères accentués en entités HTML
    $str = htmlentities($str, ENT_NOQUOTES, $encoding);
 
    // remplacer les entités HTML pour avoir juste le premier caractères non accentués
    // Exemple : "&ecute;" => "e", "&Ecute;" => "E", "à" => "a" ...
    $str = preg_replace('#&([A-za-z])(?:acute|grave|cedil|circ|orn|ring|slash|th|tilde|uml);#', '\1', $str);
 
    // Remplacer les ligatures tel que : , Æ ...
    // Exemple "œ" => "oe"
    $str = preg_replace('#&([A-za-z]{2})(?:lig);#', '\1', $str);
    // Supprimer tout le reste
    $str = preg_replace('#&[^;]+;#', '', $str);
 
    return $str;
}
static function replace_white_space($string)
{
  return str_replace( array(' '), array(''), $string);
}
    static function getLang($language)
    {
        $languages = array("en",
                           "ru",
                           "id");

        $result = "en";

        foreach($languages as $value) {

            if ($value === $language) {

                $result = $language;

                break;
            }
        }

        return $result;
    }

    static function clearText($text)
    {
        $text = trim($text);
        $text = strip_tags($text);
        $text = htmlspecialchars($text);

        return $text;
    }

    static function escapeText($text)
    {
        if (APP_MYSQLI_EXTENSION) {

            $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

            $text = $mysqli->real_escape_string($text);
        }

        return $text;
    }

    static function clearInt($value)
    {
        $value = intval($value);

        if ($value < 0) {

            $value = 0;
        }

        return $value;
    }
 static function convertToHoursMins($time, $format = '%02d:%02d') {
    if ($time < 1) {
        return;
    }
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}
 static function convertSemestertoLevel($semestercode) {
   switch ($semestercode) {
			  case 1:
			$level = 1; 
			
			break;
		   
			case 2:
			$level = 1; 
			
			break;
			case 3:
			$level = 2; 
			
			break;
			case 4:
			$level = 2; 
			
			break;
			case 5:
			$level = 3; 
			
			break;
			 case 6:
			$level = 3; 
			
			break;
			case 7:
			$level = 4; 
			
			break;
			case 8:
			$level = 4; 
			
			break;
			case 9:
			$level = 5; 
			
			break;
			case 10:
			$level = 5; 
			
			break;
			case 11:
			$level = 6; 
			
			break;
			case 12:
			$level = 6; 
			
			break;
			default:
			$level = 1;
			}
			return $level;
}
    static function ip_addr()
    {
        (string) $ip_addr = 'undefined';

        if (isset($_SERVER['REMOTE_ADDR'])) $ip_addr = $_SERVER['REMOTE_ADDR'];

        return $ip_addr;
    }

    static function u_agent()
    {
        (string) $u_agent = 'undefined';

        if (isset($_SERVER['HTTP_USER_AGENT'])) $u_agent = $_SERVER['HTTP_USER_AGENT'];

        return $u_agent;
    }

    static function generateId($n = 2)
    {
        $key = '';
        $pattern = '123456789';
        $counter = strlen($pattern) - 1;

        for ($i = 0; $i < $n; $i++) {

            $key .= $pattern{rand(0, $counter)};
        }

        return $key;
    }

    static function generateHash($n = 7)
    {
        $key = '';
        $pattern = '123456789abcdefg';
        $counter = strlen($pattern) - 1;

        for ($i = 0; $i < $n; $i++) {

            $key .= $pattern{rand(0, $counter)};
        }

        return $key;
    }

    static function generateSalt($n = 3)
    {
        $key = '';
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyz.,*_-=+';
        $counter = strlen($pattern)-1;

        for ($i=0; $i<$n; $i++) {

            $key .= $pattern{rand(0,$counter)};
        }

        return $key;
    }
	
	static function randomKey($length) {
		$pool = array_merge(range(0,9), range('A', 'Z'));

		for($i=0; $i < $length; $i++) {
			$key .= $pool[mt_rand(0, count($pool) - 1)];
		}
		return $key;
	}

    static function declOfNum($number, $titles)
    {
        $cases = array(2, 0, 1, 1, 1, 2);
        return $number.' '.$titles[ ($number%100>4 && $number%100<20) ? 2 : $cases[($number%10<5) ? $number%10:5] ];
    }

    static function newAuthenticityToken()
    {

        $authenticity_token = md5(uniqid(rand(), true));

        if (isset($_SESSION)) {

            $_SESSION['authenticity_token'] = $authenticity_token;
        }
    }

    static function getAuthenticityToken()
    {
        if (isset($_SESSION) && isset($_SESSION['authenticity_token'])) {

            return $_SESSION['authenticity_token'];

        } else {

            return NULL;
        }
    }
	
	static function slugify($string, $delimiter = '-') {
    $oldLocale = setlocale(LC_ALL, '0');
    setlocale(LC_ALL, 'en_US.UTF-8');
    $clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
    $clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
    $clean = strtolower($clean);
    $clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
    $clean = trim($clean, $delimiter);
    setlocale(LC_ALL, $oldLocale);
    return $clean;
}

static function getHreflangURL() {
//global $TEXT["menu-$pageName-desc"] ;

$url            = self::curPageURL();
$lang_code      = self::getLangCodeFromURL();
$pageName       = self::getPageNameFromURL();
$getPageDescriptionFromURL   = self::getPageDescriptionFromURL();

if(!empty($lang_code)){
    $pageName  = self::getPageNameFromURL();
    if($lang_code =="fr"){                                                        
    $language = "en";
}else{
    $language = "fr";
}
}else{
    $pageName  = 'home';
if(!empty($_COOKIE['lang'])){                   
       if($_COOKIE['lang'] =="fr"){                                                        
    $language = "en";
}else{
    $language = "fr";
}
}else{
    $language = "fr";
}

} 

include_once("/home/www/3c4da4b8ff655cb7c6fe8bb6be53e8a7/web/arsel2021/lang/".$language.".php");
$pageNameTranslated          = $TEXT["menu-$pageName-desc"] ;
$pageNameTranslated          = self::slugify($pageNameTranslated);
if(!empty($lang_code)){
    $href_lang_url = str_replace("/$lang_code/".$getPageDescriptionFromURL, "/$language/".$pageNameTranslated, $url);
}else{
    $href_lang_url  = 'https://www.arsel.inovtech.net'.'/default.html/'.$language.'.html/arsel';
}

 return $href_lang_url;
}

static function curPageURL() {
 $pageURL = 'http';
 //if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 //$pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  // $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
return $pageURL;
}


static function getLangCodeFromURL() {

$url            = self::curPageURL();
$url_parsed     = parse_url($url);
$url_path       = $url_parsed['path'];
$url_path_array = explode("/", $url_path);
$sizeof_url_array     = sizeof($url_path_array);
$lang_code_position   = $sizeof_url_array - 2 ;
$lang_code      = $url_path_array[$lang_code_position] ;
 return $lang_code ;
}

static function getPageNameFromURL() {

$url            = self::curPageURL();
$url_parsed     = parse_url($url);
$url_path       = $url_parsed['path'];
$url_path_array = explode("/", $url_path);

$pageName       = $url_path_array['1'] ;
 return $pageName;
}

static function getPageDescriptionFromURL() {

$url            = self::curPageURL();
$url_parsed     = parse_url($url);
$url_path       = $url_parsed['path'];
$url_path_array = explode("/", $url_path);
$sizeof_url_array     = sizeof($url_path_array);
$pageDescriptionPosition   = $sizeof_url_array - 1 ;
$pageDescription      = $url_path_array[$pageDescriptionPosition] ;
 return $pageDescription ;

}

static function getPageMetaTitle($lang_code , $pageName , $blogId ='0') {

require("/home/www/3c4da4b8ff655cb7c6fe8bb6be53e8a7/web/arsel2021/lang/".$lang_code.".php");

if(empty($pageName)){
$pageName = "default";
}

$pageMetaTitle               = $TEXT["meta-$pageName-title"];

 return $pageMetaTitle;
}

static function getPageMetaDescription($lang_code , $pageName , $blogId ='0') {


require("/home/www/3c4da4b8ff655cb7c6fe8bb6be53e8a7/web/arsel2021/lang/".$lang_code.".php");

if(empty($pageName)){
$pageName = "default";
}

$pageNameTranslated          = $TEXT["menu-$pageName-desc"];
//$pageNameTranslated          = self::slugify($pageNameTranslated);


 return $pageNameTranslated;
}

static function getHreflangCode() {

$lang_code      = self::getLangCodeFromURL();

if(!empty($lang_code)){
if($lang_code =="fr"){
    $language = "en";
}else{
    $language = "fr";
}


}else{
    if(!empty($_COOKIE['lang'])){                   
       if($_COOKIE['lang'] =="fr"){                                                        
    $language = "en";
}else{
    $language = "fr";
}
}else{
    $language = "fr";
}
}


 return $language;
}

static function format_url($string)
{
  $stopword = array(
	      'et','ou','chez','des','likes','est','donc','mais','à','son','a','about','above','after','again','all','and','am','any','be','because','between','by','does','few','from','if','is','to','who','than'
	);
	$paragraph = explode(" ", $string);
	$titlelenght = str_word_count($string);
	for($i=0;$i<$titlelenght;$i++){
		if (!in_array($paragraph[$i], $stopword)){
		$url_slug .= $paragraph[$i]." ";
	}else{
		//echo "mot propre";
	}
	}
$url_slug   = rtrim($url_slug, " ");
return $url_slug;
} 

}

