<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class ads extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM ads WHERE removeAt=''");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdads()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM ads");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }


    public function info($adsId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM ads WHERE id = (:adsId) LIMIT 1");
        $stmt->bindParam(":adsId", $adsId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				
				$profile = new profile($this->db, $row['addBy']);
                    $profileInfo = $profile->get();
                    unset($profile);
					
					$profile = new profile($this->db, $row['clientId']);
                    $profileInfo2 = $profile->get();
                    unset($profile);
					
$date = strftime(" %d %h %Y %H:%M",strtotime($row['createAt']));
$start_date = strftime(" %d %h %Y %H:%M",strtotime($row['start_date']));
$end_date = strftime(" %d %h %Y %H:%M",strtotime($row['end_date']));
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "AdsPlace" => $row['place'],
                                "createAt" => $row['createAt'],
                                "status" => $row['status'],
                                "place" => $row['place'],
                                "manager" => $profileInfo['fullname'],
                                "ClientName" => $profileInfo2['fullname'],
                                "AdsTitle" => htmlspecialchars_decode(stripslashes($row['title'])),
                                "AdsLink" => htmlspecialchars_decode(stripslashes($row['link'])),
                                "PreviewUrlImg" => htmlspecialchars_decode(stripslashes($row['PreviewUrlImg'])),
								"start_date" =>$start_date,
								"end_date" =>$end_date,
								"Enddate" =>$row['end_date'],
								"date" =>$date,
                                "removeAt" => $row['removeAt']);
            }
        }

        return $result;
    }

    public function get($adsId = 0, $place)
    {

       if ($adsId == 0) {

            $adsId = $this->getMaxIdads();
            $adsId++;
        }
        

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "adsId" => $adsId,
                        "ads" => array());

        $stmt = $this->db->prepare("SELECT id FROM ads WHERE removeAt = 0 AND id < (:adsId) AND place = (:place) AND DATE(end_date) >= DATE(NOW()) ORDER BY id DESC");
        $stmt->bindParam(':adsId', $adsId, PDO::PARAM_INT);
        $stmt->bindParam(':place', $place, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $adsInfo = $this->info($row['id']);

                array_push($result['ads'], $adsInfo);

                $result['adsId'] = $adsInfo['id'];

                unset($adsInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 25/04/2017 bt TFM==============================================================================
 */
    public function getInfosCat($adsId)
    {
        if ($adsId == 0) {

            $adsId = $this->getMaxIdads();
            $adsId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "adsId" => $adsId,
                        "ads" => array());

        $stmt = $this->db->prepare("SELECT id FROM ads WHERE removeAt = 0 AND id = (:adsId)");
        $stmt->bindParam(':adsId', $adsId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $adsInfo = $this->info($row['id']);

                array_push($result['ads'], $adsInfo);

                $result['adsId'] = $adsInfo['id'];

                unset($adsInfo);
            }
        }

        return $result;
    }

	
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
