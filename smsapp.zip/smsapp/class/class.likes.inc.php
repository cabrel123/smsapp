<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class likes extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdLikes()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdCars()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($countryId= "0" , $stateId= "0" , $cityId= "0" , $makeId= "0" , $modelId= "0", $title, $description, $content, $imgUrl, $previewImgUrl, $allowComments = 1, $price = "0", $incitydailyprice = "0" , $outcitydailyprice = "0" , $incityhourlyprice = "0" , $postArea = "", $postCountry = "", $postCity = "", $postLat = "0.000000", $postLng = "0.000000")
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
                        "error_message" => "erreur",);

        /*
        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        if (strlen($content) == 0) {

            return $result;
        }

        if ($category == 0) {

            return $result;
        }

        if ($price == 0) {

            return $result;
        }
        */

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO likes (countryId , stateId , cityId , modelId , makeId, allowComments, fromUserId, category,  carDesc, carContent, imgUrl, previewImgUrl, price, incitydailyprice , outcitydailyprice , incityhourlyprice , area, country, city, lat, lng, createAt, ip_addr, u_agent) value (:countryId , :stateId , :cityId , :makeId , :modelId, :allowComments, :fromUserId, :category,  :carDesc, :carContent, :imgUrl, :previewImgUrl, :price, :incitydailyprice , :outcitydailyprice , :incityhourlyprice , :area, :country, :city, :lat, :lng, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":allowComments", $allowComments, PDO::PARAM_INT);
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->bindParam(":category", $makeId, PDO::PARAM_INT);
        $stmt->bindParam(":countryId", $countryId, PDO::PARAM_INT);
        $stmt->bindParam(":stateId", $stateId, PDO::PARAM_INT);
        $stmt->bindParam(":cityId", $cityId, PDO::PARAM_INT);
        $stmt->bindParam(":modelId", $modelId, PDO::PARAM_INT);
        $stmt->bindParam(":makeId", $makeId, PDO::PARAM_INT);
        $stmt->bindParam(":carDesc", $description, PDO::PARAM_STR);
        $stmt->bindParam(":carContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":previewImgUrl", $previewImgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":price", $price, PDO::PARAM_STR);
        $stmt->bindParam(":incitydailyprice", $incitydailyprice, PDO::PARAM_STR);
        $stmt->bindParam(":outcitydailyprice", $outcitydailyprice, PDO::PARAM_STR);
        $stmt->bindParam(":incityhourlyprice", $incityhourlyprice , PDO::PARAM_STR);
        $stmt->bindParam(":area", $postArea, PDO::PARAM_STR);
        $stmt->bindParam(":country", $postCountry, PDO::PARAM_STR);
        $stmt->bindParam(":city", $postCity, PDO::PARAM_STR);
        $stmt->bindParam(":lat", $postLat, PDO::PARAM_STR);
        $stmt->bindParam(":lng", $postLng, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "likeId" => $this->db->lastInsertId(),
                            "car" => $this->info($this->db->lastInsertId()));

            if ($this->requestFrom != 0) {

                $account = new account($this->db, $this->requestFrom);
                $account->updateCounters();
                unset($account);
            }

            if ($category != 0) {

                $cat = new categories($this->db);
                $cat->recalculate($category);
                unset($cat);
            }
        }

        return $result;
    }

    public function deleteAllByUserId($userId)
    {
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(':fromUserId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $this->remove($row['id']);
            }
        }
    }

    public function remove($likeId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $likeInfo = $this->info($likeId);

        if ($likeInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE id = (:likeId)");
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            // remove all notifications by likes and comments

            $stmt2 = $this->db->prepare("DELETE FROM notifications WHERE likeId = (:likeId)");
            $stmt2->bindParam(":likeId", $likeId, PDO::PARAM_INT);
            $stmt2->execute();

            //remove all comments to car

            $stmt3 = $this->db->prepare("UPDATE comments SET removeAt = (:removeAt) WHERE likeId = (:likeId)");
            $stmt3->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt3->bindParam(":likeId", $likeId, PDO::PARAM_INT);
            $stmt3->execute();

            //remove all likes to car

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE likeId = (:likeId) AND removeAt = 0");
            $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt->execute();

            $cat = new categories($this->db);
            $cat->recalculate($likeInfo['category']);

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        $this->recalculate($likeId);

        return $result;
    }

    public function restore($likeId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $likeInfo = $this->info($likeId);

        if ($likeInfo['error'] === true) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE likes SET removeAt = 0 WHERE id = (:likeId)");
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function edit($likeId, $category, $title, $imgUrl, $content, $allowComments, $price)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        if (strlen($content) == 0) {

            return $result;
        }

        if ($category == 0) {

            return $result;
        }

        if ($price == 0) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE likes SET allowComments = (:allowComments), category = (:category), carTitle = (:carTitle), carContent = (:carContent), imgUrl = (:imgUrl), price = (:price), moderatedAt = 0, moderatedId = 0 WHERE id = (:likeId)");
        $stmt->bindParam(":allowComments", $allowComments, PDO::PARAM_INT);
        $stmt->bindParam(":category", $category, PDO::PARAM_INT);
        $stmt->bindParam(":carTitle", $title, PDO::PARAM_STR);
        $stmt->bindParam(":carContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
        $stmt->bindParam(":price", $price, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function like($likeId, $fromUserId)
    {
        $account = new account($this->db, $fromUserId);
        $account->setLastActive();
        unset($account);

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $likeInfo = $this->info($likeId);

        if ($likeInfo['error'] === true) {

            return $result;
        }

        if ($likeInfo['removeAt'] != 0) {

            return $result;
        }

        if ($this->is_like_exists($likeId, $fromUserId)) {

            $removeAt = time();

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE likeId = (:likeId) AND fromUserId = (:fromUserId) AND removeAt = 0");
            $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
            $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $removeAt, PDO::PARAM_INT);
            $stmt->execute();

            $notify = new notify($this->db);
            $notify->removeNotify($likeInfo['fromUserId'], $fromUserId, NOTIFY_TYPE_LIKE, $likeId);
            unset($notify);

        } else {

            $createAt = time();
            $ip_addr = helper::ip_addr();

            $stmt = $this->db->prepare("INSERT INTO likes (toUserId, fromUserId, likeId, createAt, ip_addr) value (:toUserId, :fromUserId, :likeId, :createAt, :ip_addr)");
            $stmt->bindParam(":toUserId", $likeInfo['fromUserId'], PDO::PARAM_INT);
            $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
            $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
            $stmt->bindParam(":createAt", $createAt, PDO::PARAM_INT);
            $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
            $stmt->execute();
        }


        $this->recalculate($likeId);

        $car_info = $this->info($likeId);


        if ($car_info['fromUserId'] != $this->requestFrom) {

            $account = new account($this->db, $car_info['fromUserId']);
            $account->updateCounters();
            unset($account);
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likesCount" => $car_info['likesCount'],
                        "myLike" => $car_info['myLike']);

        return $result;
    }

    private function getLikesCount($likeId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE likeId = (:likeId) AND removeAt = 0");
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function is_like_exists($likeId, $fromUserId)
    {
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND likeId = (:likeId) AND removeAt = 0 LIMIT 1");
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            return true;
        }

        return false;
    }

    public function recalculate($likeId) {

        $comments_count = 0;
        $likes_count = 0;
        $rating = 0;
        $images_count = 0;

        $modifyAt = time();

        $likes_count = $this->getLikesCount($likeId);

        $comments = new comments($this->db);
        $comments_count = $comments->count($likeId);
        unset($comments);

        $images = new images($this->db);
        $images_count = $images->count($likeId);
        unset($images);

        $rating = $likes_count + $comments_count;

        $stmt = $this->db->prepare("UPDATE likes SET imagesCount = (:imagesCount), likesCount = (:likesCount), commentsCount = (:commentsCount), rating = (:rating), modifyAt = (:modifyAt) WHERE id = (:likeId)");
        $stmt->bindParam(":imagesCount", $images_count, PDO::PARAM_INT);
        $stmt->bindParam(":likesCount", $likes_count, PDO::PARAM_INT);
        $stmt->bindParam(":commentsCount", $comments_count, PDO::PARAM_INT);
        $stmt->bindParam(":rating", $rating, PDO::PARAM_INT);
        $stmt->bindParam(":modifyAt", $modifyAt, PDO::PARAM_INT);
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);
        $stmt->execute();

        $account = new account($this->db, $this->requestFrom);
        $account->updateCounters();
        unset($account);
    }

    public function info($likeId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM likes WHERE id = (:likeId) LIMIT 1");
        $stmt->bindParam(":likeId", $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $myLike = false;

                if ($this->requestFrom != 0) {

                    if ($this->is_like_exists($likeId, $this->requestFrom)) {

                        $myLike = true;
                    }
                }

                if ($row['fromUserId'] != 0) {

                    $profile = new profile($this->db, $row['fromUserId']);
                    $profileInfo = $profile->get();
                    unset($profile);

                } else {

                    $profileInfo = array("username" => "",
                                         "fullname" => "",
                                         "lowPhotoUrl" => "");
                }             
                
                $cars 		   = new cars($this->db);
         		 $carInfo 	   = $cars->info($row['carId']);
         		 unset($currency);
         		 
         		 $category = new categories($this->db);
                $categoryInfo = $category->info($carInfo['category']);
                unset($category);
				
				    $cities = new cities($this->db);
                $citiesInfo = $cities->info($carInfo['cityId']);
                unset($cities);
                
                $countries = new countries($this->db);
                $countryInfo = $countries->info($carInfo['countryId']);
                unset($countries);
                
                $models = new models($this->db);
                $modelInfo = $models->info($carInfo['modelId']);
                unset($models);
                
                $currency 		   = new currencies($this->db);
         		 $currencyInfo 	= $currency->info($countryInfo['currencyId']);
         		 unset($currency);
                
				
				
                $result = array("error" => false,
                                "error_code"        => ERROR_SUCCESS,
                                
                                "categoryTitle"     => $categoryInfo['title'],
                                "cityName"          => $citiesInfo['name'],
                                //====================Country Infos======================
                                "countryName"       => $countryInfo['name'], 
                                "currencyIso" 		 => $countryInfo['currencyIso'],
                                
                                "currencyName"      => htmlspecialchars_decode(stripslashes($currencyInfo['name'])), 
                                "countryCode"       => strtolower($countryInfo['sortname']),
                                
                                "fromUserUsername"  => $profileInfo['username'],
                                "fromUserFullname"  => $profileInfo['fullname'],
                                "fromUserPhone"     => $profileInfo['phone'],
                                "fromUserPhoto"     => $profileInfo['lowPhotoUrl'],
                                "carTitle"          => htmlspecialchars_decode(stripslashes($modelInfo['model'])),
                                
                                  
                                
                                //====================Car infos==========================
                                "id"                	=> $carInfo['id'],
                                "category"          	=> $carInfo['category'],
                                "price"             	=> $carInfo['price'],
                                "fromUserId"        	=> $carInfo['fromUserId'],
  										  "carDesc"           	=> htmlspecialchars_decode(stripslashes($carInfo['carDesc'])),
                                "carContent"        	=> stripslashes($carInfo['carContent']),
                                "area"              	=> htmlspecialchars_decode(stripslashes($carInfo['area'])),
                                "country" 			 	=> htmlspecialchars_decode(stripslashes($carInfo['country'])),
                                "city" 					=> htmlspecialchars_decode(stripslashes($carInfo['city'])),
                                "lat" 						=> $carInfo['lat'],
                                "lng" 						=> $carInfo['lng'],
                                "incitydailyprice" 	=> $carInfo['incitydailyprice'],
                                "outcitydailyprice" 	=> $carInfo['outcitydailyprice'],
                                "incityhourlyprice" 	=> $carInfo['incityhourlyprice'],
                                "previewImgUrl" 		=> $carInfo['previewImgUrl'],
                                "imgUrl" 					=> $carInfo['imgUrl'],
                                "allowComments" 		=> $carInfo['allowComments'],
                                "rating" 					=> $carInfo['rating'],
                                "commentsCount" 		=> $carInfo['commentsCount'],
                                "likesCount" 			=> $carInfo['likesCount'],
                                "myLike" 					=> $myLike,
                                "createAt" 				=> $carInfo['createAt'],
                                "date" 					=> date("Y-m-d H:i:s", $carInfo['createAt']),
                                "timeAgo" 				=> $time->timeAgo($carInfo['createAt']),
                                "removeAt" 				=> $carInfo['removeAt']
                              
                                
                                );
            }
        }

        return $result;
    }

    public function get($profileId, $likeId = 0)
    {
        if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0 AND id < (:likeId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
    
    
    
    
        public function getILiked($profileId, $likeId = 0)
    {
        if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0 AND id < (:likeId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
        public function getAllCars($likeId=0 , $cityName=0)
    {
        
         //Retrieve city id ;  getCityId($cityName
        if(!empty($cityName)){
         $cities   = new cities($this->db);
         $cityInfo = $cities->getCityId($cityName);
         unset($cities);
         $cityId   = $cityInfo['cityId'];
        }
        
        if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());
        if(!empty($cityId)){
            $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND cityId = (:cityId) AND id < (:likeId)  ORDER BY id DESC LIMIT 20");
            $stmt->bindParam(':cityId', $cityId, PDO::PARAM_INT);
            $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);
        }else{
            $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id < (:likeId)  ORDER BY id DESC LIMIT 20");
           //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
            $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);
        }
        

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
        public function getAllCarsExist($likeId=0, $limit)
    {
        if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id < (:likeId)  ORDER BY id DESC LIMIT $limit");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
	
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
        public function getInfosCars($likeId)
    {
         if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id = (:likeId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on 08/05/2017 bt TFM==============================================================================
 */
        public function getUsercar($accountId)
    {
         if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        } 
	//$accountId = 52180;
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND fromUserId = (:accountId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':accountId', $accountId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }	
	
/**
 * ===============Added on 03/05/2017 bt TFM==============================================================================
 */
        public function getAllOrdersAboutUser($user_id)
    {
         
        $stmt = $this->db->prepare("SELECT * FROM orders WHERE  removeAt = 0 AND fromUserId = (:user_id)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        $result = $stmt->execute();

        return $result;
    }
	
/**
 * ===============Added on april 04 bt TFM==============================================================================
 */
  public function getLastCars($likeId=0)
    {
         if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND id < (:likeId) ORDER BY id DESC LIMIT 1");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 17/04/2017 bt TFM==============================================================================
 */
        public function getInfosCarsByCategory($categoryId,$likeId)
    {
         if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND category = (:categoryId) AND id != (:likeId) ORDER BY id DESC LIMIT 3");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
         $stmt->bindParam(':likeId', $likeId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 19/04/2017 bt TFM==============================================================================
 */
        public function getAllCarsAvailable($queryText)
    {
         if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());
		//$queryText = "%".$queryText."%";
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE  removeAt = 0 AND cityId = (:queryText)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':queryText', $queryText, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['id']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }

        return $result;
    }	
	
/**
 * ===============Added on april 28/04/2017 bt TFM==============================================================================
 */
 
	public function sendcontactform($name , $subject , $email , $message, $date)
    {
		date_default_timezone_set("Africa/Douala");
$date = date("Y-m-d H:i:s");

		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
		
        $stmt = $this->db->prepare("INSERT INTO contact (name , subject, email , message, date) value (:name , :subject , :email , :message , :date)");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":subject", $subject, PDO::PARAM_STR);
        $stmt->bindParam(":message", $message, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        
        
		$result    = $stmt->execute();
		
        return $result;
    }
//generate Ramdom nuùber to insert to db
        public function db_random_number($tableName , $random_id)
        { 
        global $db;
// run an endless loop
        while(1) {
// generate unique random number
            $randomNumber = rand(0, 999999999);
// check if it exists in database
            $query = "SELECT * FROM $tableName WHERE $random_id=$randomNumber";
            $res = $this->db->query($query);
            $rowCount = $res->fetchColumn();
//$rowCount = mysql_num_rows($res);
// if not found in the db (it is unique), break out of the loop
            if($rowCount < 1) {
                break;
            }
        }
// pad the number with zeros (if needed)
            $paded = str_pad($randomNumber, 6, '0', STR_PAD_LEFT);
// dash delimited string to be displayed
            $delimited = '';
// add dashes
            for($i = 0; $i < 9; $i++) {
// add a character
            $delimited .= $paded[$i];
// add dashes wherever appropriate
            if($i == 2 || $i == 5) {
//$delimited .= '-';
            $delimited .= '';
            }
        }
            return $delimited;

            }
			
/**
 * ===============Added on april 26/04/2017 bt TFM==============================================================================
 */	
	
	public function SubscribeNewsletter($newsletterId , $email, $date)
    {
		date_default_timezone_set("Africa/Douala");
$date = date("Y-m-d H:i:s");

		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
		$table 			= "newsletter";
		$newsletter		= rand(0, 999999999);
		$newsletterId	= $this->db_random_number($table , $newsletter);
		
        $stmt = $this->db->prepare("INSERT INTO newsletter (newsletterId , email , date) value (:newsletterId , :email , :date)");
        $stmt->bindParam(":newsletterId", $newsletterId, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        
        
		$result    = $stmt->execute();
		
        return $result;
    }
	
 public function addcar($countryId, $stateId, $cityId, $makeId, $modelId, $description, $content, $price, $imgUrl, $previewImgUrl , $incitydailyprice, $outcitydailyprice , $incityhourlyprice)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
                        "error_message" => "erreur",);

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO likes (countryId , stateId , cityId , modelId , makeId, fromUserId, category, price, carDesc, carContent, imgUrl, previewImgUrl, incitydailyprice , outcitydailyprice , incityhourlyprice , createAt, ip_addr, u_agent) value (:countryId , :stateId , :cityId , :makeId , :modelId, :fromUserId, :category, :price, :carDesc, :carContent, :imgUrl, :previewImgUrl, :incitydailyprice , :outcitydailyprice , :incityhourlyprice , :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->bindParam(":category", $makeId, PDO::PARAM_INT);
        $stmt->bindParam(":countryId", $countryId, PDO::PARAM_INT);
        $stmt->bindParam(":stateId", $stateId, PDO::PARAM_INT);
        $stmt->bindParam(":cityId", $cityId, PDO::PARAM_INT);
        $stmt->bindParam(":modelId", $modelId, PDO::PARAM_INT);
        $stmt->bindParam(":makeId", $makeId, PDO::PARAM_INT);
        $stmt->bindParam(":price", $price, PDO::PARAM_STR);
        $stmt->bindParam(":carDesc", $description, PDO::PARAM_STR);
        $stmt->bindParam(":carContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":previewImgUrl", $previewImgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":incitydailyprice", $incitydailyprice, PDO::PARAM_STR);
        $stmt->bindParam(":outcitydailyprice", $outcitydailyprice, PDO::PARAM_STR);
        $stmt->bindParam(":incityhourlyprice", $incityhourlyprice , PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "likeId" => $this->db->lastInsertId(),
                            "car" => $this->info($this->db->lastInsertId()));

            if ($this->requestFrom != 0) {

                $account = new account($this->db, $this->requestFrom);
                $account->updateCounters();
                unset($account);
            }

            if ($category != 0) {

                $cat = new categories($this->db);
                $cat->recalculate($category);
                unset($cat);
            }
        }

        return $result;
    }

/**
 * ===============Added on april 15/05/2017 bt TFM==============================================================================
 */
        public function getWhishlistUser($accountId)
    {
         
 if ($likeId == 0) {

            $likeId = $this->getMaxIdCars();
            $likeId++;
        } 
	//$accountId = 52225;
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likeId" => $likeId,
                        "likes" => array());

        $stmt = $this->db->prepare("SELECT DISTINCT likeId FROM likes WHERE fromUserId = (:accountId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':accountId', $accountId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $likeInfo = $this->info($row['likeId']);

                array_push($result['likes'], $likeInfo);

                $result['likeId'] = $likeInfo['id'];

                unset($likeInfo);
            }
        }
        return $result;
    }
	
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
