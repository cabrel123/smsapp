<?php

class orders extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

	
/***************************** Fonction pour avoir l'id le plus grand de la table orders ************************/
    private function getMaxIdorders()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM orders");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

// count all users	
	public function getAllCount($client_id)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM orders WHERE client_id = (:client_id) AND deleted = 0");
         $stmt->bindParam(':client_id', $client_id, PDO::PARAM_INT);
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
		public function getTotalRaised()
    {
        $stmt = $this->db->prepare("SELECT SUM(price) FROM orders WHERE status = 1 AND deleted = 0");
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
/*
|------------------------------------------------------------------------------
| get sms code
|------------------------------------------------------------------------------
*/	
	public function getSMSCodeUser($accountId)
    {
        $stmt = $this->db->prepare("SELECT code FROM orders WHERE toUserId = (:accountId) AND status = 0 AND deleted = 0 ORDER BY id DESC LIMIT 1");
        $stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['code'];
        }

        return 0;
    }	

/*
|------------------------------------------------------------------------------
| update user sms code
|------------------------------------------------------------------------------
*/
 public function UpdateUserSmsCode($accountId)
    {
		$currentTime = time();
        $stmt = $this->db->prepare("UPDATE orders SET status = 1, removeAt = (:currentTime)  WHERE toUserId = (:accountId)");
        $stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
        $stmt->bindParam(":currentTime", $currentTime, PDO::PARAM_STR);

        $stmt->execute();
    }	

/***************************** Fonction pour supprimer (désactiver) un orders *********************************/	
    public function remove($ordersId, $accountId)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $itemInfo = $this->info($ordersId);

        if ($itemInfo['error'] === true) {

            return $result;
        }
		
        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE orders SET deleted = (:removeAt), deleted_by = (:accountId) WHERE id = (:ordersId)");
        $stmt->bindParam(":ordersId", $ordersId, PDO::PARAM_INT);
        $stmt->bindParam(":accountId", $accountId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }

/***************************** fonction pour avoir les infos d'un orders *********************************/
    public function info($ordersId)
    {
		//initialisation du tableau result
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM orders WHERE id = (:ordersId) LIMIT 1");
        $stmt->bindParam(":ordersId", $ordersId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				
				$profile = new profile($this->db, $row['client_id']);
                $profileInfo = $profile->get();
                unset($profile);
				
				$products = new products($this->db);
                $contentsInfo = $products->info($row['id_product']);
                unset($products);
				
				$products = new products($this->db);
                $subscriptionproduct = $products->getSubscriptionProductProductTitle($row['id_product']);
                unset($products);
	                 setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
//$date = date("d M Y H:i:s", strtotime($row['publish_date']));

$date = strftime(" %d %h %Y",strtotime($row['seller_date']));				
				//on rempli le tableau result
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "price" => $row['price'],
                                "transactionId" => $row['id_cart'],
                                "id_product" => $row['id_product'],
                                "id_category" => $row['id_category'],
                                "payment_method" => $row['payment_method'],
                                "client_id" => $row['client_id'],
                                "status" => $row['status'],
                                "qte" => $row['qte'],
                                "flagseller" => $row['flagseller'],
                                "comment" => $row['comment'],
                                "fromUserFullname" => $profileInfo['fullname'],
                                "fromUserLastname" => $profileInfo['lastname'],
                                "productName" => $contentsInfo['productsName'],
                                "productName2" => $subscriptionproduct,
                                "createAt" => $row['seller_date'],
                                "date" => $date,
                                "removeAt" => $row['deleted']);
            }
        }

        return $result;
    }

/***************************** fonction pour parcourir la table orders *********************************/
    public function get($ordersId = 0, $client_id, $pageNumber)
    {
		
	$limit = 12;
    if($pageNumber){
		 $contentId = 0;
	if($pageNumber=='1'){
		   $offset=0;                      
		  }else{
		   $offset = ($pageNumber - 1) * $limit;
		  }
		  
	}
                    
       if ($ordersId == 0) {

            $ordersId = $this->getMaxIdorders();
            $ordersId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }
   
       

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "ordersId" => $ordersId,
                        "orders" => array());

        $stmt = $this->db->prepare("SELECT id FROM orders WHERE deleted = 0 AND id < (:ordersId) AND client_id=(:client_id) ORDER BY id DESC LIMIT $offset,$limit");
        $stmt->bindParam(':ordersId', $ordersId, PDO::PARAM_INT);
        $stmt->bindParam(':client_id', $client_id, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {
				//appel de la fonction info
                $itemInfo = $this->info($row['id']);
				
                array_push($result['orders'], $itemInfo);

                $result['ordersId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }

/***************************** fonction pour sélectionner un orders par id *********************************/	
	 public function getordersById($ordersId = 0)
    {
        if ($ordersId == 0) {

            $ordersId = $this->getMaxIdorders();
            $ordersId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "ordersId" => $ordersId,
                        "orders" => array());

        $stmt = $this->db->prepare("SELECT id FROM orders WHERE deleted = 0 AND id = (:ordersId)");
        $stmt->bindParam(':ordersId', $ordersId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['orders'], $itemInfo);

                $result['ordersId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
/***************************** fonction pour parcourir la table orders *********************************/
    public function getuserpayment($ordersId = 0, $client_id)
    {
        if ($ordersId == 0) {

            $ordersId = $this->getMaxIdorders();
            $ordersId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "ordersId" => $ordersId,
                        "orders" => array());

        $stmt = $this->db->prepare("SELECT id FROM orders WHERE deleted = 0 AND id < (:ordersId) AND client_id=(:client_id) ORDER BY id DESC");
        $stmt->bindParam(':ordersId', $ordersId, PDO::PARAM_INT);
        $stmt->bindParam(':client_id', $client_id, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {
				//appel de la fonction info
                $itemInfo = $this->info($row['id']);
				
                array_push($result['orders'], $itemInfo);

                $result['ordersId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
/*
|------------------------------------------------------------------------------
| Insert transaction into DB
|------------------------------------------------------------------------------
*/	
	public function create($transactionId, $product_item, $id_category,$price, $client_id,$payment_method, $comment)
    {

        $result = array("error" => true);

        date_default_timezone_set("Africa/Douala");
		$currentTime 		= date('Y-m-d H:i:s');
        $u_agent        	= helper::u_agent();
        $ip_addr        	= helper::ip_addr();
        $flagseller        	= 1;
		
        $stmt = $this->db->prepare("INSERT INTO orders (id_cart, id_product, id_category,price, client_id,payment_method, comment, seller_date,flagseller, ip_addr, u_agent) value (:transactionId, :product_item, :id_category, :price, :client_id, :payment_method, :comment, :createAt, :flagseller, :ip_addr, :u_agent)"); 
        $stmt->bindParam(":transactionId", $transactionId, PDO::PARAM_STR);
        $stmt->bindParam(":product_item", $product_item, PDO::PARAM_STR);
        $stmt->bindParam(":id_category", $id_category, PDO::PARAM_STR);
        $stmt->bindParam(":price", $price, PDO::PARAM_STR);
        $stmt->bindParam(":client_id", $client_id, PDO::PARAM_INT);
        $stmt->bindParam(":payment_method", $payment_method, PDO::PARAM_STR);
        $stmt->bindParam(":comment", $comment, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
        $stmt->bindParam(":flagseller", $flagseller, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);
        if ($stmt->execute()) {

             $this->setId($this->db->lastInsertId());

            $this->setLanguage("en");

            $result = array("error" => false,
                            'ordersId' => $this->id,
                            'error_code'    => ERROR_SUCCESS,
                            'error_description' => 'orders Success!');

            return $result;
        }

        return $result;
    }
	
    // edit user info
	 public function updateOders($orderId,$transactionId, $client_id, $payment_method,$comment,$extrainfos)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
                        "orderId" => $orderId,
                        "transactionId" => $transactionId,
                        "client_id" => $client_id,
                        "payment_method" => $payment_method,
						"error_msg" => "error msg");

      date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
        

		$status = 1;
        $stmt = $this->db->prepare("UPDATE orders SET id_cart = (:transactionId),flagseller = (:status), payment_method = (:payment_method), comment = (:comment), extrainfos = (:extrainfos), client_id = (:client_id)
 WHERE id = (:orderId)");
        $stmt->bindParam(":orderId", $orderId, PDO::PARAM_INT);
        $stmt->bindParam(":status", $status, PDO::PARAM_INT);
        $stmt->bindParam(":client_id", $client_id, PDO::PARAM_INT);
        $stmt->bindParam(":transactionId", $transactionId, PDO::PARAM_STR);
        $stmt->bindParam(":payment_method", $payment_method, PDO::PARAM_STR);
        $stmt->bindParam(":comment", $comment, PDO::PARAM_STR);
        $stmt->bindParam(":extrainfos", $extrainfos, PDO::PARAM_STR);
        

        if ($stmt->execute()) {

            $result = array("error" => false,
						"orderId" => $orderId,
                        "transactionId" => $transactionId,
                        "client_id" => $client_id,
                        "payment_method" => $payment_method,
                        "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }
	
	
/**
 * ==================================Set Db uniq number =========================================  
 */
 //generate Ramdom nuùber to insert to db
        public function db_random_number($tableName , $random_id)
        { 
        global $db;
// run an endless loop
        while(1) {
// generate unique random number
            $randomNumber = rand(111111, 999999);
// check if it exists in database
            $query = "SELECT * FROM $tableName WHERE $random_id=$randomNumber";
            $res = $this->db->query($query);
            $rowCount = $res->fetchColumn();
//$rowCount = mysql_num_rows($res);
// if not found in the db (it is unique), break out of the loop
            if($rowCount < 1) {
                break;
            }
        }
// pad the number with zeros (if needed)
            $paded = str_pad($randomNumber, 6, '0', STR_PAD_LEFT);
// dash delimited string to be displayed
            $delimited = '';
// add dashes
            for($i = 0; $i < 9; $i++) {
// add a character
            $delimited .= $paded[$i];
// add dashes wherever appropriate
            if($i == 2 || $i == 5) {
//$delimited .= '-';
            $delimited .= '';
            }
        }
            return $delimited;

            }	
/***************************** fonctions pour les fichiers de traduction *********************************/
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

/***************************** fonctions pour tracer l'activité d'un utilisateur sur la table orders *********************************/
    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }
	public function setId($transactionId)
    {
        $this->id = $transactionId;
    }
    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
