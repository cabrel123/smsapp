<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class states extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM states");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM states");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO states (title, description, imgUrl, createAt, ip_addr, u_agent) value (:title, :description, :imgUrl, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "stateId" => $this->db->lastInsertId(),
                            "state" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }

    public function remove($stateId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stateInfo = $this->info($stateId);

        if ($stateInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE states SET removeAt = (:removeAt) WHERE id = (:stateId)");
        $stmt->bindParam(":stateId", $stateId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            //remove all states

            $stmt3 = $this->db->prepare("SELECT id FROM cars WHERE category = (:category)");
            $stmt3->bindParam(":category", $stateId, PDO::PARAM_INT);

            if ($stmt3->execute()) {

                while ($row = $stmt->fetch()) {

                    $state = new states($this->db);

                    $state->remove($row['id']);

                    unset($state);
                }
            }

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

            $this->recalculate($stateId);
        }

        return $result;
    }

    public function edit($stateId, $title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }


        $stmt = $this->db->prepare("UPDATE states SET title = (:title), description = (:description), imgUrl = (:imgUrl) WHERE id = (:stateId)");
        $stmt->bindParam(":stateId", $stateId, PDO::PARAM_INT);
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }

    public function recalculate($categoryId) {

        $states_count = 0;

        $states_count = $this->getItemsCount($categoryId);

        $stmt = $this->db->prepare("UPDATE states SET statesCount = (:statesCount) WHERE id = (:categoryId)");
        $stmt->bindParam(":statesCount", $states_count, PDO::PARAM_INT);
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->execute();
    }

    private function getItemsCount($categoryId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE category = (:category) AND removeAt = 0");
        $stmt->bindParam(":category", $categoryId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function info($stateId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM states WHERE id = (:stateId) LIMIT 1");
        $stmt->bindParam(":stateId", $stateId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "statesCount" => $row['statesCount'],
                                "name" => htmlspecialchars_decode(stripslashes($row['name'])),
                                "description" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "country_id" => $row['country_id'],
                                "createAt" => $row['createAt'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "removeAt" => $row['removeAt']);

            }
        }

        return $result;
    }

    public function get($stateId = 0 , $countryId)
    {
        if ($stateId == 0) {

            $stateId = $this->getMaxIdItems();
            $stateId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "stateId" => $stateId,
                        "states" => array());

        $stmt = $this->db->prepare("SELECT id FROM states WHERE removeAt = 0 AND country_id = (:country_id) AND id < (:stateId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':stateId', $stateId, PDO::PARAM_INT);
        $stmt->bindParam(':country_id', $countryId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $stateInfo = $this->info($row['id']);

                array_push($result['states'], $stateInfo);

                $result['stateId'] = $stateInfo['id'];

                unset($stateInfo);
            }
        }

        return $result;
    }

    public function getList()
    {
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "states" => array());

        $stmt = $this->db->prepare("SELECT id FROM states WHERE removeAt = 0 ORDER BY id");

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $stateInfo = $this->info($row['id']);

                array_push($result['states'], $stateInfo);

                unset($stateInfo);
            }
        }

        return $result;
    }

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
