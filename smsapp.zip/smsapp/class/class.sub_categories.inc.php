<?php
/**************************************************************** *
 * arsel.cm engine v1.0                       					  *
 *                                                                *
 * ALLURE                                            	  		  *
 * admin@allure.com                             				  *
 *                                                                *
 * Copyright 2021 BEYALA BEATRICE CEO ALLURE					  *
 ******************************************************************
 */
 
class sub_categories extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM subcategory");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM subcategory");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
    public function getCountSubCategoryByCategory($categoryId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM subcategory WHERE deleted=0 AND id_parent_category = (:categoryId)");
		$stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_STR);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
/**
 * ===============Fonction pour récupérer le nom d'une sous-catégorie==============================================================================
*/	
public function getSubCategoryTitle($categoryId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT title_fr, title_en FROM subcategory WHERE id = (:categoryId) LIMIT 1");
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            $result = array('error' => false,
                            'error_code' => ERROR_SUCCESS,
                            'title_fr' => $row['title_fr'],
                            'title_en' => $row['title_en']);
        }

        return $result;
    }	
/**
 * ===============Fonction pour récupérer l'id de la section d'une sous-catégorie==============================================================================
*/
 public function getCatIdBySubCategory($categoryId)
    {
        $stmt = $this->db->prepare("SELECT id_parent_category FROM subcategory WHERE id = (:categoryId) LIMIT 1");
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['id_parent_category'];
        }

        return 0;
    }	
/**
 * ===============Fonction pour Vérifier si une sous-categorie existe==============================================================================
*/
	public function CheckIfsubcategoriesExist($name)
    {
		//initialisation du tableau result
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM subcategory WHERE title_fr = (:name) AND deleted = '' ORDER BY id");
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
		$stmt->execute();
        return $number_of_rows = $stmt->fetchColumn();
    }
	
/**
 * ===============Fonction pour ajouter une nouvelle catégorie==============================================================================
*/
    public function add($title_fr,$title_en,  $description_fr, $description_en, $categoryId, $managerId)
    {
        $result = array("error" => true,
                        "title" => $title,
                        "description" => $description,
                        "error_code" => ERROR_UNKNOWN);

       
        date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO subcategory (title_fr,title_en, description_fr, description_en,manager, id_parent_category, createAt, ip_addr, u_agent) value (:title_fr, :title_en, :description_fr, :description_en, :managerId, :categoryId, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":title_fr", $title_fr, PDO::PARAM_STR);
        $stmt->bindParam(":title_en", $title_en, PDO::PARAM_STR);
        $stmt->bindParam(":description_fr", $description_fr, PDO::PARAM_STR);
        $stmt->bindParam(":description_en", $description_en, PDO::PARAM_STR);
        $stmt->bindParam(":managerId", $managerId, PDO::PARAM_INT);
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
		$stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "itemId" => $this->db->lastInsertId(),
                            "item" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }
/**
 * ===============Fonction pour supprimer une sous-catégorie==============================================================================
*/
	 public function remove($itemId, $deleted_by)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $itemInfo = $this->info($itemId);

        if ($itemInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE subcategory SET deleted = (:deleted), deleted_by = (:deleted_by) WHERE id = (:itemId)");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->bindParam(":deleted_by", $deleted_by, PDO::PARAM_INT);
        $stmt->bindParam(":deleted", $currentTime, PDO::PARAM_INT);

		$stmt->execute();

        return $result;
    }
/**
 * ===============Fonction pour modifier une sous-catégorie==============================================================================
*/
    public function edit($itemId, $title_fr, $title_en, $description_fr, $description_en, $categoryId)
    {
        $result = array("error" => true,
                        "error_description" => "Une erreur s'est produite essaye à nouveau stp !",
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title_fr) == 0) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE category SET title_fr = (:title_fr), title_en = (:title_en), description_fr = (:description_fr), description_en = (:description_en), id_parent_category = (:categoryId) WHERE id = (:itemId)");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->bindParam(":title_fr", $title_fr, PDO::PARAM_STR);
        $stmt->bindParam(":title_en", $title_en, PDO::PARAM_STR);
        $stmt->bindParam(":description_fr", $description_fr, PDO::PARAM_STR);
        $stmt->bindParam(":description_en", $description_en, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            $result = array("error" => false,
							"error_description" => "$itemId, $title_fr, $title_en, $categoryId",
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }
/**
 * ===============Fonction pour avoir les infos sur une sous-categorie==============================================================================
*/

    public function info($itemId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM subcategory WHERE id = (:itemId) LIMIT 1");
        $stmt->bindParam(":itemId", $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				$categories = new categories($this->db);
                $categoriesInfo = $categories->info($row['id_parent_category']);
                unset($categories);
				
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "categoryId" => $row['id_parent_category'],
                                "description_en" => htmlspecialchars_decode(stripslashes($row['description_en'])),
                                "description_fr" => htmlspecialchars_decode(stripslashes($row['description_fr'])),
                                "title_fr" => htmlspecialchars_decode(stripslashes($row['title_fr'])),
                                "title_en" => htmlspecialchars_decode(stripslashes($row['title_en'])),
								"categoryTitle" => $categoriesInfo['title_fr'],
                                "deleted" => $row['deleted']);
            }
        }

        return $result;
    }

/**
 * ===============Fonction pour récupérer toutes les catégories==============================================================================
 */
    public function get($itemId = 0)
    {
        if ($itemId == 0) {

            $itemId = $this->getMaxIdItems();
            $itemId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "itemId" => $itemId,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM subcategory WHERE id < (:itemId) ORDER BY id DESC");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['items'], $itemInfo);

                $result['itemId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
/**
 * ===============Fonction pour récupérer une catégorie par son ID==============================================================================
 */
    public function getInfosSubCat($itemId)
    {
        if ($itemId == 0) {

            $itemId = $this->getMaxIdItems();
            $itemId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "itemId" => $itemId,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM subcategory WHERE deleted = 0 AND id = (:itemId)");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['items'], $itemInfo);

                $result['itemId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
	public function getListSubCat($itemId)
    {
        

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "itemId" => $itemId,
                        "sql" => "SELECT id FROM subcategory WHERE deleted = 0 AND id_parent_category = $itemId",
                        "items" => array());

        $stmt = $this->db->prepare("SELECT id FROM subcategory WHERE deleted = 0 AND id_parent_category = (:itemId) ORDER BY id DESC");
        $stmt->bindParam(':itemId', $itemId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $itemInfo = $this->info($row['id']);

                array_push($result['items'], $itemInfo);

                $result['itemId'] = $itemInfo['id'];

                unset($itemInfo);
            }
        }

        return $result;
    }
    
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
