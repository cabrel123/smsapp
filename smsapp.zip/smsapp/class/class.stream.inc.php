<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class stream extends db_connect
{
    private $requestFrom = 0;

    public function __construct($dbo = NULL)
    {
        parent::__construct($dbo);
    }

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE removeAt = 0 AND category > 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getAllCountByCategory($category = 0)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE removeAt = 0 AND category = (:category)");
        $stmt->bindParam(':category', $category, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getAllCountByUserId($userId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE removeAt = 0 AND fromUserId = (:fromUserId)");
        $stmt->bindParam(':fromUserId', $userId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getLikeMaxId()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxId()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM cars");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count($language = 'en')
    {
        $count = 0;

        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE fromUserId <> (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(':fromUserId', $this->requestFrom, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $count = $stmt->fetchColumn();
        }

        return $count;
    }

    public function getFavoritesCount()
    {
        $count = 0;

        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(':fromUserId', $this->requestFrom, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $count = $stmt->fetchColumn();
        }

        return $count;
    }

    public function getFavorites($carId = 0)
    {
        if ($carId == 0) {

            $carId = $this->getLikeMaxId();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carId" => $carId,
                        "cars" => array());

        $stmt = $this->db->prepare("SELECT carId FROM likes WHERE removeAt = 0 AND id < (:carId) AND fromUserId = (:fromUserId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':fromUserId', $this->requestFrom, PDO::PARAM_INT);
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $cars = new cars($this->db);
                    $cars->setRequestFrom($this->requestFrom);
                    $carInfo = $cars->info($row['carId']);
                    unset($cars);

                    array_push($result['cars'], $carInfo);

                    $result['carId'] = $carInfo['id'];

                    unset($carInfo);
                }
            }
        }

        return $result;
    }

    public function get($carId = 0, $language = 'en')
    {
        if ($carId == 0) {

            $carId = $this->getMaxId();
            $carId++;
        }

        $result = array("error" => false,
                         "error_code" => ERROR_SUCCESS,
                         "carId" => $carId,
                         "cars" => array());

        $stmt = $this->db->prepare("SELECT id FROM cars WHERE removeAt = 0 AND category > 0 AND id < (:carId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $car = new cars($this->db);
                    $car->setRequestFrom($this->requestFrom);
                    $carInfo = $car->info($row['id']);
                    unset($post);

                    array_push($result['cars'], $carInfo);

                    $result['carId'] = $carInfo['id'];

                    unset($carInfo);
                }
            }
        }

        return $result;
    }

    public function getByCategory($categoryId, $carId = 0, $language = 'en')
    {
        if ($carId == 0) {

            $carId = $this->getMaxId();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "categoryId" => $categoryId,
                        "carId" => $carId,
                        "cars" => array());

        $stmt = $this->db->prepare("SELECT id FROM cars WHERE removeAt = 0 AND category = (:category) AND id < (:carId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);
        $stmt->bindParam(':category', $categoryId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $car = new cars($this->db);
                    $car->setRequestFrom($this->requestFrom);
                    $carInfo = $car->info($row['id']);
                    unset($post);

                    array_push($result['cars'], $carInfo);

                    $result['carId'] = $carInfo['id'];

                    unset($carInfo);
                }
            }
        }

        return $result;
    }

    public function getByUserId($carId = 0, $userId = 0, $language = 'en')
    {
        if ($carId == 0) {

            $carId = $this->getMaxId();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "userId" => $userId,
                        "carId" => $carId,
                        "cars" => array());

        $stmt = $this->db->prepare("SELECT id FROM cars WHERE removeAt = 0 AND fromUserId = (:fromUserId) AND id < (:carId) ORDER BY id DESC LIMIT 20");
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);
        $stmt->bindParam(':fromUserId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $car = new cars($this->db);
                    $car->setRequestFrom($this->requestFrom);
                    $carInfo = $car->info($row['id']);
                    unset($post);

                    array_push($result['cars'], $carInfo);

                    $result['carId'] = $carInfo['id'];

                    unset($carInfo);
                }
            }
        }

        return $result;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }
}

