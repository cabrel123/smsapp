<?php


/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class users extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM users");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdLikes()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdUsers()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM users");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM users WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($category, $title, $description, $content, $imgUrl, $previewImgUrl, $allowComments = 1, $price = 0, $postArea = "", $postCountry = "", $postCity = "", $postLat = "0.000000", $postLng = "0.000000")
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        if (strlen($content) == 0) {

            return $result;
        }

        if ($category == 0) {

            return $result;
        }

        if ($price == 0) {

            return $result;
        }

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO users (allowComments, fromUserId, category, userTitle, userDesc, userContent, imgUrl, previewImgUrl, price, area, country, city, lat, lng, createAt, ip_addr, u_agent) value (:allowComments, :fromUserId, :category, :userTitle, :userDesc, :userContent, :imgUrl, :previewImgUrl, :price, :area, :country, :city, :lat, :lng, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":allowComments", $allowComments, PDO::PARAM_INT);
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->bindParam(":category", $category, PDO::PARAM_INT);
        $stmt->bindParam(":userTitle", $title, PDO::PARAM_STR);
        $stmt->bindParam(":userDesc", $description, PDO::PARAM_STR);
        $stmt->bindParam(":userContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":previewImgUrl", $previewImgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":price", $price, PDO::PARAM_INT);
        $stmt->bindParam(":area", $postArea, PDO::PARAM_STR);
        $stmt->bindParam(":country", $postCountry, PDO::PARAM_STR);
        $stmt->bindParam(":city", $postCity, PDO::PARAM_STR);
        $stmt->bindParam(":lat", $postLat, PDO::PARAM_STR);
        $stmt->bindParam(":lng", $postLng, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "userId" => $this->db->lastInsertId(),
                            "user" => $this->info($this->db->lastInsertId()));

            if ($this->requestFrom != 0) {

                $account = new account($this->db, $this->requestFrom);
                $account->updateCounters();
                unset($account);
            }

            if ($category != 0) {

                $cat = new categories($this->db);
                $cat->recalculate($category);
                unset($cat);
            }
        }

        return $result;
    }

    public function deleteAllByUserId($userId)
    {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(':fromUserId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $this->remove($row['id']);
            }
        }
    }

    public function remove($userId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $userInfo = $this->info($userId);

        if ($userInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE users SET removeAt = (:removeAt) WHERE id = (:userId)");
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            // remove all notifications by likes and comments

            $stmt2 = $this->db->prepare("DELETE FROM notifications WHERE userId = (:userId)");
            $stmt2->bindParam(":userId", $userId, PDO::PARAM_INT);
            $stmt2->execute();

            //remove all comments to user

            $stmt3 = $this->db->prepare("UPDATE comments SET removeAt = (:removeAt) WHERE userId = (:userId)");
            $stmt3->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt3->bindParam(":userId", $userId, PDO::PARAM_INT);
            $stmt3->execute();

            //remove all likes to user

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE userId = (:userId) AND removeAt = 0");
            $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt->execute();

            $cat = new categories($this->db);
            $cat->recalculate($userInfo['category']);

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        $this->recalculate($userId);

        return $result;
    }

    public function restore($userId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $userInfo = $this->info($userId);

        if ($userInfo['error'] === true) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE users SET removeAt = 0 WHERE id = (:userId)");
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function edit($userId, $category, $title, $imgUrl, $content, $allowComments, $price)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        if (strlen($content) == 0) {

            return $result;
        }

        if ($category == 0) {

            return $result;
        }

        if ($price == 0) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE users SET allowComments = (:allowComments), category = (:category), userTitle = (:userTitle), userContent = (:userContent), imgUrl = (:imgUrl), price = (:price), moderatedAt = 0, moderatedId = 0 WHERE id = (:userId)");
        $stmt->bindParam(":allowComments", $allowComments, PDO::PARAM_INT);
        $stmt->bindParam(":category", $category, PDO::PARAM_INT);
        $stmt->bindParam(":userTitle", $title, PDO::PARAM_STR);
        $stmt->bindParam(":userContent", $content, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
        $stmt->bindParam(":price", $price, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function like($userId, $fromUserId)
    {
        $account = new account($this->db, $fromUserId);
        $account->setLastActive();
        unset($account);

        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $userInfo = $this->info($userId);

        if ($userInfo['error'] === true) {

            return $result;
        }

        if ($userInfo['removeAt'] != 0) {

            return $result;
        }

        if ($this->is_like_exists($userId, $fromUserId)) {

            $removeAt = time();

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE userId = (:userId) AND fromUserId = (:fromUserId) AND removeAt = 0");
            $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
            $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $removeAt, PDO::PARAM_INT);
            $stmt->execute();

            $notify = new notify($this->db);
            $notify->removeNotify($userInfo['fromUserId'], $fromUserId, NOTIFY_TYPE_LIKE, $userId);
            unset($notify);

        } else {

            $createAt = time();
            $ip_addr = helper::ip_addr();

            $stmt = $this->db->prepare("INSERT INTO likes (toUserId, fromUserId, userId, createAt, ip_addr) value (:toUserId, :fromUserId, :userId, :createAt, :ip_addr)");
            $stmt->bindParam(":toUserId", $userInfo['fromUserId'], PDO::PARAM_INT);
            $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
            $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
            $stmt->bindParam(":createAt", $createAt, PDO::PARAM_INT);
            $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
            $stmt->execute();
        }

        $this->recalculate($userId);

        $user_info = $this->info($userId);

        if ($user_info['fromUserId'] != $this->requestFrom) {

            $account = new account($this->db, $user_info['fromUserId']);
            $account->updateCounters();
            unset($account);
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "likesCount" => $user_info['likesCount'],
                        "myLike" => $user_info['myLike']);

        return $result;
    }

    private function getLikesCount($userId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE userId = (:userId) AND removeAt = 0");
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function is_like_exists($userId, $fromUserId)
    {
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND userId = (:userId) AND removeAt = 0 LIMIT 1");
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            return true;
        }

        return false;
    }

    public function recalculate($userId) {

        $comments_count = 0;
        $likes_count = 0;
        $rating = 0;
        $images_count = 0;

        $modifyAt = time();

        $likes_count = $this->getLikesCount($userId);

        $comments = new comments($this->db);
        $comments_count = $comments->count($userId);
        unset($comments);

        $images = new images($this->db);
        $images_count = $images->count($userId);
        unset($images);

        $rating = $likes_count + $comments_count;

        $stmt = $this->db->prepare("UPDATE users SET imagesCount = (:imagesCount), likesCount = (:likesCount), commentsCount = (:commentsCount), rating = (:rating), modifyAt = (:modifyAt) WHERE id = (:userId)");
        $stmt->bindParam(":imagesCount", $images_count, PDO::PARAM_INT);
        $stmt->bindParam(":likesCount", $likes_count, PDO::PARAM_INT);
        $stmt->bindParam(":commentsCount", $comments_count, PDO::PARAM_INT);
        $stmt->bindParam(":rating", $rating, PDO::PARAM_INT);
        $stmt->bindParam(":modifyAt", $modifyAt, PDO::PARAM_INT);
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);
        $stmt->execute();

        $account = new account($this->db, $this->requestFrom);
        $account->updateCounters();
        unset($account);
    }

    public function info($userId)
    {
        
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = (:userId)  LIMIT 1");
        $stmt->bindParam(":userId", $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $myLike = false;

                if ($this->requestFrom != 0) {

                    if ($this->is_like_exists($userId, $this->requestFrom)) {

                        $myLike = true;
                    }
                }


                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "category" => $row['category'],
                                "price" => $row['price'],
                                "fromUserId" => $row['fromUserId'],
                                "fromUserUsername" => $row['username'],
                                "fromUserFullname" => $row['fullname'],
                                "fromUserPhone" => $row['phone'],
                                "fromUserEmail" => $row['email'],
                                "fromUserGender" => $row['gender'],
                                "fromUserPhoto" => $row['lowPhotoUrl'],
                                "online" => $row['online'],
                                "userTitle" => htmlspecialchars_decode(stripslashes($row['userTitle'])),
                                "userDesc" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "userContent" => stripslashes($row['userContent']),
                                "area" => htmlspecialchars_decode(stripslashes($row['area'])),
                                "country" => htmlspecialchars_decode(stripslashes($row['country'])),
                                "city" => htmlspecialchars_decode(stripslashes($row['city'])),
                                "lat" => $row['lat'],
                                "lng" => $row['lng'],
                                "year" => $row['bYear'],
                                "month" => $row['bMonth'],
                                "day" => $row['bDay'],
                                "previewImgUrl" => $row['previewImgUrl'],
                                "imgUrl" => $row['imgUrl'],
                                "allowComments" => $row['allowComments'],
                                "rating" => $row['rating'],
                                "commentsCount" => $row['commentsCount'],
                                "likesCount" => $row['likesCount'],
                                "myLike" => $myLike,
                                "createAt" => $row['createAt'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "timeAgo" => $time->timeAgo($row['regtime']),
                                "removeAt" => $row['removeAt']);
            }
        }

        return $result;
    }

    public function get($userId = 0)
    {
        if ($userId == 0) {

            $userId = $this->getMaxIdUsers();
            $userId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "userId" => $userId,
                        "users" => array());

        $stmt = $this->db->prepare("SELECT id FROM users WHERE lowPhotoUrl != '' AND removed = 0 AND id < (:userId) ORDER BY id DESC LIMIT 20");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $userInfo = $this->info($row['id']);

                array_push($result['users'], $userInfo);

                $result['userId'] = $userInfo['id'];

                unset($userInfo);
            }
        }

        return $result;
    }
	
    
        
        public function getAllActivesUsers($userId = 0 , $pageNumber = 0)
    
    {
       
       
               $limit = 10;
    if($pageNumber){
             $userId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
                    }
                    
        if ($userId == 0) {

            $userId = $this->getMaxIdUsers();
            $userId++;
        }

         if(!$pageNumber){
                           $offset=0; 
   }
       
       

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "userId" => $userId,
                        "pageNumber" => $pageNumber,
                        "users" => array());
        $stmt = $this->db->prepare("SELECT id FROM users WHERE  removed = 0   AND id < (:userId) ORDER BY id DESC LIMIT $offset,$limit");
        //$stmt = $this->db->prepare("SELECT id FROM users WHERE fromUserId = (:fromUserId) AND removeAt = 0 AND id < (:userId) ORDER BY id DESC LIMIT 20");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $userInfo = $this->info($row['id']);

                array_push($result['users'], $userInfo);

                $result['userId'] = $userInfo['id'];

                unset($userInfo);
            }
        }

        return $result;
    }
	
    
        
        public function getUsersSubAccount($userId = 0 , $pageNumber = 0)
    
    {
        
    $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
       
       
 $limit = 10;
    if($pageNumber){
             $userId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
                    }
                    
        if ($userId == 0) {

            $userId = $this->getMaxIdUsers();
            $userId++;
        }

         if(!$pageNumber){
                           $offset=0; 
   }
       
       

  
        $stmt = $this->db->prepare("SELECT id FROM users WHERE  referredby = (:referredby) AND removed = 0   AND id < (:userId) ORDER BY id DESC LIMIT $offset,$limit");
        $stmt->bindParam(":referredby", $this->requestFrom, PDO::PARAM_INT);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {
            
                  $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "userId" => $userId,
                        "pageNumber" => $pageNumber,
                        "users" => array());

            while ($row = $stmt->fetch()) {

                $userInfo = $this->info($row['id']);

                array_push($result['users'], $userInfo);

                $result['userId'] = $userInfo['id'];

                unset($userInfo);
            }
        }

        return $result;
    }
	
    
    
	public function getAllDrivers($userId = 0)
    {
        if ($userId == 0) {

            $userId = $this->getMaxIdUsers();
            $userId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "userId" => $userId,
                        "users" => array());

        $stmt = $this->db->prepare("SELECT id FROM users WHERE lowPhotoUrl != '' AND removed = 0 AND  account_type = 5 AND id < (:userId)  ORDER BY id DESC LIMIT 20");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $userInfo = $this->info($row['id']);

                array_push($result['users'], $userInfo);

                $result['userId'] = $userInfo['id'];

                unset($userInfo);
            }
        }

        return $result;
    }
	
public function getUserProfil($userId = 0)
    {
        if ($userId == 0) {

            $userId = $this->getMaxIdUsers();
            $userId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "userId" => $userId,
                        "users" => array());

        $stmt = $this->db->prepare("SELECT id FROM users WHERE lowPhotoUrl != '' AND removed = 0 AND id = (:userId) ORDER BY id DESC LIMIT 1");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $userInfo = $this->info($row['id']);

                array_push($result['users'], $userInfo);

                $result['userId'] = $userInfo['id'];

                unset($userInfo);
            }
        }

        return $result;
    }
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
