<?php
/**************************************************************** *
 * arsel.cm engine v1.0                       					  *
 *                                                                *
 * ALLURE                                            	  		  *
 * admin@allure.com                             				  *
 *                                                                *
 * Copyright 2021 BEYALA BEATRICE CEO ALLURE					  *
 ******************************************************************
 */

class slide extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM slide WHERE deleted=0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdLikes()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdslide()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM slide");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM slide WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function info($slideId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM slide WHERE id = (:slideId) LIMIT 1");
        $stmt->bindParam(":slideId", $slideId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $profile = new profile($this->db, $row['author_id']);
                    $profileInfo2 = $profile->get();
                    unset($profile);
					
					$profile = new profile($this->db, $row['manager']);
                    $profileInfo = $profile->get();
                    unset($profile);
				
              $categories = new categories($this->db);
                $categoriesInfo = $categories->info($row['category_id']);
                unset($categories);
				
                 $row['createAt'] = strtotime($row['publish_date']);
                 setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
//$date = date("d M Y H:i:s", strtotime($row['publish_date']));
$date = strftime(" %d %h %Y %H:%M",strtotime($row['publish_date']));
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "status" => $row['status'],
                                "category_id" => $row['category_id'],
                                "author" => $row['author_id'],
								"FromUserfullname" => $profileInfo['fullname'],
								"AuthorUsername" => $profileInfo2['fullname'],
								"AuthorPhoto" => $profileInfo2['lowPhotoUrl'],
                                "contentTitle" => htmlspecialchars_decode(stripslashes($row['title'])),
                                "contentTitle_en" => htmlspecialchars_decode(stripslashes($row['title_en'])),
                                "contentDesc" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "contentDesc_en" => htmlspecialchars_decode(stripslashes($row['description_en'])),
                                "shortContent" => htmlspecialchars_decode(stripslashes($row['shortContent'])),
                                "categoryTitle" => $categoriesInfo['title'],
                                "createAt" => $row['publish_date'],
                                "previewImg" => $row['title_image'],
                                "date" =>$date,
                                "timeAgo" => $time->timeAgo($row['createAt'])
                                );
            }
        }

        return $result;
    }

    public function get($slideId = 0)
    {
      
       if ($slideId == 0) {

            $slideId = $this->getMaxIdslide();
            $slideId++;
        }
        
        
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());

        $stmt = $this->db->prepare("SELECT id FROM slide WHERE deleted = 0 AND id < (:slideId) AND status=1 ORDER BY id DESC");
        $stmt->bindParam(':slideId', $slideId, PDO::PARAM_INT);
       
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }

    
/**
 * ===============Get Content Infos by ID==============================================================================
 */
    public function getContentById($slideId)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());

        $stmt = $this->db->prepare("SELECT id FROM slide WHERE deleted = 0 AND id = (:slideId)");
        $stmt->bindParam(':slideId', $slideId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }

	/**
 * ===============Get Content Infos by ID 25/04/2017==============================================================================
 */
    public function getOthersContentById($slideId)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());

        $stmt = $this->db->prepare("SELECT id FROM slide WHERE deleted = 0 AND id != (:slideId) ORDER BY publish_date DESC limit 3");
        $stmt->bindParam(':slideId', $slideId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	

/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getResultSearch($queryText, $limit)
    {
         if ($slideId == 0) {

            $slideId = $this->getMaxIdslide();
            $slideId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());
						
		$queryText = "%".$queryText."%";
		
        $stmt = $this->db->prepare("SELECT id FROM slide WHERE deleted = 0 AND (title LIKE (:queryText) OR content LIKE (:queryText) OR shortContent LIKE (:queryText)) ORDER BY id DESC LIMIT $limit");
        $stmt->bindParam(':queryText', $queryText, PDO::PARAM_STR);
        //$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	
/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getContentBycategory_id($categoryId,$limit)
    {
         if ($slideId == 0) {

            $slideId = $this->getMaxIdslide();
            $slideId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());

        $stmt = $this->db->prepare("SELECT id FROM slide WHERE  deleted = 0 AND category_id = (:categoryId) ORDER BY id DESC LIMIT $limit");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
        //$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getContentBySubcategory_id($Subcategory_id,$limit)
    {
         if ($slideId == 0) {

            $slideId = $this->getMaxIdslide();
            $slideId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());

        $stmt = $this->db->prepare("SELECT id FROM slide WHERE  deleted = 0 AND subcategory_id = (:Subcategory_id) ORDER BY id DESC LIMIT $limit");
        $stmt->bindParam(':Subcategory_id', $Subcategory_id, PDO::PARAM_INT);
        //$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
 /**
 * ===============Added on april 25 bt TFM==============================================================================
 */
        public function getAllslide2($slideId=0,$limit)
    {
        if ($slideId == 0) {

            $slideId = $this->getMaxIdslide();
            $slideId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "slideId" => $slideId,
                        "slide" => array());

        $stmt = $this->db->prepare("SELECT id FROM slide WHERE  previewImgUrl != '' AND deleted = 0 AND id < (:slideId)  ORDER BY publish_date DESC LIMIT $limit");
    
         $stmt->bindParam(':slideId', $slideId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['slide'], $contentInfo);

                $result['slideId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }   

	
/**
 * ===============Added on april 27/04/2017 bt TFM==============================================================================
 */
 
	public function addLike($like , $countlike, $date)
    {
		date_default_timezone_set("Africa/Douala");
$date = date("Y-m-d H:i:s");

		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("INSERT INTO slide_like (article_id , countlike , date) value (:like , :countlike , :date)");
        $stmt->bindParam(":like", $like, PDO::PARAM_STR);
        $stmt->bindParam(":countlike", $countlike, PDO::PARAM_STR);
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        
        
		$result    = $stmt->execute();
		
        return $result;
    }
	
	
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
