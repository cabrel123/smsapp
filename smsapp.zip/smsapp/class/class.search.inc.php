<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class search extends db_connect
{

    private $requestFrom = 0;
    private $language = 'en';

    public function __construct($dbo = NULL)
    {
        parent::__construct($dbo);
    }

    public function getCarsCount($queryText)
    {
        //$queryText = "%".$queryText."%";

        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE removeAt = 0 AND (cityId = (:city_id))");
        $stmt->bindParam(':city_id', $queryText, PDO::PARAM_STR);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getCount($queryText)
    {
        $queryText = "%".$queryText."%";

        $stmt = $this->db->prepare("SELECT count(*) FROM users WHERE state = 0 AND (login LIKE (:query) OR fullname LIKE (:query) OR email LIKE (:query))");
        $stmt->bindParam(':query', $queryText, PDO::PARAM_STR);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function lastIndex()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM users");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn() + 1;
    }

    public function lastCarsIndex()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars");
        $stmt->execute();
       
        return $number_of_rows = $stmt->fetchColumn() + 1;
    }
    
     public function getMaxCarsIndex()
    {
        $stmt = $this->db->prepare("SELECT max(id) FROM cars");
        $stmt->execute();
        return $number_of_rows = $stmt->fetchColumn();
    }
    
    
      private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM cities");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }


    public function query($queryText = '', $userId = 0)
    {
        $originQuery = $queryText;

        if ($userId == 0) {

            $userId = $this->lastIndex();
            $userId++;
        }

        $users = array("error" => false,
                       "error_code" => ERROR_SUCCESS,
                       "carsCount" => $this->getCount($originQuery),
                       "carId" => $userId,
                       "query" => $originQuery,
                       "cars" => array());

        $queryText = "%".$queryText."%";

        $stmt = $this->db->prepare("SELECT id, regtime FROM users WHERE state = 0 AND (login LIKE (:query) OR fullname LIKE (:query) OR email LIKE (:query) ) AND id < (:userId) ORDER BY regtime DESC LIMIT 20");
        $stmt->bindParam(':query', $queryText, PDO::PARAM_STR);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_STR);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $profile = new profile($this->db, $row['id']);
                    $profile->setRequestFrom($this->requestFrom);

                    array_push($users['cars'], $profile->getShort());

                    $users['carId'] = $row['id'];

                    unset($profile);
                }
            }
        }

        return $users;
    }

         // public function carsQuery($queryText = '', $carId = 0, $limit = 100)
     public function carsQuery($cityName ,$arrivalDate,  $departureDate , $arrivalTime , $depatureDate,   $carId, $limit = 100)
    {
        $originQuery = $cityName;
        //Retrieve city id ;  getCityId($cityName
        
         $cityInfos = explode(",", $cityName);
         $cityName = $cityInfos['0'];
         $cities   = new cities($this->db);
         $cityInfo = $cities->getCityId($cityName);
         unset($cities);
         $cityId   = $cityInfo['cityId'];

        if ($carId == 0) {

            $carId = $this->getMaxCarsIndex();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carsCount" => $this->getCarsCount($cityId),
                        "carId" => $carId,
                        "query" => $originQuery,
                        "cityid" => $cityId,
                        "cars" => array());

        $queryText = "%".$queryText."%";

        //$stmt = $this->db->prepare("SELECT id FROM cars WHERE removeAt = 0 AND city_id = (:cityId) AND id < (:carId) ORDER BY createAt DESC LIMIT :limit");
        $stmt = $this->db->prepare("SELECT id FROM cars WHERE removeAt = 0  AND  cityId = (:cityId) AND id < (:carId)  ORDER BY id DESC LIMIT :limit ");
        $stmt->bindParam(':cityId', $cityId, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);
  

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $car = new cars($this->db);
                    $car->setRequestFrom($this->requestFrom);
					
                    array_push($result['cars'], $car->info($row['id']));

                    $result['carId'] = $row['id'];

                    unset($car);
                }
            }
        }

        return $result;
    }


   /* public function carsQuery($queryText = '', $carId = 0, $limit = 100)
    {
        $originQuery = $queryText;

        if ($carId == 0) {

            $carId = $this->lastCarsIndex();
            $carId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "carsCount" => $this->getCarsCount($originQuery),
                        "carId" => $carId,
                        "query" => $originQuery,
                        "cars" => array());

        $queryText = "%".$queryText."%";

        $stmt = $this->db->prepare("SELECT id FROM cars WHERE removeAt = 0 AND (carTitle LIKE (:query) OR carDesc LIKE (:query) OR carContent LIKE (:query)) AND id < (:carId) ORDER BY createAt DESC LIMIT :limit");
        $stmt->bindParam(':query', $queryText, PDO::PARAM_STR);
        $stmt->bindParam(':carId', $carId, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                while ($row = $stmt->fetch()) {

                    $car = new cars($this->db);
                    $car->setRequestFrom($this->requestFrom);

                    array_push($result['cars'], $car->info($row['id']));

                    $result['carId'] = $row['id'];

                    unset($car);
                }
            }
        }

        return $result;
    }*/

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }
}

