<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class countries extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM countries");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdItems()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM countries");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }

        $currentTime = time();
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();

        $stmt = $this->db->prepare("INSERT INTO countries (title, description, imgUrl, createAt, ip_addr, u_agent) value (:title, :description, :imgUrl, :createAt, :ip_addr, :u_agent)");
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_INT);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "countryId" => $this->db->lastInsertId(),
                            "country" => $this->info($this->db->lastInsertId()));
        }

        return $result;
    }

    public function remove($countryId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $countryInfo = $this->info($countryId);

        if ($countryInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE countries SET removeAt = (:removeAt) WHERE id = (:countryId)");
        $stmt->bindParam(":countryId", $countryId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            //remove all countrys

            $stmt3 = $this->db->prepare("SELECT id FROM cars WHERE category = (:category)");
            $stmt3->bindParam(":category", $countryId, PDO::PARAM_INT);

            if ($stmt3->execute()) {

                while ($row = $stmt->fetch()) {

                    $country = new countrys($this->db);

                    $country->remove($row['id']);

                    unset($country);
                }
            }

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

            $this->recalculate($countryId);
        }

        return $result;
    }

    public function edit($countryId, $title, $description, $imgUrl)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        if (strlen($title) == 0) {

            return $result;
        }

        if (strlen($description) == 0) {

            return $result;
        }

        if (strlen($imgUrl) == 0) {

            return $result;
        }


        $stmt = $this->db->prepare("UPDATE countries SET title = (:title), description = (:description), imgUrl = (:imgUrl) WHERE id = (:countryId)");
        $stmt->bindParam(":countryId", $countryId, PDO::PARAM_INT);
        $stmt->bindParam(":title", $title, PDO::PARAM_STR);
        $stmt->bindParam(":description", $description, PDO::PARAM_STR);
        $stmt->bindParam(":imgUrl", $imgUrl, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);

        }

        return $result;
    }

    public function recalculate($categoryId) {

        $countrys_count = 0;

        $countrys_count = $this->getItemsCount($categoryId);

        $stmt = $this->db->prepare("UPDATE countries SET countrysCount = (:countrysCount) WHERE id = (:categoryId)");
        $stmt->bindParam(":countrysCount", $countrys_count, PDO::PARAM_INT);
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->execute();
    }

    private function getItemsCount($categoryId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM cars WHERE category = (:category) AND removeAt = 0");
        $stmt->bindParam(":category", $categoryId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function info($countryId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM countries WHERE id = (:countryId) LIMIT 1");
        $stmt->bindParam(":countryId", $countryId, PDO::PARAM_INT);
        

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
                
                 	$currency 		= new currencies($this->db);
         			$currencyInfo 	= $currency->info($row['currencyId']);
         			unset($currency);

                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "countrysCount" => $row['countrysCount'],
                                "sortname" => htmlspecialchars_decode(stripslashes($row['sortname'])),
                                "name" => htmlspecialchars_decode(stripslashes($row['name'])),
                                "phonecode" => $row['phonecode'],
                                "createAt" => $row['createAt'],
                                "date" => date("Y-m-d H:i:s", $row['createAt']),
                                "removeAt" => $row['removeAt'],
                                "currencyIso" => $currencyInfo['iso'],
                                "currencyName" => htmlspecialchars_decode(stripslashes($currencyInfo['name']))
                                
                                );
            }
        }

        return $result;
    }

    public function get($countryId = 0)
    {
        if ($countryId == 0) {

            $countryId = $this->getMaxIdItems();
            $countryId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "countryId" => $countryId,
                        "countries" => array());

        $stmt = $this->db->prepare("SELECT id FROM countries WHERE removeAt = 0 AND id < (:countryId) ORDER BY id DESC LIMIT 50");
        $stmt->bindParam(':countryId', $countryId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $countryInfo = $this->info($row['id']);

                array_push($result['countries'], $countryInfo);

                $result['countryId'] = $countryInfo['id'];

                unset($countryInfo);
            }
        }

        return $result;
    }

    public function getList()
    {
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "countrys" => array());

        $stmt = $this->db->prepare("SELECT id FROM countries WHERE removeAt = 0 ORDER BY id");

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $countryInfo = $this->info($row['id']);

                array_push($result['countrys'], $countryInfo);

                unset($countryInfo);
            }
        }

        return $result;
    }

    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
