<?php
/**************************************************************** *
 * arsel.cm engine v1.0                       					  *
 *                                                                *
 * ALLURE                                            	  		  *
 * admin@allure.com                             				  *
 *                                                                *
 * Copyright 2021 BEYALA BEATRICE CEO ALLURE					  *
 ******************************************************************
 */

class faqs extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM faqs");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdLikes()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM likes");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdFaqs()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM faqs");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function count()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM faqs WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function add($question="" , $answer="" , $fromUserId=0 , $account_type=0)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN,
                        "error_message" => $answer);

    
        if (strlen($question) == 0) {

            return $result;
        }

        if (strlen($answer) == 0) {

            return $result;
        }


        $currentDate = date("Y-m-d H:i:s");
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();
        $status  = '1';

        $stmt = $this->db->prepare("INSERT INTO faqs (question , answer , createAt ,status , fromUserId , account_type) value (:question , :answer , :createAt ,:status , :fromUserId , :account_type)");
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":account_type", $account_type, PDO::PARAM_INT);
        $stmt->bindParam(":question", $question, PDO::PARAM_STR);
        $stmt->bindParam(":answer", $answer, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentDate, PDO::PARAM_INT);
        $stmt->bindParam(":status", $status, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS,
                            "faqId" => $this->db->lastInsertId(),
                            "faq" => $this->info($this->db->lastInsertId()));

        }

        return $result;
    }

    public function deleteAllByUserId($userId)
    {
        $stmt = $this->db->prepare("SELECT id FROM faqs WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(':fromUserId', $userId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $this->remove($row['id']);
            }
        }
    }

    public function remove($faqId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $faqInfo = $this->info($faqId);

        if ($faqInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE faqs SET removeAt = (:removeAt) WHERE id = (:faqId)");
        $stmt->bindParam(":faqId", $faqId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);

        if ($stmt->execute()) {

            // remove all notifications by likes and comments

            $stmt2 = $this->db->prepare("DELETE FROM notifications WHERE faqId = (:faqId)");
            $stmt2->bindParam(":faqId", $faqId, PDO::PARAM_INT);
            $stmt2->execute();

            //remove all comments to faq

            $stmt3 = $this->db->prepare("UPDATE comments SET removeAt = (:removeAt) WHERE faqId = (:faqId)");
            $stmt3->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt3->bindParam(":faqId", $faqId, PDO::PARAM_INT);
            $stmt3->execute();

            //remove all likes to faq

            $stmt = $this->db->prepare("UPDATE likes SET removeAt = (:removeAt) WHERE faqId = (:faqId) AND removeAt = 0");
            $stmt->bindParam(":faqId", $faqId, PDO::PARAM_INT);
            $stmt->bindParam(":removeAt", $currentTime, PDO::PARAM_INT);
            $stmt->execute();

            $cat = new categories($this->db);
            $cat->recalculate($faqInfo['category']);

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        $this->recalculate($faqId);

        return $result;
    }

    public function restore($faqId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $faqInfo = $this->info($faqId);

        if ($faqInfo['error'] === true) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE faqs SET removeAt = 0 WHERE id = (:faqId)");
        $stmt->bindParam(":faqId", $faqId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

    public function edit($faqId = "" , $question="" , $answer="" , $fromUserId=0 , $account_type=0)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

       if (strlen($question) == 0) {

            return $result;
        }

        if (strlen($answer) == 0) {

            return $result;
        }


        $currentDate = date("Y-m-d H:i:s");
        $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();
        $status  = '1';


        $stmt = $this->db->prepare("UPDATE faqs SET question = (:question), answer = (:answer), createAt = (:createAt), status = (:status), fromUserId = (:fromUserId), account_type = (:account_type)  WHERE id = (:faqId)");
        
        $stmt->bindParam(":faqId", $faqId, PDO::PARAM_INT);
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":account_type", $account_type, PDO::PARAM_INT);
        $stmt->bindParam(":question", $question, PDO::PARAM_STR);
        $stmt->bindParam(":answer", $answer, PDO::PARAM_STR);
        $stmt->bindParam(":createAt", $currentDate, PDO::PARAM_INT);
        $stmt->bindParam(":status", $status, PDO::PARAM_INT);
        
        
        

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }


    public function info($faqId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM faqs WHERE id = (:faqId) LIMIT 1");
        $stmt->bindParam(":faqId", $faqId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);


                $result = array("error" => false,
                                "error_code"        => ERROR_SUCCESS,
                                "id"                => $row['id'],
                                "fromUserId"        => $row['fromUserId'],
                                "accountType"       => $row['account_type'],
                                "faqQuestion"       => htmlspecialchars_decode(stripslashes($row['question'])),
                                "faqAnswer"         => htmlspecialchars_decode(stripslashes($row['answer'])),
                                "updateAt"          => $row['updateAt'],
                                "createAt"          => $row['createAt'],
                                "status"            => $row['status'],
                                "removeAt"          => $row['removeAt'],
                                "target_url"        => APP_URL
                                );
            }
        }

        return $result;
    }

    public function get($faqId = 0 , $pageNumber = 0)
    {
        
        $limit = 20;
    if($pageNumber){
             $faqId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
                    }
                    
        if ($faqId == 0) {
   
            $faqId = $this->getMaxIdFaqs();
            $faqId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "faqId" => $faqId,
                        "pageNumber" => $pageNumber,
                        "faqs" => array());

        $stmt = $this->db->prepare("SELECT id FROM faqs WHERE removeAt = 0  AND status = 1 AND id < (:faqId) ORDER BY id DESC LIMIT $offset,$limit");
        $stmt->bindParam(':faqId', $faqId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $faqInfo = $this->info($row['id']);

                array_push($result['faqs'], $faqInfo);

                $result['faqId'] = $faqInfo['id'];

                unset($faqInfo);
            }
        }

        return $result;
    }
    

    public function deleteFaq($faqId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
        $removeAt =  date("Y-m-d H:i:s");
        $stmt = $this->db->prepare("UPDATE faqs SET status = 0 , removeAt = (:removeAt)  WHERE id = (:faqId)");
        $stmt->bindParam(":faqId", $faqId, PDO::PARAM_INT);
        $stmt->bindParam(":removeAt", $removeAt, PDO::PARAM_STR);

        if ($stmt->execute()) {

            $result = array('error' => false,
                            'error_code' => ERROR_SUCCESS);
        }

        return $result;
    }
   

//generate Ramdom nuùber to insert to db
        public function db_random_number($tableName , $random_id)
        { 
        global $db;
// run an endless loop
        while(1) {
// generate unique random number
            $randomNumber = rand(0, 999999999);
// check if it exists in database
            $query = "SELECT * FROM $tableName WHERE $random_id=$randomNumber";
            $res = $this->db->query($query);
            $rowCount = $res->fetchColumn();
//$rowCount = mysql_num_rows($res);
// if not found in the db (it is unique), break out of the loop
            if($rowCount < 1) {
                break;
            }
        }
// pad the number with zeros (if needed)
            $paded = str_pad($randomNumber, 6, '0', STR_PAD_LEFT);
// dash delimited string to be displayed
            $delimited = '';
// add dashes
            for($i = 0; $i < 9; $i++) {
// add a character
            $delimited .= $paded[$i];
// add dashes wherever appropriate
            if($i == 2 || $i == 5) {
//$delimited .= '-';
            $delimited .= '';
            }
        }
            return $delimited;

            }
			



    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
