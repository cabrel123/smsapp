<?php

/**************************************************************** *
 * econsultinginternational.com engine v1.0                       *
 *                                                                *
 * Africa Vision Tech                                             *
 * admin@econsultinginternational.com                             *
 *                                                                *
 * Copyright 2017 Francois Modeste CEO ECONSULTING INTERNATIONAL  *
 ******************************************************************/

class contents extends db_connect
{
	private $requestFrom = 0;
    private $language = 'en';
    private $profileId = 0;

	public function __construct($dbo = NULL)
    {
		parent::__construct($dbo);
	}

    public function getAllCount()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM contents WHERE deleted = 0 AND flagcontent = 0");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	public function getAllCountContinousNews()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM contents WHERE deleted = 0 AND flagcontent = 6");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    public function getAllCountContentByCategory($categoryId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM contents WHERE deleted = 0 AND category_id = (:categoryId) AND statut = 1");
        $stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	public function getAllCountResultofResearch($queryText)
    {
        $queryText = "%".$queryText."%";
        $stmt = $this->db->prepare("SELECT count(*) FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND (title LIKE (:queryText) OR description LIKE (:queryText) OR keyword LIKE (:queryText))");
        $stmt->bindParam(':queryText', $queryText, PDO::PARAM_STR);
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	
	
	public function CheckifcontentExist($contentId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM contents WHERE id = (:contentId) AND statut = 0 AND deleted = '0' LIMIT 1 ");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
		$stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function getMaxIdContents()
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM contents");
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	private function getMaxIdContentsBycat($categoryId)
    {
        $stmt = $this->db->prepare("SELECT MAX(id) FROM contents WHERE category_id = (:categoryId)");
		$stmt->bindParam(":categoryId", $categoryId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
	public function getTypeContent($contentId)
    {
        $stmt = $this->db->prepare("SELECT flagcontent FROM contents WHERE id = (:contentId) AND deleted = 0 LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['flagcontent'];
        }

        return 0;
    }
	public function getContentTitle($contentId)
    {
        $stmt = $this->db->prepare("SELECT title FROM contents WHERE id = (:contentId) AND deleted = 0 LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['title'];
        }

        return '';
    }
	
	public function getContentDesc($contentId)
    {
        $stmt = $this->db->prepare("SELECT description FROM contents WHERE id = (:contentId) AND deleted = 0 LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['description'];
        }

        return '';
    }
	
	public function getContentCategoryId($contentId)
    {
        $stmt = $this->db->prepare("SELECT category_id FROM contents WHERE id = (:contentId) AND deleted = 0 LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();

            return $row['category_id'];
        }

        return 0;
    }
	
	public function getContentPostedDate($contentId)
    {
        $stmt = $this->db->prepare("SELECT createAt FROM contents WHERE id = (:contentId) AND deleted = 0 LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $row = $stmt->fetch();
			setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
			$date = strftime(" %d %h %Y %H:%M",strtotime($row['createAt']));
            return $date;
        }

        return '';
    }
	
    public function count()
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM contents WHERE fromUserId = (:fromUserId) AND removeAt = 0");
        $stmt->bindParam(":fromUserId", $this->requestFrom, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }


	
   public function remove($contentId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $itemInfo = $this->info($contentId);

        if ($itemInfo['error'] === true) {

            return $result;
        }

        $currentTime = time();

        $stmt = $this->db->prepare("UPDATE contents SET deleted = (:deleted) WHERE id = (:contentId)");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->bindParam(":deleted", $currentTime, PDO::PARAM_INT);

		$stmt->execute();

        return $result;
    }

    public function restore($contentId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $contentInfo = $this->info($contentId);

        if ($contentInfo['error'] === true) {

            return $result;
        }

        $stmt = $this->db->prepare("UPDATE contents SET removeAt = 0 WHERE id = (:contentId)");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            $result = array("error" => false,
                            "error_code" => ERROR_SUCCESS);
        }

        return $result;
    }

	
	 private function is_count_exists($contentId)
    {
        $stmt = $this->db->prepare("SELECT id FROM most_read_article WHERE contentId = (:contentId) LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            return true;
        }

        return false;
    }
	
	
public function TrankingLink($contentId)
    {
		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
		
		 
		
		if ($this->is_count_exists($contentId)) {
			
		$content_info = $this->info2($contentId);
        $count = $content_info['count'] + 1;
		date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
		
		
        $stmt = $this->db->prepare("UPDATE most_read_article SET count = (:count), createAt = (:createAt) WHERE contentId = (:contentId)");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->bindParam(":count", $count, PDO::PARAM_INT);
		$stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
        $stmt->execute();
			
		}else{
			
			date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
        $currentTime = $currentTime;
       $ip_addr = helper::ip_addr();
        $u_agent = helper::u_agent();
			$count = 1;
			
        $stmt = $this->db->prepare("INSERT INTO most_read_article (contentId ,count,createAt, u_agent, ip_addr) value (:contentId , :count, :createAt, :u_agent, :ip_addr)");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->bindParam(":count", $count, PDO::PARAM_INT);
        $stmt->bindParam(":createAt", $currentTime, PDO::PARAM_STR);
        $stmt->bindParam(":u_agent", $u_agent, PDO::PARAM_STR);
        $stmt->bindParam(":ip_addr", $ip_addr, PDO::PARAM_STR);
        
        
		$result    = $stmt->execute();
		}
        return $result;
    }

    private function getLikesCount($contentId)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM likes WHERE contentId = (:contentId) AND removeAt = 0");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }

    private function is_like_exists($contentId, $fromUserId)
    {
        $stmt = $this->db->prepare("SELECT id FROM likes WHERE fromUserId = (:fromUserId) AND contentId = (:contentId) AND removeAt = 0 LIMIT 1");
        $stmt->bindParam(":fromUserId", $fromUserId, PDO::PARAM_INT);
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            return true;
        }

        return false;
    }

    public function recalculate($contentId) {

        $comments_count = 0;
        $likes_count = 0;
        $rating = 0;
        $images_count = 0;

        $modifyAt = time();

        $likes_count = $this->getLikesCount($contentId);

        $comments = new comments($this->db);
        $comments_count = $comments->count($contentId);
        unset($comments);

        $images = new images($this->db);
        $images_count = $images->count($contentId);
        unset($images);

        $rating = $likes_count + $comments_count;

        $stmt = $this->db->prepare("UPDATE contents SET imagesCount = (:imagesCount), likesCount = (:likesCount), commentsCount = (:commentsCount), rating = (:rating), modifyAt = (:modifyAt) WHERE id = (:contentId)");
        $stmt->bindParam(":imagesCount", $images_count, PDO::PARAM_INT);
        $stmt->bindParam(":likesCount", $likes_count, PDO::PARAM_INT);
        $stmt->bindParam(":commentsCount", $comments_count, PDO::PARAM_INT);
        $stmt->bindParam(":rating", $rating, PDO::PARAM_INT);
        $stmt->bindParam(":modifyAt", $modifyAt, PDO::PARAM_INT);
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);
        $stmt->execute();

        $account = new account($this->db, $this->requestFrom);
        $account->updateCounters();
        unset($account);
    }

    public function info($contentId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM contents WHERE id = (:contentId) LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();

                $time = new language($this->db, $this->language);

                $myLike = false;

                if ($this->requestFrom != 0) {

                    if ($this->is_like_exists($contentId, $this->requestFrom)) {

                        $myLike = true;
                    }
                }

               /* if ($row['contentType'] != 0) {

                    $profile = new profile($this->db, $row['fromUserId']);
                    $profileInfo = $profile->get();
                    unset($profile);

                } else {

                    $profileInfo = array("username" => "",
                                         "fullname" => "",
                                         "lowPhotoUrl" => "");
                }
*/
				$profile = new profile($this->db, $row['manager']);
                    $profileInfo = $profile->get();
                    unset($profile);
					
					$profile = new profile($this->db, $row['author']);
                    $profileInfo2 = $profile->get();
                    unset($profile);
					
                $category = new categories($this->db);
                $categoryInfo = $category->info($row['category_id']);
                unset($category);
				
                $sub_categories = new sub_categories($this->db);
                $sub_categoriesInfo = $sub_categories->info($row['id_subcategory']);
                unset($sub_categories);
				
				$comments = new comments($this->db);
				$totalcomment = $comments->CountContentComment($row['id']);
				unset($comments);
				
                 $contentInfo = $this->info($row['articleId']);
		
					$ArticleTitle = $contentInfo['title'];
		   
                 setlocale (LC_TIME, "fr_FR.utf8"); //Setting the locale to French with UTF-8
$date2 = date("d.M.Y", strtotime($row['createAt']));
$day = strftime("%d", strtotime($row['createAt']));
$month = strftime("%h", strtotime($row['createAt']));
$year = strftime("%Y", strtotime($row['createAt']));

$date = strftime(" %d %h %Y %H:%M",strtotime($row['createAt']));
                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "id" => $row['id'],
                                "status" => $row['statut'],
                                "priority" => $row['priority'],
                                "category_id" => $row['category_id'],
                                "id_subcategory" => $row['id_subcategory'],
                                "contentTitle" => htmlspecialchars_decode(stripslashes($row['title'])),
                                "contentTitle_en" => htmlspecialchars_decode(stripslashes($row['title_en'])),
                                "contentDesc" => htmlspecialchars_decode(stripslashes($row['description'])),
                                "contentDesc_en" => htmlspecialchars_decode(stripslashes($row['description_en'])),
                                "shortContent" => htmlspecialchars_decode(stripslashes($row['shortContent'])),
                                "articleId" => $row['articleId'],
                                "previewImg" => $row['previewImg'],
                                "ArticleTitle" => $ArticleTitle,
                                "FromUsername" => $profileInfo['fullname'],
                                "AuthorUsername" => $profileInfo2['fullname'],
                                "author" => $row['author'],
                                "flagfeatured" => $row['flagfeatured'],
                                "keyword" => $row['keyword'],
                                "createAt" => $row['createAt'],
                                "categoryTitle" => $categoryInfo['title_fr'],
                                "subcategoryTitle" => $sub_categoriesInfo['title_fr'],
                                "date" =>$date,
                                "date2" =>$date2,
                                "day" =>$day,
                                "month" =>$month,
                                "year" =>$year,
                                "totalcomment" =>$totalcomment,
                                "timeAgo" => $time->timeAgo($row['createAt'])
             
                                );
            }
        }

        return $result;
    }

	
	public function info2($contentId)
    {
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);

        $stmt = $this->db->prepare("SELECT * FROM most_read_article WHERE contentId = (:contentId) LIMIT 1");
        $stmt->bindParam(":contentId", $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            if ($stmt->rowCount() > 0) {

                $row = $stmt->fetch();
				
                $contentsInfo = $this->info($row['contentId']);

                $time = new language($this->db, $this->language);


                $result = array("error" => false,
                                "error_code" => ERROR_SUCCESS,
                                "count" => $row['count'],
                                "contentId" => $row['contentId'],
                                "contentTitle" => $contentsInfo['contentTitle'],
                                "countlike" => $contentsInfo['countlike'],
                                "timeAgo" => $time->timeAgo($row['createAt'])
             
                                );
            }
        }
      
        return $result;
    }
	
    public function get($contentId = 0, $pageNumber)
    {
        $limit = 50;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 0 AND id < (:contentId) ORDER BY createAt DESC LIMIT $offset,$limit");
        $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	
 /**
 * ===============get all news contents==============================================================================
 */	
	
	public function getRecentNews($contentId = 0)
    {
       
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
       

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND id < (:contentId) AND previewImg != '' ORDER BY createAt DESC LIMIT 3");
        $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	
 /**
 * ===============get all news contents==============================================================================
 */	
	
	public function getAllNews($contentId = 0, $pageNumber)
    {
        $limit = 6;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND id < (:contentId) ORDER BY createAt DESC LIMIT $offset,$limit");
        $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	
 /**
 * ===============get all testimonials contents==============================================================================
 */
        public function getAllContentsTestimonial($contentId=0, $pageNumber)
    {
       

		$limit = 15;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }
   
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND id < (:contentId) AND flagcontent = 1 ORDER BY createAt DESC LIMIT $offset,$limit");
    
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }   
	
	
	
 /**
 * ===============get all recruitment contents==============================================================================
 */
        public function getAllRecruitmentContents($contentId=0, $pageNumber)
    {
       

		$limit = 15;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }
   
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND id < (:contentId) AND flagcontent = 4 AND statut=1 ORDER BY createAt DESC LIMIT $offset,$limit");
    
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    } 
	
 /**
 * ===============get all sponsored contents==============================================================================
 */
        public function getAllSponsorCOntent($contentId=0, $pageNumber)
    {
       

		$limit = 15;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }
   
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND id < (:contentId) AND flagcontent = 5 ORDER BY createAt DESC LIMIT $offset,$limit");
    
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    } 	
  /**
 * ===============get all sentence of day contents==============================================================================
 */
        public function getAllContentsSentenceOfDay($contentId=0, $pageNumber)
    {
       

		$limit = 15;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }
   
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND id < (:contentId) AND flagcontent = 2 ORDER BY createAt DESC LIMIT $offset,$limit");
    
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }   
  
/**
 * ===============get content blog==============================================================================
 */
    public function getContentBlog($categoryId, $pageNumber)
    {
    $limit = 6;
    if($pageNumber){
             $contentId = 0;
        if($pageNumber=='1'){
                           $offset=0;                      
                          }else{
                           $offset = ($pageNumber - 1) * $limit;
                          }
						  
                    }
                    
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContentsBycat($categoryId);
            $contentId++;
        }
        
         if(!$pageNumber){
                           $offset=0; 
   }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND statut = 1 AND category_id = (:categoryId) ORDER BY id DESC LIMIT $offset,$limit");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
        
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	
/**
 * ===============Get Content Infos by ID==============================================================================
 */
    public function getContentOtherId($contentId, $flagcontent)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND id != (:contentId) AND statut = 1 AND flagcontent = (:flagcontent) ORDER BY createAt DESC LIMIT 2");
        $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);
        $stmt->bindParam(':flagcontent', $flagcontent, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	

     public function getBreakingNews($contentId)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND statut = 1 AND flagcontent = 1 ORDER BY createAt DESC LIMIT 1");
        //$stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    } 
/**
 * ===============Get Content Infos by ID==============================================================================
 */
    public function getContentById($contentId)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND id = (:contentId)");
        $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }

	/**
 * ===============Get Content Infos by ID 25/04/2017==============================================================================
 */
    public function getOthersContentById($categoryId, $contentId)
    {

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND category_id = (:categoryId) AND id != (:contentId) ORDER BY id DESC limit 2");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
        $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
	
/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getContentByCatAndid_subcategory($categoryId,$id_subcategory, $limit)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND statut = 1 AND category_id = (:categoryId) AND id_subcategory = (:id_subcategory) ORDER BY id DESC LIMIT $limit");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
         $stmt->bindParam(':id_subcategory', $id_subcategory, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getContentBycategory($categoryId)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND statut = 1 AND category_id = (:categoryId) ORDER BY createAt DESC LIMIT 8");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
        //$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
/**
 * ===============Fonction to search content by keyword==============================================================================
 */
        public function getResultSearch($contentId= 0, $queryText)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 
		$queryText = "%".$queryText."%";
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "sql" => "SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND (title LIKE '$queryText' OR description LIKE '$queryText' OR keyword LIKE '$queryText') ORDER BY createAt DESC LIMIT 12",
                        "contents" => array());
						
		
		
        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND (title LIKE (:queryText) OR description LIKE (:queryText) OR keyword LIKE (:queryText)) ORDER BY createAt DESC LIMIT 12");
        $stmt->bindParam(':queryText', $queryText, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }

/**
 * ===============Fonction to search document by keyword==============================================================================
 */
    public function getResultContentSearchByCategory($contentId= 0, $queryText, $category_id)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 
		$queryText = "%".$queryText."%";
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "sql" => "SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND (title LIKE '$queryText' OR description LIKE '$queryText' OR keyword LIKE '$queryText') ORDER BY createAt DESC LIMIT 12",
                        "contents" => array());
						
		
		
        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND category_id = (:category_id) AND statut=1 AND (title LIKE (:queryText) OR description LIKE (:queryText) OR keyword LIKE (:queryText)) ORDER BY createAt DESC LIMIT 12");
        $stmt->bindParam(':queryText', $queryText, PDO::PARAM_STR);
        $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }

/**
 * ===============Fonction to search content by keyword==============================================================================
 */
        public function getResultContentSearch($contentId= 0, $queryText)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 
		$queryText = "%".$queryText."%";
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "sql" => "SELECT id FROM contents WHERE deleted = 0 AND flagcontent = 6 AND statut=1 AND (title LIKE '$queryText' OR description LIKE '$queryText' OR keyword LIKE '$queryText') ORDER BY createAt DESC LIMIT 12",
                        "contents" => array());
						
		
		
        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND statut=1 AND (title LIKE (:queryText) OR description LIKE (:queryText) OR keyword LIKE (:queryText)) ORDER BY createAt DESC LIMIT 12");
        $stmt->bindParam(':queryText', $queryText, PDO::PARAM_STR);
        
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }	
/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getContentBycategory_id($categoryId,$limit)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND statut = 1 AND category_id = (:categoryId) ORDER BY id DESC LIMIT $limit");
        $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
        //$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
/**
 * ===============Added on april 24/04/2017 bt TFM==============================================================================
 */
        public function getContentByid_subcategory($id_subcategory)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  deleted = 0 AND statut = 1 AND id_subcategory = (:id_subcategory) ORDER BY createAt DESC");
        $stmt->bindParam(':id_subcategory', $id_subcategory, PDO::PARAM_INT);
        
        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }
 /**
 * ===============Added on april 25 bt TFM==============================================================================
 */
        public function getAllContents2($contentId=0,$limit)
    {
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  title_image != '' AND deleted = 0 AND publish_status = 1 AND id < (:contentId)  ORDER BY publish_date DESC LIMIT $limit");
    
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }   

   /**
 * ===============Added on april 25 bt TFM==============================================================================
 */
        public function getAllContents3($contentId=0,$limit)
    {
        if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        }

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE deleted = 0 AND publish_status = 1 AND id < (:contentId) AND id_subcategory != 10 ORDER BY position DESC , publish_date DESC LIMIT $limit");
    
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    } 	
	
	public function getIfSubscriberExist($email)
    {
        $stmt = $this->db->prepare("SELECT count(*) FROM newsletter WHERE email = (:email)");
		$stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->execute();

        return $number_of_rows = $stmt->fetchColumn();
    }
	
public function SubscribeNewsletter($email,$name)
    {
		 date_default_timezone_set("Africa/Douala");
		$currentTime = date('Y-m-d H:i:s');
        $currentTime = $currentTime;
        $group = 1;
		
        $result = array("error" => true,
                        "error_code" => ERROR_UNKNOWN);
		$table 			= "newsletter";
		
		
        $stmt = $this->db->prepare("INSERT INTO newsletter (email ,name,groups, date) value (:email , :name, :group, :date)");
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":group", $group, PDO::PARAM_STR);
        $stmt->bindParam(":date", $currentTime, PDO::PARAM_STR);
        
        
		$result    = $stmt->execute();
		
        return $result;
    }
/**
 * ===============Added on april 19/04/2017 bt TFM==============================================================================
 */
        public function getAllContentsAvailable($cityId)
    {
         if ($contentId == 0) {

            $contentId = $this->getMaxIdContents();
            $contentId++;
        } 

        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "contentId" => $contentId,
                        "contents" => array());

        $stmt = $this->db->prepare("SELECT id FROM contents WHERE  removeAt = 0 AND publish_status = 1 AND cityId = (:cityId)");
        //$stmt->bindParam(':fromUserId', $profileId, PDO::PARAM_INT);
         $stmt->bindParam(':contentId', $contentId, PDO::PARAM_INT);

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info($row['id']);

                array_push($result['contents'], $contentInfo);

                $result['contentId'] = $contentInfo['id'];

                unset($contentInfo);
            }
        }

        return $result;
    }	
  /**
 * ===============get most read article==============================================================================
 */
        public function getMostReadArticle()
    {
        
        $result = array("error" => false,
                        "error_code" => ERROR_SUCCESS,
                        "items" => array());

        $stmt = $this->db->prepare("SELECT DISTINCT(contentId) FROM most_read_article WHERE  count > 4 AND DATEDIFF(`createAt`, NOW()) < 7  ORDER BY id DESC LIMIT 5");
    

        if ($stmt->execute()) {

            while ($row = $stmt->fetch()) {

                $contentInfo = $this->info2($row['contentId']);

                array_push($result['items'], $contentInfo);

                $result['contentId'] = $contentInfo['contentId'];

                unset($contentInfo);
            }
        }

        return $result;
    }  
	
	
    public function setLanguage($language)
    {
        $this->language = $language;
    }

    public function getLanguage()
    {
        return $this->language;
    }

    public function setRequestFrom($requestFrom)
    {
        $this->requestFrom = $requestFrom;
    }

    public function getRequestFrom()
    {
        return $this->requestFrom;
    }

    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;
    }

    public function getProfileId()
    {
        return $this->profileId;
    }
}
