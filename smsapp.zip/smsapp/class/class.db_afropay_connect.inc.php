<?php

/*!
 * ifsoft.co.uk v1.0
 *
 * http://ifsoft.com.ua, http://ifsoft.co.uk
 * qascript@ifsoft.co.uk
 *
 * Copyright 2012-2016 Demyanchuk Dmitry (https://vk.com/dmitry.demyanchuk)
 */
 if($class=="profile"){
              
$C['DB_HOST'] = "localhost";                                //localhost or your db host
$C['DB_USER'] = "afropay";                             //your db user
$C['DB_PASS'] = "X&DUGX#x9Cf5";                         //your db password
$C['DB_NAME'] = "afropay";                             //your db name

        }

    foreach ($C as $name => $val) {

        define($name, $val);
    }


class db_connect
{

    protected $db;

    protected function __construct($db = NULL)
    {

        if (is_object($db)) {

            $this->db = $db;

        }  else  {

            $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME;

            try  {

                $this->db = new PDO($dsn, DB_USER, DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));

//                $this->db = new PDO($dsn, DB_USER, DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"));

            } catch (Exception $e) {

                die ($e->getMessage());
            }
        }
    }
}
