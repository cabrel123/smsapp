<?php
/**************************************************************** *
 * SMSAPP engine v1.0        					  				  *
 *                                                                *
 * 						                                          *
 * monkamcabrel11@gmail.com                             		  *
 *                                                                *
 * Copyright 2023 MONKAM CABREL									  *
 ******************************************************************
 */
$TEXT = array();
$SEX = array("Male" => 0, "Female" => 1);

$TEXT['lang-code'] = "fr";
$TEXT['lang-name'] = "Fr";
    
/**
 *     ==============New translation start here =========================
 */

//Header
define ('SITE_TITLE', 'SMSAPP | Demo');
define ('SITE_DESC', 'Application démo de SMS pour TPE');




//Default
define ('LOGIN', 'Connexion');
define ('LOGIN_TEXT', 'Connectez-vous à votre espace utilisateur');
define ('USERNAME', 'Nom d\'utilisateur');
define ('PASSWORD', 'Mot de passe');
define ('PHONE', 'Numéro de téléphone');
define ('SIGNIN', 'Se connecter');

//Footer
