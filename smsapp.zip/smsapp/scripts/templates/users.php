<!-- Page Body -->
<div class="page-body">
    <div class="row">
        <div class="col-lg-6 col-sm-6 col-xs-12">
            <!--  <div class="widget flat radius-bordered       widget-body bordered-top bordered-red"> -->
            <div class="widget flat radius-bordered">
                <div class="widget-header bg-danger"> <span class="widget-caption"><?php echo  ADD_ACCOUNT?></span> </div>
                <div class="widget-body">
                    <div id="registration-form">
                        <div class="smart-forms">

                            <form method="post" action="" enctype="multipart/form-data" id="addcategory" name="addGroup-form" role="form">
                                 
                                <div class="form-body theme-blue">

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail2">
                                                   <?php echo FULLNAME ?>
                                                </label>
                                                <label for="groupname" class="field input-icon icon-right">
                                                    <input type="text" class="form-control gui-input" name="fullname" placeholder="<?php echo FULLNAME ?>" > <i class="fa fa-list blue"></i> </label>
                                            </div>
											<div class="form-group">
                                                <label for="exampleInputEmail2">
                                                   <?php echo LASTNAME ?>
                                                </label>
                                                <label for="groupname" class="field input-icon icon-right">
                                                    <input type="text" class="form-control gui-input" name="lastname" placeholder="<?php echo LASTNAME ?>" > <i class="fa fa-list blue"></i> </label>
                                            </div>
											<div class="form-group">
                                                <label for="exampleInputEmail2">
                                                   <?php echo EMAIL ?>
                                                </label>
                                                <label for="groupname" class="field input-icon icon-right">
                                                    <input type="email" class="form-control gui-input" name="email" placeholder="<?php echo EMAIL ?>" > <i class="fa fa-list blue"></i> </label>
                                            </div>
											<div class="form-group">
                                                <label for="exampleInputEmail2">
                                                   <?php echo PHONE ?>
                                                </label>
                                                <label for="groupname" class="field input-icon icon-right">
                                                    <input type="tel" class="form-control gui-input" name="phone" placeholder="<?php echo PHONE ?>" > <i class="fa fa-list blue"></i> </label>
                                            </div>
											<div class="form-group">
                                                <label for="exampleInputEmail2">
                                                   <?php echo CATEGORY ?>
                                                </label>
                                                <label for="groupname" class="field input-icon icon-right">
                                                   <select data-style="btn-white" data-live-search="true" class=" form-control" name="categoryId">
													<option value="">-- <?php echo $LANG['label-select']; ?> --</option>
													<?php
														$result 							= $categories->get($itemId=0);
														//print_r($result);
														$items_loaded 						= count($result['items']);

														if ($items_loaded != 0) {

															foreach ($result['items'] as $key => $value) {

														?>
														<option value="<?php echo $value['id']; ?>"><?php echo $value['title']; ?></option>
														<?php
															}
															
														} 
													?>
												</select>
												   </label>
                                            </div>
                                        </div>
                                    </div>
                                    <button id="submit" type="submit" data-btntext-sending="SENDING..." class="btn btn-danger btn-position-right"> <i class="fa fa-send"></i>
                                        <?php echo SAVE ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id ="latestSmsSent" class="col-lg-6 col-sm-12 col-xs-12">
            <div class="orders-container">
                <div class="orders-header">
                    <h6><?php echo CATEGORY?></h6> </div>
                <ul class="orders-list">
				<?php
						$pageNumber = $_GET['p'];
					$result 							= $categories->get($itemId = 0,$pageNumber);
					//print_r($result);
					$items_loaded 						= count($result['items']);

					if ($items_loaded != 0) {

						foreach ($result['items'] as $key => $value) {

				?>
					<li class="order-item top">
					<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 item-left">
					<div class="item-booker"><?php echo $value['title'];?></div>
					
					</div>
					
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 item-left">
					<div class="item-message">
					<i class="fa fa-envelope"></i>

					<span><?php echo $value['description'];?></span>
					</div>

					</div>
					</div>
					<a class="item-more" id="g69963" onclick="showMessage(this.id);return false;" href="#">
					<i></i>
					</a>
					</li>
				<?php
						}
						
					} else {

				?>

					<div class="row">
						<div class="col s12">
							<div class="card blue-grey darken-1">
								<div class="card-content white-text">
									<span class="card-title"><?php echo $LANG['label-empty-list']; ?></span>
								</div>
							</div>
						</div>
					</div>

							<?php
						}
					?>
					
                </ul>
                
            </div>
        </div>
    </div>
</div>
<!-- /Page Body -->
</div>
<!-- /Page Content -->
</div>
<!-- /Page Container -->
<!-- Main Container -->
</div>