<?php
include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/login.html');
?>