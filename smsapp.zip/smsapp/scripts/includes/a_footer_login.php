<?php
	include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/footer_login.html');
?>