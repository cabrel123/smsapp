<?php
	include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/footer.html');
?>
<script src="/assets/jquery-validation/js/jquery.validate.min.js"></script>
<?php if(isset($action) && ($action=="addcategory")) {?>
<script src="/assets/js/pages/category.js"></script>
<?php }?>
<?php if(isset($action) && ($action=="users")) {?>
<script src="/assets/js/pages/users.js"></script>
<?php }?>
<script type="text/javascript">
  //  window.App || ( window.App = {} );
function createCookie(language) {
    name,value,days
    var name = "lang";
    var days = "7";
    var value = language;
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
    //location.reload();
	var initLang = LANG_CODE;
	var url = new URL(window.location.href);
    var url2 = url.toString().replace(initLang, language);
    //location.reload(newUrl);
    document.location.replace(url2);
    //$( "#actifLanguage" ).append(LANG_NAME);
    console.log(url2);
}

</script>
</body>
</html>