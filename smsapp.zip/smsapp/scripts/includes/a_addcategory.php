<?php
	$categories = new categories($dbo);
	include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/addcategory.html');
?>