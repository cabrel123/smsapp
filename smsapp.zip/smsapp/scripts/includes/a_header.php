<?php
include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/header.html');
?>