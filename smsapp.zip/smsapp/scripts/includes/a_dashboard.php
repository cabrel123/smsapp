<?php
 include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/dashboard.html');
?>