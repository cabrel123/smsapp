<?php
	
	$categories = new categories($dbo);
	include($_SERVER['DOCUMENT_ROOT'].'/scripts/templates/users.html');
?>