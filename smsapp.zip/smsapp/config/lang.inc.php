<?php
/**************************************************************** *
 * SMSAPP engine v1.0        					  				  *
 *                                                                *
 * 						                                          *
 * monkamcabrel11@gmail.com                             		  *
 *                                                                *
 * Copyright 2023 MONKAM CABREL									  *
 ******************************************************************
 */

$url_lang_code  = helper::getLangCodeFromURL();



if(isset($url_lang_code) && !empty($url_lang_code)){

        $language = $url_lang_code;

        $result = "fr";

        if (in_array($language, $LANGS)) {

            $result = $language;
        }

        @setcookie("lang", $result, time() + 14 * 24 * 3600, "/");
        include_once($_SERVER['DOCUMENT_ROOT']."/lang/".$result.".php");



}else{

    if(empty($url_lang_code) && empty($_COOKIE['lang']) ){

        $language = "fr";

        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {

            $language = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
        }

        $result = "fr";

        if (in_array($language, $LANGS)) {

            $result = $language;
        }

        @setcookie("lang", $result, time() + 14 * 24 * 3600, "/");
        include_once($_SERVER['DOCUMENT_ROOT']."/lang/".$result.".php");

        $pageNameTranslated          = $TEXT["menu-home-desc"] ;
        $pageNameTranslated          = helper::slugify($pageNameTranslated);
        $homePage = $B['APP_URL']."/home/".$result."/".$pageNameTranslated ;
if($result != "fr"){
  //header('Location: '.$homePage);
}
    

 }elseif(empty($url_lang_code) && !empty($_COOKIE['lang']) ){ 

  $language = $_COOKIE['lang'];

        $result = "fr";

        if (in_array($language, $LANGS)) {

            $result = $language;
        }

        @setcookie("lang", $result, time() + 14 * 24 * 3600, "/");
        include_once($_SERVER['DOCUMENT_ROOT']."/lang/".$result.".php");

        //Retrieve language lang_code
        $url                         = helper::curPageURL();
        $lang_code                   = helper::getLangCodeFromURL();
        $pageName                    = helper::getPageNameFromURL();
        $getPageDescriptionFromURL   = helper::getPageDescriptionFromURL();
        $pageNameTranslated          = $TEXT["menu-$pageName-desc"] ;
        $pageNameTranslated          = helper::slugify($pageNameTranslated);
        $homePage = $B['APP_URL']."/home/".$language."/".$pageNameTranslated ;
       
   // header('Location: '.$homePage);


    

 }

}

    $LANG = $TEXT;
?>